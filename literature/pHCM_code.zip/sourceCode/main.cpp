  /*
  * =====================================================================================
  *
  *  This program is free software: you can redistribute it and/or modify
  *  it under the terms of the GNU General Public License as published by
  *  the Free Software Foundation, either version 3 of the License, or
  *  (at your option) any later version.
  *
  *  This program is distributed in the hope that it will be useful,
  *  but WITHOUT ANY WARRANTY; without even the implied warranty of
  *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  *  GNU General Public License for more details.
  *
  *  You should have received a copy of the GNU General Public License
  *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
  *
  * -------------------------------------------------------------------------------------
  *
  *       Filename:  main.cpp
  *
  *        Version:   1.0
  *        Created:   6/18/13
  *        Revision:  none
  *        Compiler:  gcc/intel compiler
  *        Author:    Adam Chacon, adamdante@gmail.com
  *                   Cornell University
  *
  *        This file is a part of the numerical methods implementation/
  *        benchmarking described in the following article:
  *
  *	   http://www.math.cornell.edu/~vlad/papers/pHCM/
  *
  *	   The HCM and pHCM algorithms were developed by A. Chacon and 
  *	   A. Vladimirsky.
  *
  * =====================================================================================
  */



#include <math.h>
#include <assert.h>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <time.h>
#include "params3D.h"
#include "omp.h"
#include "GlobalVars3D.h"
#include "fenv.h"

using namespace std;


int m; //number x-gridpoints
int n;//number y-gridpoints
int b; //number z-gridpoints

int cm;
int cn;
int cb;
int cellHeight;
int cellDepth;
int cellWidth;
int numBV;

#ifndef CONST_THREADS
int numthreads;
#endif

DOUBLE threshConst;
DOUBLE hx;
DOUBLE hy;
DOUBLE hz;

DOUBLE chx;
DOUBLE chy;
DOUBLE chz;

int trialNum; //for running many trials of a method.  3/9/12.
int numTrials; //this is in params now 4/20/12

DOUBLE prevTime[4]; //Used for removing outliers in pHCM trials.  4/20/12

int numcheckers;
DOUBLE checkerdimx;
DOUBLE checkerdimy;
DOUBLE checkerdimz;

speeds speed_fun;
exits exit_set;
//int CompUCounter = 0;
//int CompUCounter3 = 0; //DEBUG only!  Be sure to turn off for parallel methods!
//int CompUCounter2 = 0;
//int CompUCounter1 = 0;
//int TwoSidedCounter = 0;

#include "ComputeFuncs3D.h"
#include "OtherCommon.h"
#include "HeapCellMethod.h"
#include "Gridpoint.h"
#include "HeapGeneral.h"
#include "parallelHCM.h"
#include "timingInfo.h"

void set_global_vars(param_struct params);
//void Incorporate_Into_L(FMMGridpoint ***domain, HeapGeneral<FMMGridpoint> *Considered,
//                       int x, int y, int z, DOUBLE rootVal);
//void Update_fmmNode(FMMGridpoint ***domain, HeapGeneral<FMMGridpoint> *Considered,int x, int y, int z);

template <class GPs>
void Initialize(GPs*** domain);
void InitializeFMM(FMMGridpoint ***domain, HeapGeneral<FMMGridpoint> *Considered);
void InitializeLSM(LSMGridpoint ***domain);

DOUBLE FastMarchingMethod(FMMGridpoint ***domain,HeapGeneral<FMMGridpoint> *Considered);
int FastSweepingMethod(FSMGridpoint ***domain);
int LockingSweepingMethod(LSMGridpoint*** domain);
//void UnlockNeighbors(LSMGridpoint*** domain, int x, int y, int z); //4/10/13: moved into OtherCommon.h

template <class T, class U>
        void Compare(T*** fmmdomain, U*** fsmdomain);

template <class GPs>
        void CheckAgainstExact(GPs*** domain);

template <class GPs>
        void CheckSymmetry(GPs*** domain);

DOUBLE FMM();
DOUBLE LSM(int* numSweeps);
DOUBLE FSM();
DOUBLE DetrixheFSM();
DOUBLE DetrixheLSM();
void HCM(bool isFast, double cellTimes[], double cellExclTimes[], DOUBLE AvS[]);
void pHCM(bool isFast,double cellTimes[], double cellExclTimes[], DOUBLE AvS[]);
void RunAll();
void Run_RecordTiming(param_struct params);
void Run_Record_Scaling(param_struct params);



int main(int argc, char** argv)
{
    //fesetround(FE_UPWARD);

    param_struct params; //command line parameters;
    get_params(argc, argv, &params);
    set_global_vars(params);
    print_params(params);
    cout<<"Size of DOUBLE data: "<<sizeof(DOUBLE)<<endl;
    
#ifdef NEW_CELL_VAL
    cout<<"Using experimental cell value."<<endl;
#endif

#ifdef UNSAFE_COMP_THREE
    cout<<"Using possibly non-monotonic Compute From Three Neighbors. See GlobalConfiguration.h"<<endl;
#else
#endif

#ifdef _DEBUGMODE
    cout<<"Running in Debug Mode."<<endl;
#else
#endif

#ifndef LSM_in_Cells
    cout<<"Using FSM in cells."<<endl;
#endif

    cout<<"Num trials of each method: "<<numTrials<<endl;
    cout<<"Sweep termination threshold: "<<sweepTerminationThresh<<endl;
    double cellTimes[numCellDivs];
    double cellExclTimes[numCellDivs];
    DOUBLE AvS[numCellDivs];
    int numSweeps;
    numthreads = 1;
    //FMM();
    //FSM();
    //LSM(&numSweeps);     
    //DetrixheFSM();
    
    HCM(false,cellTimes,cellExclTimes,AvS);
    //pHCM(false, cellTimes, cellExclTimes,AvS);
    
    //  Run_Record_Scaling(params);    
    //Run_RecordTiming(params);




    return 0;
}


void Run_RecordTiming(param_struct params)
{
  int i,j,currentM, numSweeps;
  double cellTimes_pHCM[numCellDivs];
  double cellTimes_HCM[numCellDivs];
  double cellExclTimes_pHCM[numCellDivs];
  double cellExclTimes_HCM[numCellDivs];
  DOUBLE AvS_HCM[numCellDivs];
  DOUBLE AvS_pHCM[numCellDivs];


  Performance perf1(mStart,numMTrials,mStep);
  cout<<"Num m trials: "<<numMTrials<<endl;
  cout<<"Num cell trials: "<<numCellDivs<<endl;

  for(i = 0; i < numMTrials; i++)
    {
      //currentM = mStart*(int)pow(2,i);
      currentM = mStart + i*mStep;
      //currentM = mTrials[i];

      m = currentM;
      n = m;
      b = m;
      
      hx = (maxx - minx)/ (DOUBLE)(m-1);
      hy = (maxy - miny)/ (DOUBLE)(n-1);
      hz = (maxz - minz)/ (DOUBLE)(b-1); 
      
      print_params(params);
      cout<<endl;
      
      perf1.fmmTime = FMM();
      perf1.lsmTime = LSM(&numSweeps);
      perf1.numSweeps[i] = numSweeps;
      perf1.fsmTime = FSM();
      HCM(false,cellTimes_HCM, cellExclTimes_HCM, AvS_HCM);
      //pHCM(false,cellTimes_pHCM, cellExclTimes_pHCM, AvS_pHCM);

      
      for(j = 0; j < numCellDivs; j++)
	{
	  perf1.hcmTime = cellTimes_HCM[j];
	  perf1.pHCMTime = 1;//cellTimes_pHCM[j];
	  //perf1.setSpeedUps_MJ(i,j);
	  perf1.setRawTimes_MJ(i,j);

	}
      
    }
  perf1.writeMatlabFile(true);
  perf1.writeLatexFile3(); //used to record the number of sweeps for different M for LSM
}


void Run_Record_Scaling(param_struct params)
{
  int i,j,currentP;
  int numSweeps;
  double cellTimes_pHCM[numCellDivs];
  double cellTimes_HCM[numCellDivs];
  double cellExclTimes_pHCM[numCellDivs];
  double cellExclTimes_HCM[numCellDivs];
  DOUBLE AvS_HCM[numCellDivs];
  DOUBLE AvS_pHCM[numCellDivs];

  Performance perf1(mStart,numPTrials,mStep);
  cout<<"Num p trials: "<<numPTrials<<endl;
  cout<<"Num cell trials: "<<numCellDivs<<endl;

  assert(numMTrials == 1);

  perf1.fmmTime = FMM();
  perf1.lsmTime = LSM(&numSweeps);
  perf1.fsmTime = FSM();
  
    
  //DEBUG:
/*
  for(i = 0; i < numCellDivs; i++)
    {
      AvS_HCM[i] = 1;
      AvS_pHCM[i] = 1;
      prevTime[i] = 1;
    }
*/
 
  HCM(false,cellTimes_HCM, cellExclTimes_HCM,AvS_HCM);
  for(i = 0; i < numPTrials; i++)
    {
#ifndef CONST_THREADS
      numthreads = i + 1;
#endif
      pHCM(false,cellTimes_pHCM, cellExclTimes_pHCM,AvS_pHCM);

      /*New 4/22/13: Record Detrixhe scaling */
      perf1.detrixheFSMTime = DetrixheFSM();
      perf1.detrixheLSMTime = DetrixheLSM();
      
      for(j = 0; j < numCellDivs; j++)
	{
	  perf1.hcmTime = cellTimes_HCM[j];
	  perf1.pHCMTime = cellTimes_pHCM[j];
	  perf1.hcmCellCompTime = cellExclTimes_HCM[j];
	  perf1.pHCMCellCompTime = cellExclTimes_pHCM[j];
	  
	  perf1.setSpeedUps_PJ(i,j);
	  perf1.setRawTimes_PJ(i,j);
	  perf1.setAvSData(AvS_HCM[j],AvS_pHCM[j],i,j);

	  prevTime[j] = cellTimes_pHCM[j];
	}
    }

  perf1.writeMatlabFile(false);
  //perf1.writeLatexFile2();

}



DOUBLE FMM()
{
    int i,j,k;
    double startTime, endTime, totalTime, avgHeapSize;
    FMMGridpoint ***fmmdomain = new FMMGridpoint**[m];

    FMMGridpoint temp;
    /*
    cout<<"Size of fmm gp: "<<sizeof(temp)<<endl;
    cout<<"Size of int: "<<sizeof(int)<<endl;
    cout<<"Size of DOUBLE: "<<sizeof(DOUBLE)<<endl;
    cout<<"Size of enum: "<<sizeof(flags)<<endl;
    */
    for(i = 0; i < m; i++)
        fmmdomain[i] = new FMMGridpoint*[n];
    fmmdomain[0][0] = new FMMGridpoint[m*n*b];
    k = 0;
    for(i = 0; i < m; i++)
    {
        for(j = 0; j < n; j++)
        {
            fmmdomain[i][j] = fmmdomain[0][0] + b*k;
            k++;
        }
    }
    HeapGeneral<FMMGridpoint> Considered;

    //void* A = &fmmdomain[1][1][1];
    //void* B = &fmmdomain[1][1][2];

    //cout<<"Difference of addresses of array: "<<B-A<<endl;
    //cout<<"Size of fmm gp in array: "<<sizeof(fmmdomain[1][1][1])<<endl;


    totalTime = 0;
    Considered.Initialize(m*n*b); //the parameter is the maximum size of the list.
    for(i = 0; i < numTrials; i++)
      {

	startTime = omp_get_wtime();
	InitializeFMM(fmmdomain, &Considered);
	avgHeapSize = FastMarchingMethod(fmmdomain,&Considered);
	endTime = omp_get_wtime();
	totalTime += endTime - startTime;
      }
    //  cout<<"Avg Heap Size: "<<avgHeapSize<<endl;
    //  cout<<"Comp from 3 neighbs per gp: "<<(double)CompUCounter3/(m*n*b)<<endl;
    //  cout<<"Comp from 2 neighbs per gp: "<<(double)CompUCounter2/(m*n*b)<<endl;
    // cout<<"Comp from 1 neighbs per gp: "<<(double)CompUCounter1/(m*n*b)<<endl;
    //  cout<<"TwoSided opt per gp: "<<(double)TwoSidedCounter/(m*n*b)<<endl;
    cout<<"Fast Marching Time per Trial: "<<(totalTime)/numTrials<<endl<<endl;


    delete [] fmmdomain[0][0];
    for(i = 0; i < m; i++)
      delete [] fmmdomain[i];
    delete [] fmmdomain;

    return endTime - startTime;
}

DOUBLE LSM(int* numSweeps)
{
    int i,j,k;
    double startTime, endTime, totalTime;

    LSMGridpoint ***lsmdomain = new LSMGridpoint**[m];
    for(i = 0; i < m; i++)
        lsmdomain[i] = new LSMGridpoint*[n];
    lsmdomain[0][0] = new LSMGridpoint[m*n*b];
    k = 0;
    for(i = 0; i < m; i++)
    {
        for(j = 0; j < n; j++)
        {
            lsmdomain[i][j] = lsmdomain[0][0] + b*k;
            k++;
        }
    }
    totalTime = 0;
    for(i = 0; i < numTrials; i++)
      {
	startTime = omp_get_wtime();
	InitializeLSM(lsmdomain);
	*numSweeps = LockingSweepingMethod(lsmdomain);
	endTime = omp_get_wtime();
	totalTime += endTime - startTime;
      }


    cout<<"Locking Sweeping Time per trial: "<<totalTime/numTrials;
    cout<<".   Number sweeps: "<<*numSweeps<<endl<<endl;

    //printLevelSet(lsmdomain,.3);


    delete [] lsmdomain[0][0];
    for(i = 0; i < m; i++)
      delete [] lsmdomain[i];
    delete [] lsmdomain;
    
    return endTime - startTime;
    
}

DOUBLE FSM()
{
    int i,j,k, numSweeps;
    double startTime, endTime, totalTime;
    //FSM domain
    FSMGridpoint ***fsmdomain = new FSMGridpoint**[m];
    for(i = 0; i < m; i++)
        fsmdomain[i] = new FSMGridpoint*[n];
    fsmdomain[0][0] = new FSMGridpoint[m*n*b];
    k = 0;
    for(i = 0; i < m; i++)
    {
        for(j = 0; j < n; j++)
        {
            fsmdomain[i][j] = fsmdomain[0][0] + b*k;
            k++;
        }
    }
    
    totalTime = 0;
    for(i = 0; i < numTrials; i++)
      {
	startTime = omp_get_wtime();
	Initialize(fsmdomain);
	numSweeps = FastSweepingMethod(fsmdomain);
	endTime = omp_get_wtime();
	totalTime += endTime - startTime;
      }
    cout<<"Fast Sweeping Time per trial: "<<totalTime/numTrials;
    cout<<".   Number sweeps: "<<numSweeps<<endl<<endl;

    delete [] fsmdomain[0][0];
    for(i = 0; i < m; i++)
      delete [] fsmdomain[i];
    delete [] fsmdomain;

    return totalTime/(numTrials);

}

DOUBLE DetrixheFSM()
{
  int i,j,k, numSweeps;
  double startTime, endTime, totalTime;

  FSMGridpoint ***domain = new FSMGridpoint**[m];
    for(i = 0; i < m; i++)
      domain[i] = new FSMGridpoint*[n];
    domain[0][0] = new FSMGridpoint[m*n*b];

    k = 0;
    for(i = 0; i < m; i++)
    {
        for(j = 0; j < n; j++)
        {
            domain[i][j] = domain[0][0] + b*k;
            k++;
        }
    }

    
    
    //for(numthreads = 1; numthreads <= 16; numthreads++)
    //  {    
    totalTime = 0;
    for(i = 0; i < numTrials; i++)
      {
	startTime = omp_get_wtime();
	Initialize(domain);
	numSweeps = parallelDetrixhe(domain);
	
	endTime = omp_get_wtime();
	totalTime += endTime - startTime;
      }
    cout<<"Detrixhe Sweeping Time per trial: "<<totalTime/numTrials;
    cout<<".   Number sweeps: "<<numSweeps<<endl<<endl;
    //}
    
    delete [] domain[0][0];
    for(i = 0; i < m; i++)
      delete [] domain[i];
    delete [] domain;

    return totalTime/(numTrials);

}


DOUBLE DetrixheLSM()
{
  int i,j,k, numSweeps;
  double startTime, endTime, totalTime;


    LSMGridpoint ***lsmdomain = new LSMGridpoint**[m];
    for(i = 0; i < m; i++)
      lsmdomain[i] = new LSMGridpoint*[n];
    lsmdomain[0][0] = new LSMGridpoint[m*n*b];
     
    k = 0;
    for(i = 0; i < m; i++)
      {
        for(j = 0; j < n; j++)
	  {
            lsmdomain[i][j] = lsmdomain[0][0] + b*k;
            k++;
	  }
    }
    
    //   for(numthreads = 1; numthreads <= 16; numthreads++)
    //  {    
	totalTime = 0;
	for(i = 0; i < numTrials; i++)
	  {
	    startTime = omp_get_wtime();
	    InitializeLSM(lsmdomain);
	    numSweeps = parallelDetrixheLSM(lsmdomain);
	    
	    endTime = omp_get_wtime();
	    totalTime += endTime - startTime;
	  }
	cout<<"Detrixhe LSM Time per trial: "<<totalTime/numTrials;
	cout<<".   Number sweeps: "<<numSweeps<<endl<<endl;
	//}
    
    delete [] lsmdomain[0][0];
    for(i = 0; i < m; i++)
      delete [] lsmdomain[i];
    delete [] lsmdomain;
    
    return totalTime/(numTrials);

}




void HCM(bool isFast, double cellTimes[], double cellExclTimes[],DOUBLE AvS[])
{
  int i,j,k,l, HRs, Sweeps;
  double startTime, endTime, totalTime, totalCellExclTime;
  double cellCompTime;

 
    LSMGridpoint ***hcmdomain = new LSMGridpoint**[m];
    for(i = 0; i < m; i++)
        hcmdomain[i] = new LSMGridpoint*[n];
    hcmdomain[0][0] = new LSMGridpoint[m*n*b];
    k = 0;
    for(i = 0; i < m; i++)
    {
        for(j = 0; j < n; j++)
        {
            hcmdomain[i][j] = hcmdomain[0][0] + b*k;
            k++;
        }
    }

    for(l = 1; l <= numCellDivs; l++)
    {
      SetCellGlobals((int)(m/pow(2,l+4)));
      //SetCellGlobals((int)(m/pow(2,l)));
      
      //HCM cell domain
      cell ***celldomain = new cell**[cm];
      for(i = 0; i < cm; i++)
	celldomain[i] = new cell*[cn];
      celldomain[0][0] = new cell[cm*cn*cb];
      k = 0;
      for(i = 0; i < cm; i++)
	{
	  for(j = 0; j < cn; j++)
            {
	      celldomain[i][j] = celldomain[0][0] + cb*k;
	      k++;
            }
        }
      
      if(isFast)
        {
            cout<<"Fast Heap Cell Method."<<endl;
        }
        else
        {
            cout<<"Heap Cell Method."<<endl;
        }
        cout<<"Number cells: "<<cm<<"x"<<cn<<"x"<<cb<<" = "<<cm*cn*cb<<endl;
	totalTime = 0;
	//Sweeps = 0;
	totalCellExclTime = 0;
	for(i = 0; i < numTrials; i++)
	  {
	    startTime = omp_get_wtime();
	    InitializeLSM(hcmdomain);
	    Sweeps = HCMAlgorithm(celldomain,hcmdomain,isFast,&cellCompTime);
	    endTime = omp_get_wtime();
	    totalTime += endTime - startTime;
	    totalCellExclTime += cellCompTime;
	  }
	cout<<"Time per trial: "<<totalTime/numTrials<<endl;//(endTime - startTime)<<endl;
        cout<<"AvS: "<<(DOUBLE)Sweeps/(cm*cn*cb)<<endl<<endl;
	cellTimes[l - 1] = totalTime/numTrials;
	cellExclTimes[l - 1] = totalCellExclTime/numTrials;
	AvS[l - 1] = (DOUBLE)Sweeps/(cm*cn*cb);
        delete [] celldomain[0][0];
	for(i = 0; i < cm; i++)
	  delete [] celldomain[i];
        delete [] celldomain;
    }

    delete [] hcmdomain[0][0];
    for(i = 0; i < m; i++)
      delete [] hcmdomain[i];
    delete [] hcmdomain;
}

void pHCM(bool isFast, double cellTimes[], double cellExclTimes[], DOUBLE AvS[])
{
  int i,j,k,l, HRs, outliers, localNumTrials;
  double startTime, endTime, totalTime, totalCellCompTime, avgCellCompTime;
  double totalAvHR, cellCompTime;
  DOUBLE totalAvS, AvSweeps;

  bool handleOutliers = false;


  //pHCM domain
  LSMGridpoint ***hcmdomain = new LSMGridpoint**[m];
  for(i = 0; i < m; i++)
    hcmdomain[i] = new LSMGridpoint*[n];
  hcmdomain[0][0] = new LSMGridpoint[m*n*b];
  k = 0;
  for(i = 0; i < m; i++)
    {
      for(j = 0; j < n; j++)
        {
	  hcmdomain[i][j] = hcmdomain[0][0] + b*k;
            k++;
        }
    }
  
  for(l = 1; l <= numCellDivs; l++)
    {
      //SetCellGlobals((int)(m/pow(2,l+1)));
      SetCellGlobals((int)(m/pow(2,l)));
      
      
      //pHCM cell domain
      parallelCell ***celldomain = new parallelCell**[cm];
      for(i = 0; i < cm; i++)
	celldomain[i] = new parallelCell*[cn];
      celldomain[0][0] = new parallelCell[cm*cn*cb];
      k = 0;
      for(i = 0; i < cm; i++)
        {
	  for(j = 0; j < cn; j++)
            {
                celldomain[i][j] = celldomain[0][0] + cb*k;
                k++;
            }
        }

        if(isFast)
        {
            cout<<"Parallel Fast Heap Cell Method."<<endl;
        }
        else
        {
            cout<<"Parallel Heap Cell Method."<<endl;
        }
        cout<<"Number cells: "<<cm<<"x"<<cn<<"x"<<cb<<" = "<<cm*cn*cb<<endl;
	cout<<"Num Threads: "<<numthreads<<endl;
	totalTime = 0;
	totalCellCompTime = 0;
	totalAvHR = 0;
	totalAvS = 0;
	outliers = 0;
	
	if(handleOutliers == true)
	  localNumTrials = 5;
	else
	  localNumTrials = numTrials;

	for(i = 0; i < localNumTrials; i++)
	  {
	    startTime = omp_get_wtime();
	    InitializeLSM(hcmdomain);
	    AvSweeps = ParallelHCM(celldomain, hcmdomain, isFast,&cellCompTime);
	    endTime = omp_get_wtime();


	    if(numthreads > 1 && handleOutliers == true)
	      { 
		if((endTime - startTime) < 2*prevTime[l-1])
		  {
		    totalAvS += AvSweeps;
		    totalCellCompTime += cellCompTime;
		    totalTime += endTime - startTime;
		  }
		else //The trial took more than double the amount of time at numthreads - 1
		  {
		    outliers++;
		    totalAvS += AvSweeps;
		    totalCellCompTime += cellCompTime;
		    totalTime += endTime - startTime;
		  }
	      }
	    else //outliers never happen at numthreads == 1.
	      {
		totalAvS += AvSweeps;
		totalCellCompTime += cellCompTime;
		totalTime += endTime - startTime;
	      }
	    
	  }
	if(outliers == localNumTrials)
	  {	   
	    //assert(false);
	  }
	if(outliers > 0)
	  cout<<"num outliers: "<<outliers<<endl;
	
	//This reports measurements with no data thrown away.

	avgCellCompTime = totalCellCompTime/(localNumTrials);// - outliers);
	cout<<"Time per trial: "<<totalTime/(localNumTrials)<<endl;// - outliers)<<endl;
	cellTimes[l - 1] = totalTime/(localNumTrials);// - outliers);
	cellExclTimes[l - 1] = avgCellCompTime;

	AvS[l - 1] = totalAvS/(localNumTrials);// - outliers);
	cout<<"Total AvS: "<<totalAvS/(localNumTrials)<<endl<<endl;// - outliers)<<endl<<endl;
	//cout<<"Ratio of # removals to # cells: "<<(DOUBLE)HRs/(cm*cn*cb)<<endl<<endl;

        delete [] celldomain[0][0];
	for(i = 0; i < cm; i++)
	  delete [] celldomain[i];
        delete [] celldomain;
    }

    delete [] hcmdomain[0][0];
    for(i = 0; i < m; i++)
      delete [] hcmdomain[i];
    delete [] hcmdomain;
}



void RunAll()
{
    int i,j,k,numSweeps,HRs;
    HRs = 0;
    float ptime1, ptime2;
    //FMM domain
    FMMGridpoint ***fmmdomain = new FMMGridpoint**[m];
    for(i = 0; i < m; i++)
        fmmdomain[i] = new FMMGridpoint*[n];
    fmmdomain[0][0] = new FMMGridpoint[m*n*b];
    k = 0;
    for(i = 0; i < m; i++)
    {
        for(j = 0; j < n; j++)
        {
            fmmdomain[i][j] = fmmdomain[0][0] + b*k;
            k++;
        }
    }
    HeapGeneral<FMMGridpoint> Considered;//the parameter is the maximum size of the list.

    //LSM domain
    LSMGridpoint ***lsmdomain = new LSMGridpoint**[m];
    for(i = 0; i < m; i++)
        lsmdomain[i] = new LSMGridpoint*[n];
    lsmdomain[0][0] = new LSMGridpoint[m*n*b];
    k = 0;
    for(i = 0; i < m; i++)
    {
        for(j = 0; j < n; j++)
        {
            lsmdomain[i][j] = lsmdomain[0][0] + b*k;
            k++;
        }
    }
    
    //Dextrixhe domain
    LSMGridpoint ***detrixheDomain = new LSMGridpoint**[m];
    for(i = 0; i < m; i++)
        detrixheDomain[i] = new LSMGridpoint*[n];
    detrixheDomain[0][0] = new LSMGridpoint[m*n*b];
    k = 0;
    for(i = 0; i < m; i++)
    {
        for(j = 0; j < n; j++)
        {
	  detrixheDomain[i][j] = detrixheDomain[0][0] + b*k;
	  k++;
        }
    }

    //HCM domain
    LSMGridpoint ***hcmdomain = new LSMGridpoint**[m];
    for(i = 0; i < m; i++)
        hcmdomain[i] = new LSMGridpoint*[n];
    hcmdomain[0][0] = new LSMGridpoint[m*n*b];
    k = 0;
    for(i = 0; i < m; i++)
    {
        for(j = 0; j < n; j++)
        {
            hcmdomain[i][j] = hcmdomain[0][0] + b*k;
            k++;
        }
    }

    //HCM cell domain
    SetCellGlobals(numCellsStart);
    parallelCell ***celldomain = new parallelCell**[cm];
    for(i = 0; i < cm; i++)
        celldomain[i] = new parallelCell*[cn];
    celldomain[0][0] = new parallelCell[cm*cn*cb];
    k = 0;
    for(i = 0; i < cm; i++)
    {
        for(j = 0; j < cn; j++)
        {
            celldomain[i][j] = celldomain[0][0] + cb*k;
            k++;
        }
    }


    //    time1 = clock();
    //Considered.Initialize(m*n*b);
    //InitializeFMM(fmmdomain, &Considered);
    //FastMarchingMethod(fmmdomain,&Considered);
    // time2 = clock();
    //cout<<"Fast Marching Time: "<<(DOUBLE)(time2 - time1)/CLOCKS_PER_SEC<<endl<<endl;

    bool locking = true;
    if(locking)
    {
        InitializeLSM(lsmdomain);
        numSweeps = LockingSweepingMethod(lsmdomain);
    }
 
    if(locking)
    {
        cout<<"Locking ";
    }
    else
    {
        cout<<"Fast ";
    }
    // cout<<"Sweeping Time: "<<(DOUBLE)(time2 - time1)/CLOCKS_PER_SEC;
    cout<<".   Number sweeps: "<<numSweeps<<endl<<endl;


    //Detrixhe:
    InitializeLSM(detrixheDomain);
    numSweeps = parallelDetrixheLSM(detrixheDomain);    




    /*
    bool isFast = false;
    if(isFast)
    {
        cout<<"Fast Heap Cell Method."<<endl;
    }
    else
    {
        cout<<"Heap Cell Method."<<endl;
    }
    cout<<"Number cells: "<<cm<<"x"<<cn<<"x"<<cb<<" = "<<cm*cn*cb<<endl;
    ptime1 = omp_get_wtime();
    //InitializeLSM(hcmdomain);
    //HRs = HCMAlgorithm(celldomain,hcmdomain,isFast);
    //ParallelHCM(celldomain,hcmdomain,isFast);
    ptime2 = omp_get_wtime();
    cout<<"Time: "<<(ptime2 - ptime1)<<endl;
    cout<<"Ratio of # removals to # cells: "<<(DOUBLE)HRs/(cm*cn*cb)<<endl;
    */

    Compare(detrixheDomain,lsmdomain);
    //CheckAgainstExact(fsmdomain);
    //CheckSymmetry(fmmdomain);
    //CheckSymmetry(fsmdomain);
    cout<<endl;


    delete [] fmmdomain[0][0];
    for(i = 0; i < m; i++)
      delete [] fmmdomain[i];
    delete [] fmmdomain;

    delete [] lsmdomain[0][0];
    for(i = 0; i < m; i++)
      delete [] lsmdomain[i];
    delete [] lsmdomain;
    
    delete [] detrixheDomain[0][0];
    for(i = 0; i < m; i++)
      delete [] detrixheDomain[i];
    delete [] detrixheDomain;


    delete [] celldomain[0][0];
    for(i = 0; i < cm; i++)
      delete [] celldomain[i];
    delete [] celldomain;

    delete [] hcmdomain[0][0];
    for(i = 0; i < m; i++)
      delete [] hcmdomain[i];
    delete [] hcmdomain;

}


void set_global_vars(param_struct params)
{
    /*The global variables set are
m, the number gridpoints along x-direction
n, # gridpoints along y-direction
b, # gridpoints along z-direction

speed function
number of checkers, if speed function is chosen to be checkerboard.
exit set.
See the file params.cpp.  */

    m  = params.m;
    n = m;
    b = m;
    numcheckers = params.nc;
    speed_fun = params.sp;
    exit_set = params.ex;
    threshConst = params.threshConst;
    numTrials = params.numTrials;

    hx = (maxx - minx)/ (DOUBLE)(m-1);
    hy = (maxy - miny)/ (DOUBLE)(n-1);
    hz = (maxz - minz)/ (DOUBLE)(b-1);
/*
    cm = 7;
    cn = cm;
    cb = cm;
    assert(m%cm == 0);

    cellWidth = m/cm;
    cellDepth = n/cn;
    cellHeight = b/cb;

    chx = (maxx - minx)/(DOUBLE)(cm);
    chy = (maxy - miny)/(DOUBLE)(cn);
    chz = (maxz - minz)/(DOUBLE)(cb);
*/
    checkerdimx = (maxx - minx )/numcheckers;
    checkerdimy = (maxy - miny) /numcheckers;
    checkerdimz = (maxz - minz) /numcheckers;
}

template <class GPs>
        void Initialize(GPs ***domain)
{
    int i,j,k, bvx, bvy, bvz, halfM, halfN, halfB;
    DOUBLE cubeCenter, squareCenter;

    for(i = 0; i < m; i++)
    {
        for(j = 0; j < n; j++)
        {
            for(k = 0; k < b; k++)
                domain[i][j][k].value = inf;
        }
    }

    switch(exit_set)
    {

    case center:
        //based on parity of m.
        if(m%2 == 0){
            cubeCenter = sqrt(3)*hx/2;
            halfM = m/2;
            halfN = n/2;
            halfB = b/2;

            domain[halfM][halfN][halfB].value = cubeCenter;
            domain[halfM - 1][halfN][halfB].value = cubeCenter;
            domain[halfM][halfN - 1][halfB].value = cubeCenter;
            domain[halfM - 1][halfN - 1][halfB].value = cubeCenter;

            domain[halfM][halfN][halfB - 1].value = cubeCenter;
            domain[halfM - 1][halfN][halfB - 1].value = cubeCenter;
            domain[halfM][halfN - 1][halfB - 1].value = cubeCenter;
            domain[halfM - 1][halfN - 1][halfB - 1].value = cubeCenter;
            numBV = 8;
        }

        else
        {
            bvx = (int)(m - 1)/2;
            bvy = (int)(n - 1)/2;
            bvz = (int)(b - 1)/2;
            domain[bvx][bvy][bvz].value = 0;
            numBV = 1;
        }
        break;

case lowerleftcorner:
        domain[0][0][0].value = 0;
        numBV = 1;
        break;

case zaxis:
  //assert(m%2 == 1);
	if(m%2 == 1)
	  {
	    numBV = b;
	    bvx = (int)(m - 1)/2;
	    bvy = (int)(n - 1)/2;
	    for(i = 0; i < numBV; i++)
	      {
		bvz = i;
		domain[bvx][bvy][bvz].value = 0;
	      }
	  }
	else
	  {
	    numBV = 4*b;
	    squareCenter = SQRT2*hx/2;
	    halfM = m/2;
	    halfN = n/2;
	    for(i = 0; i < numBV; i++)
	      {
		domain[halfM][halfN][i].value = squareCenter;
		domain[halfM -1][halfN][i].value = squareCenter;
		domain[halfM - 1][halfN - 1][i].value = squareCenter;
		domain[halfM][halfN - 1][i].value = squareCenter;
	      }
	  }
        break;

case domainedge:
        //TODO
        //See note in ComputeBorder().
        for(i = 0; i < m; i++)
        {
            for(j = 0; j < n; j++)
            {
                for(k = 0; k < b; k++)
                {
                    if(i == 0 || i == m-1 || j == 0 || j == n-1 || k == 0 || k == b-1)
                        domain[i][j][k].value = 0;
                }
            }
        }
        break;
    }
}


void InitializeFMM(FMMGridpoint ***domain, HeapGeneral<FMMGridpoint> *Considered)
{

    Initialize(domain);
    Considered->currently_used = 0;
    int i,j,k, bvx,bvy, bvz, halfM, halfN, halfB;

    int neighborVec[6][3];
    SetNeighborVec(neighborVec);

    for(i = 0; i < m; i++)
      {
	for(j = 0; j < n; j++)
	  {
	    for(k = 0; k < b; k++)
	      domain[i][j][k].status = FAR;
	  }
      }
    
    //int numbv is a global set in Initialize()
    int **bv = new int*[numBV];
    for(i = 0; i < numBV; i++)
        bv[i] = new int[3];

    switch(exit_set)
    {
    case center:
        //based on parity of m.
        if(m%2 == 0){
            halfM = m/2;
            halfN = n/2;
            halfB = b/2;

            domain[halfM][halfN][halfB].status = ACCEPTED;
            bv[0][0] = halfM;
            bv[0][1] = halfN;
            bv[0][2] = halfB;

            bvx = halfM - 1;
            bvy = halfN;
            bvz = halfB;
            domain[bvx][bvy][bvz].status = ACCEPTED;
            bv[1][0] = bvx;
            bv[1][1] = bvy;
            bv[1][2] = bvz;

            bvx = halfM;
            bvy = halfN - 1;
            bvz = halfB;
            domain[bvx][bvy][bvz].status = ACCEPTED;
            bv[2][0] = bvx;
            bv[2][1] = bvy;
            bv[2][2] = bvz;

            bvx = halfM - 1;
            bvy = halfN - 1;
            bvz = halfB;
            domain[bvx][bvy][bvz].status = ACCEPTED;
            bv[3][0] = bvx;
            bv[3][1] = bvy;
            bv[3][2] = bvz;

            bvx = halfM;
            bvy = halfN;
            bvz = halfB - 1;
            domain[bvx][bvy][bvz].status = ACCEPTED;
            bv[4][0] = bvx;
            bv[4][1] = bvy;
            bv[4][2] = bvz;

            bvx = halfM - 1;
            bvy = halfN;
            bvz = halfB - 1;
            domain[bvx][bvy][bvz].status = ACCEPTED;
            bv[5][0] = bvx;
            bv[5][1] = bvy;
            bv[5][2] = bvz;

            bvx = halfM;
            bvy = halfN - 1;
            bvz = halfB - 1;
            domain[bvx][bvy][bvz].status = ACCEPTED;
            bv[6][0] = bvx;
            bv[6][1] = bvy;
            bv[6][2] = bvz;

            bvx = halfM - 1;
            bvy = halfN - 1;
            bvz = halfB - 1;
            domain[bvx][bvy][bvz].status = ACCEPTED;
            bv[7][0] = bvx;
            bv[7][1] = bvy;
            bv[7][2] = bvz;
        }

        else
        {
            bvx = (m - 1)/2;
            bvy = (n - 1)/2;
            bvz = (b - 1)/2;
            domain[bvx][bvy][bvz].status = ACCEPTED;
            bv[0][0] = bvx;
            bv[0][1] = bvy;
            bv[0][2] = bvz;
        }
        break;

case lowerleftcorner:
        domain[0][0][0].status = ACCEPTED;
        bv[0][0] = 0;
        bv[0][1] = 0;
        bv[0][2] = 0;
        break;

case zaxis:
  if(m%2 == 1)
    {
      bvx = (m - 1)/2;
      bvy = (n - 1)/2;
      for(i = 0; i < numBV; i++)
	{
	  
	  bvz = i;
	  bv[i][0] = bvx;
	  bv[i][1] = bvy;
	  bv[i][2] = bvz;
	  domain[bvx][bvy][bvz].status = ACCEPTED;
	}
    }
  else
    {
      halfM = m/2;
      halfN = n/2;
      for(i = 0; i < numBV/4; i++)
	{
	  bvz = i;
	  j = 4*i;
	  bv[j][0] = halfM - 1;
	  bv[j][1] = halfN - 1;
	  bv[j][2] = bvz;
	  domain[halfM - 1][halfN - 1][bvz].status = ACCEPTED;

	  bv[j + 1][0] = halfM - 1;
	  bv[j + 1][1] = halfN;
	  bv[j + 1][2] = bvz;
	  domain[halfM - 1][halfN][bvz].status = ACCEPTED;

	  bv[j + 2][0] = halfM;
	  bv[j + 2][1] = halfN - 1;
	  bv[j + 2][2] = bvz;
	  domain[halfM][halfN - 1][bvz].status = ACCEPTED;

	  bv[j + 3][0] = halfM;
	  bv[j + 3][1] = halfN;
	  bv[j + 3][2] = bvz;
	  domain[halfM][halfN][bvz].status = ACCEPTED;
	}
    }
  break;

default:
        assert(false);
        break;
    } //end switch

    int x,y,z;
    DOUBLE bvVal;
    for(i = 0; i < numBV; i++)
    {
        bvx = bv[i][0];
        bvy = bv[i][1];
        bvz = bv[i][2];

        bvVal = domain[bvx][bvy][bvz].value;
        for(j = 0; j < 6; j++)
        {
            x = bvx + neighborVec[j][0];
            y = bvy + neighborVec[j][1];
            z = bvz + neighborVec[j][2];
            if(x >= 0 && x < m && y >= 0 && y < n && z >=0 && z < b)
            {
#ifdef OLD_INC_L
                if(domain[x][y][z].status == FAR)
                    Incorporate_Into_L(domain,Considered,x,y,z,bvVal);
#else
		if(domain[x][y][z].status == FAR)
		  Incorporate_Into_L(&domain[x][y][z],Considered,x,y,z,bvVal);
#endif
                //IncorporateIntoLOptimized(Considered,&domain[x][y],bvVal,x,y);
            }
            /*7/8/11 HACK.  Necessary for exit set = domainedge
Possibly better to rewrite IncorporateIntoLOptimized()  */
            /*
            if((x == 1 && y == n-2)||(x == m-2 && y == n-2)||(x == n-2 && y == 1)||(x == 1 && y == 1) )
            {
                //TODO for domainedge
                domain[x][y][z].value = Update_fmmNode(domain,Considered,x,y,z);;
                //domain[x][y].value = UpdateNodeFMM(x,y,0,0,domain[x][y].value);
                //(x,y) assumed to be on the list already.
                Considered->upheap(domain[x][y][z].offset);
            }
            */
        }
    }
    for(i = 0; i < numBV; i++)
        delete [] bv[i];
    delete [] bv;
}

void InitializeLSM(LSMGridpoint ***domain)
{
    Initialize(domain);
    int i,j,k,bvx,bvy,bvz, halfM, halfN, halfB;
    //int numBV is a global set in Initialize()

    int **bv = new int*[numBV];
    for(i = 0; i < numBV; i++)
        bv[i] = new int[3];

    switch(exit_set)
    {
    case center:
        //based on parity of m.
        if(m%2 == 0)
        {
            halfM = m/2;
            halfN = n/2;
            halfB = b/2;

            bv[0][0] = halfM;
            bv[0][1] = halfN;
            bv[0][2] = halfB;

            bvx = halfM - 1;
            bvy = halfN;
            bvz = halfB;
            bv[1][0] = bvx;
            bv[1][1] = bvy;
            bv[1][2] = bvz;

            bvx = halfM;
            bvy = halfN - 1;
            bvz = halfB;
            bv[2][0] = bvx;
            bv[2][1] = bvy;
            bv[2][2] = bvz;

            bvx = halfM - 1;
            bvy = halfN - 1;
            bvz = halfB;
            bv[3][0] = bvx;
            bv[3][1] = bvy;
            bv[3][2] = bvz;

            bvx = halfM;
            bvy = halfN;
            bvz = halfB - 1;
            bv[4][0] = bvx;
            bv[4][1] = bvy;
            bv[4][2] = bvz;

            bvx = halfM - 1;
            bvy = halfN;
            bvz = halfB - 1;
            bv[5][0] = bvx;
            bv[5][1] = bvy;
            bv[5][2] = bvz;

            bvx = halfM;
            bvy = halfN - 1;
            bvz = halfB - 1;
            bv[6][0] = bvx;
            bv[6][1] = bvy;
            bv[6][2] = bvz;

            bvx = halfM - 1;
            bvy = halfN - 1;
            bvz = halfB - 1;
            bv[7][0] = bvx;
            bv[7][1] = bvy;
            bv[7][2] = bvz;
        }

        else
        {
            bvx = (int)(m - 1)/2;
            bvy = (int)(n - 1)/2;
            bvz = (int)(b - 1)/2;
            bv[0][0] = bvx;
            bv[0][1] = bvy;
            bv[0][2] = bvz;
        }

        break;

case lowerleftcorner:
        bv[0][0] = 0;
        bv[0][1] = 0;
        bv[0][2] = 0;
        break;
case zaxis:
  if(m%2 == 1)
    {
        for(i = 0; i < numBV; i++)
        {
            bvx = (int)(m - 1)/2;
            bvy = (int)(n - 1)/2;
            bvz = i;
            bv[i][0] = bvx;
            bv[i][1] = bvy;
            bv[i][2] = bvz;
        }
    }

  else
    {
      halfM = m/2;
      halfN = n/2;
      for(i = 0; i < numBV/4; i++)
	{
	  bvz = i;
	  j = 4*i;
	  bv[j][0] = halfM - 1;
	  bv[j][1] = halfN - 1;
	  bv[j][2] = bvz;

	  bv[j + 1][0] = halfM - 1;
	  bv[j + 1][1] = halfN;
	  bv[j + 1][2] = bvz;

	  bv[j + 2][0] = halfM;
	  bv[j + 2][1] = halfN - 1;
	  bv[j + 2][2] = bvz;

	  bv[j + 3][0] = halfM;
	  bv[j + 3][1] = halfN;
	  bv[j + 3][2] = bvz;
	}
    }

        break;

case domainedge:
        //TODO
        //See note in ComputeBorder().
        assert(false);
        for(i = 0; i < m; i++){
            for(j = 0; j < n; j++){
                for(k = 0; k < b; k++){
                    if(i == 0 || i == m-1 || j == 0 || j == n-1 || k == 0 || k == b-1){
                        domain[i][j][k].value = 0;
                    }
                }
            }
        }
        break;
    default:
        assert(false);
        break;
    }
    for(i = 0; i < numBV; i++)
    {
        bvx = bv[i][0];
        bvy = bv[i][1];
        bvz = bv[i][2];
        UnlockNeighbors(domain,bvx,bvy,bvz);
        /*for(j = 0; j < 6; j++)
            {
                x = bvx + neighborVec[j][0];
                y = bvy + neighborVec[j][1];
                z = bvz + neighborVec[j][2];
                inBounds = (x >= 0 && z >= 0 && y >= 0 && z < b && x < m && y < n);
                if(inBounds && domain[x][y][z].status != ACCEPTED)
                    domain[x][y][z].isLocked = false;

            }*/
    }
    for(i = 0; i < numBV; i++)
        delete [] bv[i];
    delete [] bv;
}

DOUBLE FastMarchingMethod(FMMGridpoint ***domain, HeapGeneral<FMMGridpoint> *Considered)
{
    /*At each iteration of the algorithm,
  -the fmmNode q at the top of the heap is removed
  -the neighbors of q get their value recomputed according to the PDE
    -if the value of a neighbor changes, its position on the heap needs to be updated.
  -if the neighbor fmmNode wasn't on the heap before, it's put onto the heap and the heap needs to be balanced.

  The maintenance of the heap is handled by the member functions Considered_List::downheap() and
  Considered_List::upheap().  These are both in the file FMMclasses.h.

  NeighborVec ordering is left right back front bottom top.
  */

  //  double avgHeapSize = 0;
    int heapcounter = 0;
    int neighborVec[6][3];
    int x,y,z,i,xcount, ycount, zcount;
    DOUBLE tempVal;
#ifndef OLD_INC_L
    DOUBLE neighb2Val, neighb3Val;
#endif

    FMMGridpoint* root;
    FMMGridpoint* zBar;
    FMMGridpoint* domainBegins = &domain[0][0][0];
    SetNeighborVec(neighborVec);

    while(Considered->currently_used != 0) //While L  is nonempty.
    {
      
      // if(Considered->currently_used > heapcounter)
      //    heapcounter = Considered->currently_used;

      //avgHeapSize += (double)Considered->currently_used / (m*n*b);
        root = Considered->L[0];
        root->status = ACCEPTED;
        Considered->downheap();
        xcount = root->getx(domainBegins);
        ycount = root->gety(domainBegins);
        zcount = root->getz(domainBegins);

        root->status = ACCEPTED;

        for(i = 0; i < 6; i++)
        {
            x = xcount + neighborVec[i][0];
            y = ycount + neighborVec[i][1];
            z = zcount + neighborVec[i][2];
            //See params3D.h: loc_flag for ordering of neighbors.
            if(x >= 0 && x < m && y >=0 && y < n && z >= 0 && z < b)
            {
                zBar = &domain[x][y][z];
                if(zBar->status == CONSIDERED && zBar->value > root->value)
                {
#ifdef OLD_INC_L
		  if(root->value >= inf) //June 2013: for impermeable barriers
		    tempVal = inf;
		  else
                    tempVal = UpdateNode(domain,x,y,z);
#else
		    if(i < 3) //root is left or right of zBar.
		      {
			neighb2Val = SmallerYNeighbor(domain,x,y,z);
			neighb3Val = SmallerZNeighbor(domain,x,y,z);
		      }
		    else if (i < 5) //root is back or front of zBar.
		      {
		       	neighb2Val = SmallerXNeighbor(domain,x,y,z);
			neighb3Val = SmallerZNeighbor(domain,x,y,z);
		      }
		    else //root is bottom or top of zBar.
		      {
			neighb2Val = SmallerXNeighbor(domain,x,y,z);
			neighb3Val = SmallerYNeighbor(domain,x,y,z);
		      }
		    tempVal = updateNodeFMM(x,y,z,root->value,neighb2Val, neighb3Val, zBar->value);
#endif
                    if(tempVal < zBar->value)
                    {
                        zBar->value = tempVal;
                        Considered->upheap(zBar->offset);
                    }
                }
                else if(zBar->status == FAR)
		  {
#ifdef OLD_INC_L
                    Incorporate_Into_L(domain,Considered,x,y,z, root->value);
#else
		    Incorporate_Into_L(zBar,Considered,x,y,z, root->value);
#endif
		  }
            }
        }
    }//end while
    //cout<<"Avg Heap Size: "<<avgHeapSize<<endl;
    //return avgHeapSize;
    return 0;
}




//////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////

int FastSweepingMethod(FSMGridpoint*** domain)
{

    //See Othercommon.h: SetSweepDirs() for sweep ordering.
    int i,j, k, numSweeps, numChanging;
    bool changing = true;
    DOUBLE temp;
    DOUBLE maxChange, percentChanging, zbarOld;
    numSweeps = 0;
    int maxSweep = (int)inf;
    FSMGridpoint* zbar;
    SweepData possibleSweeps[8];

    SetSweepDirs(0,m-1,0,b-1,0,n-1,possibleSweeps);
    SweepData* currentSweep;
    int incrementI, incrementJ, incrementK;

    while(changing && (numSweeps < maxSweep))
    {
        changing = false;
        currentSweep = &possibleSweeps[numSweeps%8];
        incrementI = currentSweep->iInc;
        incrementJ = currentSweep->jInc;
        incrementK = currentSweep->kInc;

        maxChange = 0;
        numChanging = 0;
        for(i = currentSweep->iStart; i != currentSweep->iEnd + incrementI; i = i + incrementI)
        {
            for(j = currentSweep->jStart; j != currentSweep->jEnd + incrementJ; j = j + incrementJ)
            {
                for(k = currentSweep->kStart; k != currentSweep->kEnd + incrementK; k = k + incrementK)
                {
                    zbar = &domain[i][j][k];
		    zbarOld = zbar->value;
                    temp = UpdateNode(domain,i,j,k);
                    if(temp < zbarOld)
                    {
		      //numChanging++;
		      //maxChange = Max(maxChange, (zbar->value - temp));
		      zbar->value = temp;
		     
		      if(temp + sweepTerminationThresh < zbarOld)
			{
			  changing = true;
			}
                    }
                }
            }
        }
        numSweeps++;
        //percentChanging = 100*(DOUBLE)numChanging/(m*n*b);
        //cout<<numSweeps<<". "<<maxChange<<"        "<<percentChanging<<" %"<<endl;
    }
    return numSweeps;
}

int LockingSweepingMethod(LSMGridpoint*** domain)
{

    //See Othercommon.h: SetSweepDirs() for sweep ordering.
  //Note that early termination condition doesn't affect whether neighbors are unlocked.

    int i,j, k, numSweeps, numChanging;
    bool changing = true;
    bool printSweepConvergence = false;
    ofstream texFile;
    DOUBLE temp;
    DOUBLE maxChange, percentChanging, zbarOld;
    numSweeps = 0;
    int maxSweep = (int)inf;
    DOUBLE thresh = 0;//1e-6;//+ pow(10,-trialNum-5);
    //cout<<"Termination criterion: "<<thresh<<endl;
    LSMGridpoint* zbar;

    SweepData possibleSweeps[8];
    SetSweepDirs(0,m-1,0,b-1,0,n-1,possibleSweeps);
    SweepData* currentSweep;

    int incrementI, incrementJ, incrementK;
    if(printSweepConvergence)
      {
	texFile.open("sweep_Analysis.txt");
	texFile<<setprecision(3);
	texFile<<"\\begin{table}[h] \\footnotesize"<<endl;
	//texFile<<"\\begin{center}"<<endl;
	texFile<<"\\caption{Performance analysis of HCM and pHCM for $F ";
	texFile<<"= 1 + .5\\sin(20\\pi x)\\sin(20\\pi y)\\sin(20\\pi z)$.}"<<endl; 

	texFile<<"\\vspace*{2mm}"<<endl;
	texFile<<"\\begin{tabular}{|c|c|c|}"<<endl;
	texFile<<"\\hline"<<endl;
	texFile<<" \\textbf{sweep \\#} & \\textbf{max change} & \\textbf{\\% grid changing} \\\\ ";
	texFile<<endl<<"\\hline"<<endl;
      }



    while(changing && (numSweeps < maxSweep))
    {
        changing = false;
        currentSweep = &possibleSweeps[numSweeps%8];
        incrementI = currentSweep->iInc;
        incrementJ = currentSweep->jInc;
        incrementK = currentSweep->kInc;

        maxChange = 0;
        numChanging = 0;
        for(i = currentSweep->iStart; i != currentSweep->iEnd + incrementI; i = i + incrementI)
        {
            for(j = currentSweep->jStart; j != currentSweep->jEnd + incrementJ; j = j + incrementJ)
            {
                for(k = currentSweep->kStart; k != currentSweep->kEnd + incrementK; k = k + incrementK)
                {
                    zbar = &domain[i][j][k];
                    if(!zbar->isLocked)
                    {
                        zbar->isLocked = true;
			zbarOld = zbar->value;
                        temp = UpdateNode(domain,i,j,k);
			if(temp < zbar->value)
			  {
			    zbar->value = temp;
			    UnlockNeighbors(domain,i,j,k);
			    numChanging++;
			    maxChange = Max(maxChange, (zbarOld - zbar->value));
			  }

                        if(temp + sweepTerminationThresh < zbarOld)
			  {
			    changing = true;
			  }
                    }
                }
            }
        }
        numSweeps++;
	percentChanging = 100*(DOUBLE)numChanging/(m*n*b);
        //cout<<numSweeps<<". "<<maxChange<<"        "<<percentChanging<<" %"<<endl;
	if(printSweepConvergence)
	  {
	    texFile<<numSweeps<<" & "<<maxChange<<" & "<<percentChanging<<"\\\\"<<endl<<"\\hline ";

	  }

    }

    if(printSweepConvergence)
      {
	//texFile<<"\\hline"<<endl;
	texFile<<endl<<"\\end{tabular}"<<endl;
	//texFile<<"\\end{center}"<<endl<<endl;
	texFile<<"\\end{table}"<<endl;
	texFile.close();
      }
    
    return numSweeps;
}



////////////////////////////////////////////////////////////////////////
template <class T, class U>
        void Compare(T ***fmmdomain, U ***fsmdomain)
{
    DOUBLE maxDiff = 0;
    DOUBLE temp, dist;// tempDist;
    int i,j,k;
    int maxI = -1;
    int maxJ = -1;
    int maxK = -1;
    dist = inf;
    //int numDiffCount = 0;

    for(i = 0; i < m; i++)
    {
        for(j = 0; j < n; j++)
        {
            for(k = 0; k < b; k++)
            {
                temp = fabs(fmmdomain[i][j][k].value - fsmdomain[i][j][k].value);
                //temp[i][j][k] = fmmdomain[i][j][k].value - fsmdomain[i][j][k].value;


                /*               if(temp > 0){
                    numDiffCount++;
                    cout<<numDiffCount<<". ";
                    cout<<setprecision(16)<<"fmm["<<i<<"]["<<j<<"]["<<k<<"]: "<<fmmdomain[i][j][k].value<<",  ";
                    cout<<setprecision(16)<<"fsm["<<i<<"]["<<j<<"]["<<k<<"]: "<<fsmdomain[i][j][k].value<<endl;
                }
                */

                /*
                tempDist = sqrt((i-23.5)*(i-23.5) + (j-23.5)*(j-23.5) + (k-23.5)*(k-23.5));

                if( temp > 0 && tempDist < dist)//find the point closest to the exit set that has a difference.
                {
                    maxI = i;
                    maxJ = j;
                    maxK = k;
                    dist = tempDist;
                }*/


                if(temp > maxDiff)
                {
                    maxI = i;
                    maxJ = j;
                    maxK = k;
                    maxDiff = temp;
                }
            }
        }
    }
    //cout<<"Difference closest to exit point: "<<dist;
    cout<<"Max Difference: "<<maxDiff;
    cout<<" at ("<<maxI<<","<<maxJ<<","<<maxK<<")"<<endl;
    if(maxI >= 0 && maxJ >= 0 && maxK >= 0)
    {
        cout<<"Method 1 val: "<<setprecision(16)<<fmmdomain[maxI][maxJ][maxK].value<<endl;
        cout<<"Method 2 val: "<<fsmdomain[maxI][maxJ][maxK].value<<endl;
    }

}
template <class GPs>
        void CheckAgainstExact(GPs ***domain)
{
    //this function checks against the exact solution ONLY for speed f(x,y,z) = 1 everywhere.
    //and exit set in the center
    assert(speed_fun == constantf);

    DOUBLE maxDiff = 0;
    DOUBLE temp,exact;
    int i,j,k;
    int maxI = -1;
    int maxJ = -1;
    int maxK = -1;
    
    for(i = 0; i < m; i++)
    {
        for(j = 0; j < n; j++)
        {
            for(k = 0; k < b; k++)
            {
                exact = twonorm(hx*i - .5,hy*j - .5,hz*k - .5);
                temp = fabs(domain[i][j][k].value - exact);
                if(temp > maxDiff)
                {
                    maxI = i;
                    maxJ = j;
                    maxK = k;
                    maxDiff = temp;
                }
            }
        }
    }
    cout<<"L_infinity error against true solution: "<<maxDiff<<endl;
    //cout<<"at (i,j,k) = ("<<maxI<<","<<maxJ<<","<<maxK<<")"<<endl;

}

template <class GPs>
        void CheckSymmetry(GPs*** domain)
{
    //This function should only be called for certain speed functions.
    assert(exit_set == center);
    assert(b%2 == 0);

    //For now I will ony check symmetries about the z = .5 plane, for debugging reasons.

    DOUBLE temp,exact;
    int i,j,k;
    int nonSymmetric = 0;

    for(i = 0; i < m; i++)
    {
        for(j = 0; j < n; j++)
        {
            for(k = 0; k < b/2 - 1; k++)
            {
                exact = twonorm(hx*i,hy*j,hz*k);
                temp = fabs(domain[i][j][k].value - domain[i][j][b - k -1].value);
                if(temp > eps )
                {
                    cout<<"("<<i<<","<<j<<","<<k<<"): "<<domain[i][j][k].value<<"  ";
                    cout<<"("<<i<<","<<j<<","<<b-k-1<<"): "<<domain[i][j][b-k -1].value<<endl;
                    nonSymmetric++;
                }
            }
        }
    }
    cout<<endl;
}
