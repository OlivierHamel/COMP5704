  /*
  * =====================================================================================
  *
  *  This program is free software: you can redistribute it and/or modify
  *  it under the terms of the GNU General Public License as published by
  *  the Free Software Foundation, either version 3 of the License, or
  *  (at your option) any later version.
  *
  *  This program is distributed in the hope that it will be useful,
  *  but WITHOUT ANY WARRANTY; without even the implied warranty of
  *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  *  GNU General Public License for more details.
  *
  *  You should have received a copy of the GNU General Public License
  *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
  *
  * -------------------------------------------------------------------------------------
  *
  *       Filename:  GlobalConfiguration.h
  *
  *        Version:   1.0
  *        Created:   6/18/13
  *        Revision:  none
  *        Compiler:  gcc/intel compiler
  *        Author:    Adam Chacon, adamdante@gmail.com
  *                   Cornell University
  *
  *        This file is a part of the numerical methods implementation/
  *        benchmarking described in the following article:
  *
  *	   http://www.math.cornell.edu/~vlad/papers/pHCM/
  *
  *	   The HCM and pHCM algorithms were developed by A. Chacon and 
  *	   A. Vladimirsky.
  *
  * =====================================================================================
  */


#ifndef GLOBALCONFIGURATION_H
#define GLOBALCONFIGURATION_H

 

#ifdef _DEBUGMODE

#define ASSERT(X) assert(X)

//#define DOUBLE     double


#else

#define DOUBLE  double

#define ASSERT(X)

#endif

//#define UNSAFE_COMP_THREE 1

//#define NUMERICAL_TINKER_COMP2NEIGHB 1


#define LSM_in_Cells 1

#define OLD_INC_L 1 

#define NEW_CELL_VAL 1



//#define HARDCODED_UNIT_SPEED 1

//#define CONST_THREADS 1

#endif // GLOBALCONFIGURATION_H

