  /*
  * =====================================================================================
  *
  *  This program is free software: you can redistribute it and/or modify
  *  it under the terms of the GNU General Public License as published by
  *  the Free Software Foundation, either version 3 of the License, or
  *  (at your option) any later version.
  *
  *  This program is distributed in the hope that it will be useful,
  *  but WITHOUT ANY WARRANTY; without even the implied warranty of
  *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  *  GNU General Public License for more details.
  *
  *  You should have received a copy of the GNU General Public License
  *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
  *
  * -------------------------------------------------------------------------------------
  *
  *       Filename:  ExternVars.h
  *
  *        Version:   1.0
  *        Created:   6/18/13
  *        Revision:  none
  *        Compiler:  gcc/intel compiler
  *        Author:    Adam Chacon, adamdante@gmail.com
  *                   Cornell University
  *
  *        This file is a part of the numerical methods implementation/
  *        benchmarking described in the following article:
  *
  *	   http://www.math.cornell.edu/~vlad/papers/pHCM/
  *
  *	   The HCM and pHCM algorithms were developed by A. Chacon and 
  *	   A. Vladimirsky.
  *
  * =====================================================================================
  */


#ifndef EXTERNVARS_H
#define EXTERNVARS_H



#include "params3D.h"
#include "GlobalConfiguration.h"
#include "GlobalVars3D.h"

extern exits exit_set;
extern speeds speed_fun;
extern int m; //# x gridpoints
extern int n; //#y gridpoints
extern int b; //#z gridpoints
extern int cm; //#x cells
extern int cn; //#y cells
extern int cb; //#z cells

extern int cellDepth;
extern int cellWidth;
extern int cellHeight;


extern DOUBLE checkerdimx;
extern DOUBLE checkerdimy;
extern DOUBLE checkerdimz;
extern int numcheckers;
extern DOUBLE hx;
extern DOUBLE hy;
extern DOUBLE hz;
extern DOUBLE chx;
extern DOUBLE chy;
extern DOUBLE chz;

extern DOUBLE threshConst;

#ifndef CONST_THREADS
extern int numthreads;
#endif

extern int CompUCounter3;
extern int CompUCounter2;
extern int CompUCounter1;
extern int TwoSidedCounter;
#endif // EXTERNVARS_H
