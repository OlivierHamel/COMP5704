  /*
  * =====================================================================================
  *
  *  This program is free software: you can redistribute it and/or modify
  *  it under the terms of the GNU General Public License as published by
  *  the Free Software Foundation, either version 3 of the License, or
  *  (at your option) any later version.
  *
  *  This program is distributed in the hope that it will be useful,
  *  but WITHOUT ANY WARRANTY; without even the implied warranty of
  *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  *  GNU General Public License for more details.
  *
  *  You should have received a copy of the GNU General Public License
  *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
  *
  * -------------------------------------------------------------------------------------
  *
  *       Filename:  HeapCellMethod.cpp
  *
  *        Version:   1.0
  *        Created:   6/18/13
  *        Revision:  none
  *        Compiler:  gcc/intel compiler
  *        Author:    Adam Chacon, adamdante@gmail.com
  *                   Cornell University
  *
  *        This file is a part of the numerical methods implementation/
  *        benchmarking described in the following article:
  *
  *	   http://www.math.cornell.edu/~vlad/papers/pHCM/
  *
  *	   The HCM and pHCM algorithms were developed by A. Chacon and 
  *	   A. Vladimirsky.
  *
  *        The function ComputeCellVal() was used only in section 6.8 of the paper;
  *	   the precompiler macro in GlobalConfiguration.h can be set to use this
  *	   function.
  *
  *
  *
  * =====================================================================================
  */


#include "HeapCellMethod.h"


int monotonicityCount = 0; //# times monotonicity function was called.
int singleSuccess = 0; //#times single monotonicty on a cube face was passed (two sweep directions tagged)
int DOUBLESuccess = 0; //#times DOUBLE monotonicity was passed (one sweep direction tagged).



void SetCellGlobals(int numCells)
{
    //numCells is the number of cells desired per domain side.
    cm = numCells;
    cn = numCells;
    cb = numCells;
    assert(m%cm == 0);
    int npc = m/cm;
    cellWidth = npc;
    cellDepth = npc;
    cellHeight = npc;
    chx = (maxx - minx)/(DOUBLE)(cm);
    chy = (maxy - miny)/(DOUBLE)(cn);
    chz = (maxz - minz)/(DOUBLE)(cb);
}


bool Sweep(LSMGridpoint ***finedomain, SweepData* currentSweep, bool whichneighbors[6], int boundaries[6], DOUBLE maxBorderGPs[6])
{
    int i, j, k, iInc, jInc, kInc;
    bool changing = false;
    DOUBLE temp, zBarOld;
    DOUBLE thresh = 0;//1e-6;
    LSMGridpoint* zBar;
    iInc = currentSweep->iInc;
    jInc = currentSweep->jInc;
    kInc = currentSweep->kInc;

    for(i = currentSweep->iStart; i != currentSweep->iEnd + iInc; i = i + iInc)
    {
        for(j = currentSweep->jStart; j != currentSweep->jEnd + jInc; j = j + jInc)
        {
            for(k = currentSweep->kStart; k != currentSweep->kEnd + kInc; k = k + kInc)
            {
	      zBar = &finedomain[i][j][k];
#ifdef LSM_in_Cells
	      if(!zBar->isLocked)
		{
		  zBar->isLocked = true;
#endif
		  zBarOld = zBar->value;
		  temp = UpdateNode(finedomain,i,j,k);
		  if(temp < zBarOld)
		    {
		      zBar->value = temp;
#ifdef LSM_in_Cells
		      UnlockNeighbors(finedomain,i,j,k,whichneighbors,boundaries, maxBorderGPs,zBarOld);
#else
		      if(i == currentSweep->iStart || i == currentSweep->iEnd || j == currentSweep ->jStart || j == currentSweep ->jEnd || k == currentSweep ->kEnd || k == currentSweep -> kStart)
			UnlockNeighbors(finedomain,i,j,k,whichneighbors,boundaries, maxBorderGPs, zBarOld);
#endif
		    }
		  if(temp + sweepTerminationThresh < zBarOld)
		    {
		      changing = true;
		      
		    }
#ifdef LSM_in_Cells
		}
#endif
            }
        }
    }
    return changing;
}



int HCMAlgorithm(cell ***celldomain, LSMGridpoint ***finedomain, bool isFast, double* cellExclTime)
{
  double debugTime = 0;
  double dummy_debugTime = 0;
  double dT,dummy_dT;
  
  
  HeapGeneral<cell>* Considered = new HeapGeneral<cell>;
  Considered->Initialize(cm*cn*cb);
  
  InitializeCells(celldomain, Considered);
  
  cell* q;
  cell* c;
  int cellx,celly, cellz, x,y,z,i, totalSweeps;
  int k = 0;
  totalSweeps = 0;
  bool whichNeighbors[6];
  DOUBLE maxBorderGPs[6];
  int neighborVec[6][3];
  DOUBLE temp;
  SetNeighborVec(neighborVec);
  
  while(Considered->currently_used > 0)
    {
      /*
        cout<<"k = "<<k<<endl;
        printHeap(Considered,celldomain);
        cin>>wait;
      */
      q = Considered->L[0];
      cellx = q->getx(&celldomain[0][0][0]);
      celly = q->gety(&celldomain[0][0][0]);
      cellz = q->getz(&celldomain[0][0][0]);
      
      //q = &celldomain[cellx][celly][cellz];
      Considered->downheap();
      //q->status = OUT;
#ifdef NEW_CELL_VAL
      //q->SetVal(inf);
      celldomain[cellx][celly][cellz].value = inf;
#endif
      celldomain[cellx][celly][cellz].status = OUT;


      
      for(i = 0; i < 6; i++)
	{
	  whichNeighbors[i] = false;
#ifdef NEW_CELL_VAL
	  maxBorderGPs[i] = inf;
#else
	  maxBorderGPs[i] = -1;
#endif
	}
      if(isFast)
	totalSweeps += FastCellCompute(celldomain,finedomain,cellx,celly,cellz,whichNeighbors,maxBorderGPs);
      else
	{
	  totalSweeps += SlowCellCompute(celldomain,finedomain,cellx,celly,cellz, whichNeighbors,&dT,&dummy_dT, maxBorderGPs);
	  debugTime += dT;
	  dummy_debugTime += dummy_dT;
	  
	}
      for(i = 0; i < 6; i++)
        {
	  if(whichNeighbors[i])
            {
	      //whichNeighbors[i] should be set to true only if the neighbor is in bounds and has a downwinding fine
	      //node.
	      //whichNeighbors order and neighborVec order is coordinated.
	      
	      x = cellx + neighborVec[i][0];
	      y = celly + neighborVec[i][1];
	      z = cellz + neighborVec[i][2];
	     
	      c = &celldomain[x][y][z];

	      //5/29/13:
	      ASSERT(maxBorderGPs[i] != -1);
#ifdef NEW_CELL_VAL
	      temp = maxBorderGPs[i];
#else
	      temp = ComputeCellVal(finedomain, cellx,celly,cellz,(loc_flag)i, maxBorderGPs[i]);
#endif	      

	      if(temp < c->value)
                {
		  c->value = temp;
		  if(c->status == IN)
		    Considered->upheap(c->offset);
                }
	     
	      UpdateSweepDirections(c, finedomain, isFast,(loc_flag)i,celldomain);
	      if(c->status == OUT)
		Considered->add(c);
            }
        }
      k++;
    }
  
    if(isFast)
      {
        cout<<"Monotonicity percentage single: "<<100*(DOUBLE)(singleSuccess)/(monotonicityCount);
        cout<<"   DOUBLE: "<<100*(DOUBLE)(DOUBLESuccess)/(monotonicityCount)<<endl;
      }
    //cout<<"Average # sweeps per cell: "<<(DOUBLE)totalSweeps/(DOUBLE)(cm*cn*cb)<<endl;
    
    *cellExclTime = debugTime;
    delete Considered;
    
    //return k;
    return totalSweeps;
}





loc_flag ConvertNeighborVec(int i, int neighborVec[6][3])
{
    //This function assumes, for each i, neighborVec[i][j] is nonzero for only one j.
    loc_flag returnVar;
    if(neighborVec[i][0] != 0)
    {
        if(neighborVec[i][0] == 1)
            returnVar = RIGHT;
        else
        {
            if(neighborVec[i][0] == -1)
                returnVar = LEFT;
            else
                assert(false);
        }

    }
    else
    {
        if(neighborVec[i][1] != 0)
        {
            if(neighborVec[i][1] == 1)
                returnVar = FRONT;
            else
            {
                if(neighborVec[i][1] == -1)
                    returnVar = BACK;
                else
                    assert(false);
            }
        }
        else
        {
            if(neighborVec[i][2] != 0)
            {
                if(neighborVec[i][2] == 1)
                    returnVar = TOP;
                else
                {
                    if(neighborVec[i][2] == -1)
                        returnVar = BOTTOM;
                    else
                        assert(false);
                }
            }
            else
                assert(false);
        }
    }
    return returnVar;
}

loc_flag ReverseLocFlag(loc_flag current)
{
    loc_flag returnVar;

    switch(current)
    {
    case TOP:
        returnVar = BOTTOM;
        break;
    case BOTTOM:
        returnVar = TOP;
        break;
    case LEFT:
        returnVar = RIGHT;
        break;
    case RIGHT:
        returnVar = LEFT;
        break;
    case FRONT:
        returnVar = BACK;
        break;
    case BACK:
        returnVar = FRONT;
        break;
    default:
        assert(false);
        break;
    }

    return returnVar;
}



/*Old "geometrically intuitive" cell value computation 5/29/13.   */
DOUBLE ComputeCellVal(LSMGridpoint ***finedomain,
                      int x, int y, int z, loc_flag location, DOUBLE maxBorderGP)
{


    DOUBLE ch = chx;
    DOUBLE ch2 = ch/2.0;
    DOUBLE D;
    DOUBLE h = hx;
    DOUBLE speed, centerX, centerY, centerZ;
    D = (ch + h)/2.0 ;

    //Note: the center variables are for the center of the downwinding cell (the one who's value we are computing).
 

    switch(location)
    {
    case LEFT:
      ASSERT(x > 0);

      centerX = x*ch - ch2;
      centerY = y*ch + ch2;
      centerZ = z*ch + ch2;
      
      break;
	
    case RIGHT:
      ASSERT(x < cm - 1);
      
      centerX = x*ch + 3*ch2;
      centerY = y*ch + ch2;
      centerZ = z*ch + ch2;
      
      break;
      
    case BACK:
      ASSERT(y > 0);

      centerX = x*ch + ch2;
      centerY = y*ch - ch2;
      centerZ = z*ch + ch2;
      
      break;
	
    case FRONT:
      ASSERT(y < cn - 1);

      centerX = x*ch + ch2;
      centerY = y*ch + 3*ch2;
      centerZ = z*ch + ch2;
      
      break;

    case BOTTOM:
      ASSERT(z > 0);

      centerX = x*ch + ch2;
      centerY = y*ch + ch2;
      centerZ = z*ch - ch2;
      
      break;
      
    case TOP:
      ASSERT(z < cb - 1);

      centerX = x*ch + ch2;
      centerY = y*ch + ch2;
      centerZ = z*ch + 3*ch2;

      break;

        default:
        assert(false);
        break;
    }

    speed = getspeed(centerX,centerY,centerZ);

#ifdef NEW_CELL_VAL
    return maxBorderGP;
#else
    return maxBorderGP + D/speed; //here "minBorderGP" is actually "maxBorderGP"
#endif
}



