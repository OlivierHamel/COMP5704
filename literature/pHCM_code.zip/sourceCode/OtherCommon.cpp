  /*
  * =====================================================================================
  *
  *  This program is free software: you can redistribute it and/or modify
  *  it under the terms of the GNU General Public License as published by
  *  the Free Software Foundation, either version 3 of the License, or
  *  (at your option) any later version.
  *
  *  This program is distributed in the hope that it will be useful,
  *  but WITHOUT ANY WARRANTY; without even the implied warranty of
  *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  *  GNU General Public License for more details.
  *
  *  You should have received a copy of the GNU General Public License
  *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
  *
  * -------------------------------------------------------------------------------------
  *
  *       Filename:  OtherCommon.cpp
  *
  *        Version:   1.0
  *        Created:   6/18/13
  *        Revision:  none
  *        Compiler:  gcc/intel compiler
  *        Author:    Adam Chacon, adamdante@gmail.com
  *                   Cornell University
  *
  *        This file is a part of the numerical methods implementation/
  *        benchmarking described in the following article:
  *
  *	   http://www.math.cornell.edu/~vlad/papers/pHCM/
  *
  *	   The HCM and pHCM algorithms were developed by A. Chacon and 
  *	   A. Vladimirsky.
  *
  * =====================================================================================
  */


#include <iostream>
#include "OtherCommon.h"
#include <math.h>
#include <assert.h>

using namespace std;

/*    //DOUBLE pi = 3.141592653589793238462643383; */

void print_params(param_struct params)
{
    cout<<endl<<"Size of domain: "<<m<<" by "<<n<<" by "<<b<<" = "<<m*n*b<<" gridpoints."<<endl;
    cout<<"Speed: ";
    switch(params.sp){
    case combmaze2:
        cout<<"Comb Maze 2 barriers"<<endl; break;
    case combmaze4:
        cout<<"Comb Maze 4 barriers"<<endl; break;
    case combmaze6:
        cout<<"Comb Maze 6 barriers"<<endl; break;
    case constantf:
        cout<<"f constant"<<endl; break;
    case sinusoid1:
        cout<<"f(x,y,z) = 1 + .5*sin(20*pi*x)*sin(20*pi*y)*sin(20*pi*z)"<<endl; break;
    case sinusoid2:
        cout<<"f(x,y,z) = 1 + .99*sin(2*pi*x)*sin(2*pi*y)*sin(2*pi*z)"<<endl; break;
    case checkerboard:
        cout<<"Checkerboard"<<endl; break;
    case blob:
        cout<<"Center blob"<<endl;break;
    case generalf:
        //assert(params.ex == domainedge);
        cout<<"1/sqrt((x+1)*(x+1) + (y+1)*(y+1))"<<endl; break;
    case shellMaze:
      if(barrierSpeed == 0)
      cout<<"Shell Maze 4 (impermeable) barriers"<<endl; 
      else
	cout<<"Shell Maze 4 (permeable) barriers"<<endl; 
      break;
    }
    if(params.sp == checkerboard)
        cout<<"NumCheckers = "<<params.nc<<endl;
    cout<<"Exit Set: ";
    switch(params.ex){
    case lowerleftcorner:
        cout<<"Lower Left Corner"<<endl; break;
    case center:
        cout<<"Center"<<endl; break;
    case domainedge:
        //assert(params.sp == generalf);
        cout<<"Boundary of domain"<<endl; break;
    case zaxis:
        cout<<"Z axis"<<endl; break;
    }
    //cout<<"Thresh Const: "<<threshConst<<endl;
    cout<<"--------------------------------------------"<<endl<<endl;
}

DOUBLE ComputeBorder(int i, int j, int k)
{
    /*This function is called by Initialize() and should only return 0 boundary data.
 If non-zero boundary data is needed, an "ACCEPTED" label will be needed to prevent the
 exit points from being re-added onto the queue.   */

    return 0;

}

DOUBLE twonorm(DOUBLE x, DOUBLE y, DOUBLE z)
{ //computes the 2-norm of a 3-vector

    return(sqrt(x*x + y*y + z*z));

}

/*Called by LSM and DetrixheLSM: */
void UnlockNeighbors(LSMGridpoint*** domain, int x, int y, int z)
{
    //This unlocks downwinding neighbors of a newly update node (x,y,z).
    //Called only by LSM.  Overloaded function name
    DOUBLE min = domain[x][y][z].value;
    if(x < m - 1 && min < domain[x+1][y][z].value)
        domain[x+1][y][z].isLocked = false;
    if(y < n - 1 && min < domain[x][y+1][z].value)
        domain[x][y+1][z].isLocked = false;
    if(z < b - 1 && min < domain[x][y][z+1].value)
        domain[x][y][z+1].isLocked = false;

    if(x > 0 && min < domain[x-1][y][z].value)
        domain[x-1][y][z].isLocked = false;
    if(y > 0 && min < domain[x][y-1][z].value)
        domain[x][y-1][z].isLocked = false;
    if(z > 0 && min < domain[x][y][z-1].value)
        domain[x][y][z-1].isLocked = false;

}



void printLevelSet(LSMGridpoint*** domain, DOUBLE level)
{
  int i,j,k;
  DOUBLE x,y,z;
  DOUBLE thickness = .15*hx;
  ofstream outFile;
  outFile.open("eikLevelSurf.m");

  outFile<<"L = [ "<<endl;
  for(i = 0; i < m; i++)
    {
      for(j = 0; j < n; j++)
	{
	  for(k = 0; k < b; k++)
	    {
	      if(fabs(domain[i][j][k].value - level) < thickness)
		{
		  x = i*hx + minx;
		  y = j*hy + miny;
		  z = k*hz + minz;
		  outFile<<x<<" "<<y<<" "<<z<<";";
		  outFile<<endl;
		}
	    }
	}
    }
  outFile<<"];"<<endl;
  outFile.close();

}


/*
void print(node ***domain,int rowlength, int collength)
{
    ofstream arrayfile;
    arrayfile.open("Test3.m");
    arrayfile<<"m = [  % speed = 1 "<<endl;
    for(int i = 0; i < rowlength; i++)
    {
        for(int j = 0; j < collength; j++)
            arrayfile<<setprecision(18)<<domain[i][j].u_value<<"  ";
        arrayfile<<endl;
    }
    arrayfile<<" ];"<<endl;
    arrayfile<<"m = m';";
    arrayfile<<"checkerdim = "<<(m-1)<<";"<<endl;
    arrayfile<<"n = "<<collength<<";"<<endl;
    arrayfile.close();
}
*/
void SetNeighborVec(int neighborVec[6][3])
{


    //right
    neighborVec[RIGHT][0] = 1;
    neighborVec[RIGHT][1] = 0;
    neighborVec[RIGHT][2] = 0;

    //forward
    neighborVec[FRONT][0] = 0;
    neighborVec[FRONT][1] = 1;
    neighborVec[FRONT][2] = 0;

    //left
    neighborVec[LEFT][0] = -1;
    neighborVec[LEFT][1] = 0;
    neighborVec[LEFT][2] = 0;

    //backward
    neighborVec[BACK][0] = 0;
    neighborVec[BACK][1] = -1;
    neighborVec[BACK][2] = 0;

    //up
    neighborVec[TOP][0] = 0;
    neighborVec[TOP][1] = 0;
    neighborVec[TOP][2] = 1;

    //down
    neighborVec[BOTTOM][0] = 0;
    neighborVec[BOTTOM][1] = 0;
    neighborVec[BOTTOM][2] = -1;

}

