  /*
  * =====================================================================================
  *
  *  This program is free software: you can redistribute it and/or modify
  *  it under the terms of the GNU General Public License as published by
  *  the Free Software Foundation, either version 3 of the License, or
  *  (at your option) any later version.
  *
  *  This program is distributed in the hope that it will be useful,
  *  but WITHOUT ANY WARRANTY; without even the implied warranty of
  *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  *  GNU General Public License for more details.
  *
  *  You should have received a copy of the GNU General Public License
  *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
  *
  * -------------------------------------------------------------------------------------
  *
  *       Filename:  HeapCellMethod.h
  *
  *        Version:   1.0
  *        Created:   6/18/13
  *        Revision:  none
  *        Compiler:  gcc/intel compiler
  *        Author:    Adam Chacon, adamdante@gmail.com
  *                   Cornell University
  *
  *        This file is a part of the numerical methods implementation/
  *        benchmarking described in the following article:
  *
  *	   http://www.math.cornell.edu/~vlad/papers/pHCM/
  *
  *	   The HCM and pHCM algorithms were developed by A. Chacon and 
  *	   A. Vladimirsky.
  *
  * =====================================================================================
  */


#ifndef HEAPCELLMETHOD_H
#define HEAPCELLMETHOD_H


#include "GlobalVars3D.h"
#include "GlobalConfiguration.h"
#include "ExternVars.h"
#include "params3D.h"
#include "OtherCommon.h"
#include "ComputeFuncs3D.h"
#include "GlobalConfiguration.h"
#include "HeapGeneral.h"
#include "Gridpoint.h"
#include <math.h>
#include <iostream>
#include "parallelHCM.h"
#include "omp.h"


using namespace std;

//The following variables live in HeapCellMethod.cpp.
extern int monotonicityCount; //# times monotonicity function was called.
extern int singleSuccess; //#times single monotonicty on a cube face was passed (two sweep directions tagged)
extern int DOUBLESuccess; //#times DOUBLE monotonicity was passed (one sweep direction tagged).


//For pHCM.cpp:
bool pHCM_Sweep(LSMGridpoint ***finedomain, SweepData* currentSweep, bool whichneighbors[6], int boundaries[6]);

void SetCellGlobals(int numCells);

int HCMAlgorithm(cell*** celldomain, LSMGridpoint*** finedomain, bool isFast, double* cellExclTime);

bool Sweep(LSMGridpoint ***finedomain, SweepData* currentSweep, bool whichneighbors[6], int boundaries[6], DOUBLE maxBorderGPs[6]);



DOUBLE ComputeCellVal(LSMGridpoint ***finedomain,
                      int x, int y, int z, loc_flag location, DOUBLE maxBorderGP);

loc_flag ConvertNeighborVec(int i, int neighborVec[6][3]);

loc_flag ReverseLocFlag(loc_flag current);




template <class T, class U>
  inline void InitializeCells(T*** domain, U* Considered)
{
  int i,j,k,bvx,bvy,bvz;
  int numCellBV;
  //int bv[100][3];
  int **bv;
  DOUBLE cubeCenter;
  
  for(i = 0; i < cm; i++)
    {
      for(j = 0; j < cn; j++)
        {
	  for(k = 0; k < cb; k++)
            {
	      domain[i][j][k].value = inf;
	      domain[i][j][k].offset = -1;
	      domain[i][j][k].status = OUT;
            }
        }
    }
  Considered->currently_used = 0;
  
  switch(exit_set)
    {
    case center:
      if(cm%2 == 0)
        {
	  cubeCenter = sqrt(3)*chx/2;
	  
	  numCellBV = 8;
	  bv = new int*[numCellBV];
	  for(i = 0; i < numCellBV; i++)
	    bv[i] = new int[3];
	  
	  bv[0][0] = cm/2;
	  bv[0][1] = cn/2;
	  bv[0][2] = cb/2;
	  
	  bv[1][0] = cm/2 - 1;
	  bv[1][1] = cn/2;
	  bv[1][2] = cb/2;
	  
	  bv[2][0] = cm/2;
	  bv[2][1] = cn/2 - 1;
	  bv[2][2] = cb/2;
	  
	  bv[3][0] = cm/2 - 1;
	  bv[3][1] = cn/2 - 1;
	  bv[3][2] = cb/2;
	  
	  bv[4][0] = cm/2;
	  bv[4][1] = cn/2;
	  bv[4][2] = cb/2 - 1;
	  
	  bv[5][0] = cm/2 - 1;
	  bv[5][1] = cn/2;
	  bv[5][2] = cb/2 - 1;
	  
	  bv[6][0] = cm/2;
	  bv[6][1] = cn/2 - 1;
	  bv[6][2] = cb/2 - 1;
	  
	  bv[7][0] = cm/2 - 1;
	  bv[7][1] = cn/2 - 1;
	  bv[7][2] = cb/2 - 1;
	  
	  for(i = 0; i < 8; i++)
            {
	      bvx = bv[i][0];
	      bvy = bv[i][1];
	      bvz = bv[i][2];
	      domain[bvx][bvy][bvz].value = cubeCenter;
            }
        }
      else
        {
	  numCellBV = 1;
	  bv = new int*[numCellBV];
	  for(i = 0; i < numCellBV; i++)
	    bv[i] = new int[3];
	  bvx = (int)(cm - 1)/2;
	  bvy = (int)(cn - 1)/2;
	  bvz = (int)(cb - 1)/2;
	  bv[0][0] = bvx;
	  bv[0][1] = bvy;
	  bv[0][2] = bvz;
	  domain[bvx][bvy][bvz].value = 0;
        }
      break;
      
    case lowerleftcorner:
        numCellBV = 1;
        bv = new int*[numCellBV];
        for(i = 0; i < numCellBV; i++)
	  bv[i] = new int[3];
        domain[0][0][0].value = 0;
        bv[0][0] = 0;
        bv[0][1] = 0;
        bv[0][2] = 0;
        break;
	
    case zaxis:
      assert(cm%2 == 1); //this assertion doesn't really need to be here.
      numCellBV = cb;
      bv = new int*[numCellBV];
      for(i = 0; i < numCellBV; i++)
	bv[i] = new int[3];
      
      for(i=0; i < cb; i++)
        {
	  bvx = (int)(cm - 1)/2;
	  bvy = (int)(cn - 1)/2;
	  bvz = i;
	  bv[i][0] = bvx;
	  bv[i][1] = bvy;
	  bv[i][2] = bvz;
	  domain[bvx][bvy][bvz].value = 0;
        }
      //numbv = cb;
      break;
      
    case domainedge:
      assert(false);
      break;
      
    default:
      assert(false);
      break;
    }
  
  for(i = 0; i < numCellBV; i++)
    {
      bvx = bv[i][0];
      bvy = bv[i][1];
      bvz = bv[i][2];
      Considered->add(&domain[bvx][bvy][bvz]);
      for(int j = 0; j < 8; j++)
	domain[bvx][bvy][bvz].sweepDirections[j] = true;
    }
  
  for(i = 0; i < numCellBV; i++)
    delete [] bv[i];
  delete [] bv;
}




template <class T>
inline int SlowCellCompute(T ***celldomain, LSMGridpoint ***finedomain, int x,
			   int y, int z, bool whichNeighbors[6],double* debugTimeOUT, double* dummy_debugTimeOUT, DOUBLE maxBorderGPs[6])
{
    //(x,y,z) = logical coordinates of a cell.
  double debugTime1, debugTime2;
  debugTime1 = omp_get_wtime();
  int i, sweepCounter, left, right, back, front, bottom, top, iterCount;
  int boundaries[6];
  bool changing = true;
  sweepCounter = 0;
  iterCount = 0;
  
    left = x*cellWidth;
    right = left + cellWidth - 1;
    back = y*cellDepth;
    front = back + cellDepth - 1;
    bottom = z*cellHeight;
    top = bottom + cellHeight - 1;

    boundaries[0] = left;
    boundaries[1] = right;
    boundaries[2] = back;
    boundaries[3] = front;
    boundaries[4] = bottom;
    boundaries[5] = top;

    SweepData possibleSweeps[8];
    SetSweepDirs(left,right,bottom,top,back,front,possibleSweeps);
    SweepData* currentSweep;

       
    for(i = 0; i < 8; i++) //sweep from the tagged directions first.
      {
        if(celldomain[x][y][z].sweepDirections[i] && changing)
	  {
            currentSweep = &possibleSweeps[i];
	    changing = Sweep(finedomain,currentSweep,whichNeighbors, boundaries, maxBorderGPs);
            sweepCounter++;
        }
    }
    while(changing)
    {
        for(i = 0; i < 8; i++)
        {
            if(changing)
            {
                if(iterCount == 0 && !celldomain[x][y][z].sweepDirections[i]) //now sweep from the non-tagged directions
                {
                    currentSweep = &possibleSweeps[i];
		    
		    changing = Sweep(finedomain,currentSweep,whichNeighbors, boundaries,maxBorderGPs);
                    sweepCounter++;
                }
                else if(iterCount > 0)
                {
		  currentSweep = &possibleSweeps[i];
		  
		  changing = Sweep(finedomain,currentSweep,whichNeighbors, boundaries,maxBorderGPs);
		  sweepCounter++;
                }
            }
        }
        iterCount++;
    }
    for(i = 0; i < 8; i++)
        celldomain[x][y][z].sweepDirections[i] = false;

    debugTime2 = omp_get_wtime();
    *debugTimeOUT = debugTime2 - debugTime1;
    
    return sweepCounter;
}

template <class T>
inline int FastCellCompute(T ***celldomain, LSMGridpoint ***finedomain, int x,
			   int y, int z, bool whichNeighbors[6], DOUBLE maxBorderGPs[6])
{

  /*Don't use this function. */
    int i, sweepCounter, left, right, back, front, bottom, top;
    bool changing = true;
    int boundaries[6];
    sweepCounter = 0;

    left = x*cellWidth;
    right = left + cellWidth - 1;
    back = y*cellDepth;
    front = back + cellDepth - 1;
    bottom = z*cellHeight;
    top = bottom + cellHeight - 1;

    boundaries[0] = left;
    boundaries[1] = right;
    boundaries[2] = back;
    boundaries[3] = front;
    boundaries[4] = bottom;
    boundaries[5] = top;

    SweepData possibleSweeps[8];
    SetSweepDirs(left,right,bottom,top,back,front,possibleSweeps);
    SweepData* currentSweep;

    for(i = 0; i < 8; i++)
    {
        if(celldomain[x][y][z].sweepDirections[i] && changing)
        {
            currentSweep = &possibleSweeps[i];
            changing = Sweep(finedomain,currentSweep,whichNeighbors, boundaries,maxBorderGPs);
            celldomain[x][y][z].sweepDirections[i] = false; //8/27/11
            sweepCounter++;
        }
    }
    /*for(i = 0; i < 8; i++)
        celldomain[x][y][z].sweepDirections[i] = false; */
    return sweepCounter;
}


inline void UnlockNeighbors(LSMGridpoint ***domain, int x, int y, int z, bool whichNeighbors[6],int boundaries[6], DOUBLE maxBorderGPs[6], DOUBLE oldVal)
{
    //This is an overloaded function.
    //This unlocks downwinding neighbors (for HCM) of a newly updated (fine) gridpoint (x,y,z)
    //This also sets whichNeighbors[].
  //5/29/13: This also sets maxBorderGPs[]
    /*The code for boundaries is:
      0.  left
      1.  right
      2.  back
      3.  front
      4.  bottom
      5.  top
*/
    DOUBLE min = domain[x][y][z].value;
    bool early = false;
#ifdef EARLY_SWEEP
    if(oldVal - min < sweepTerminationThresh)
      early = true;
#endif


#ifdef LSM_in_Cells

    if(x < m - 1 && min < domain[x+1][y][z].value)
    {
      domain[x+1][y][z].isLocked = false;
        if(!early && x == boundaries[RIGHT])
	  {
            whichNeighbors[RIGHT] = true;
#ifdef NEW_CELL_VAL
	    if(min < maxBorderGPs[RIGHT])
	      {
		maxBorderGPs[RIGHT] = min;
	      } 
#else
	    if(min > maxBorderGPs[RIGHT])
	      {
		maxBorderGPs[RIGHT] = min;
	      } 
#endif
	  }
    }

    if(y < n - 1 && min < domain[x][y+1][z].value)
    {
      domain[x][y+1][z].isLocked = false;


        if(!early && y == boundaries[FRONT])
	  {
            whichNeighbors[FRONT] = true;
#ifdef NEW_CELL_VAL
	    if(min < maxBorderGPs[FRONT])
	      {
		maxBorderGPs[FRONT] = min;
	      } 
#else
	    if(min > maxBorderGPs[FRONT])
	      {
		maxBorderGPs[FRONT] = min;
	      } 
#endif
	  }
    }

    if(z < b - 1 && min < domain[x][y][z+1].value)
    {
      domain[x][y][z+1].isLocked = false;
        if(!early && z == boundaries[TOP])
	  {
            whichNeighbors[TOP] = true;
#ifdef NEW_CELL_VAL
	    if(min < maxBorderGPs[TOP])
	      {
		maxBorderGPs[TOP] = min;
	      } 
#else	    
	    if(min > maxBorderGPs[TOP])
	      {
		maxBorderGPs[TOP] = min;
    
	      }
#endif	    
	  }
    }

    if(x > 0 && min < domain[x-1][y][z].value)
    {
      domain[x-1][y][z].isLocked = false;

        if(!early && x == boundaries[LEFT])
	  {
            whichNeighbors[LEFT] = true;
#ifdef NEW_CELL_VAL
	    if(min < maxBorderGPs[LEFT])
	      {
		maxBorderGPs[LEFT] = min;
	      } 
#else
	    if(min > maxBorderGPs[LEFT])
	      {
		maxBorderGPs[LEFT] = min;
		
	      } 
#endif
	  }
    }


    early = false;
    if(y > 0 && min < domain[x][y-1][z].value)
    {
      domain[x][y-1][z].isLocked = false;

        if(!early && y == boundaries[BACK])
	  {
            whichNeighbors[BACK] = true;
#ifdef NEW_CELL_VAL
	    if(min < maxBorderGPs[BACK])
	      {
		maxBorderGPs[BACK] = min;
	      } 
#else	   
	    if(min > maxBorderGPs[BACK])
	      {
		maxBorderGPs[BACK] = min;
		
	      } 
#endif
	  }
    }

    if(z > 0 && min < domain[x][y][z-1].value)
    {
      domain[x][y][z-1].isLocked = false;
        if(!early && z == boundaries[BOTTOM])
	  {
            whichNeighbors[BOTTOM] = true;
#ifdef NEW_CELL_VAL
	    if(min < maxBorderGPs[BOTTOM])
	      {
		maxBorderGPs[BOTTOM] = min;
	      } 
#else	 
	    if(min > maxBorderGPs[BOTTOM])
	      {
		maxBorderGPs[BOTTOM] = min;
	      } 
#endif
	  }
    }

    //FSM in cells:

#else
 if(!early && x == boundaries[RIGHT]  &&  x < m - 1 && min < domain[x+1][y][z].value)
   {
	whichNeighbors[RIGHT] = true;
	if(min < maxBorderGPs[RIGHT])
	  {
	    maxBorderGPs[RIGHT] = min;
   
	  }
   }
 if(!early && y == boundaries[FRONT] &&  y < n - 1 && min < domain[x][y+1][z].value)
   {
       whichNeighbors[FRONT] = true;
       if(min < maxBorderGPs[FRONT])
	 {
	   maxBorderGPs[FRONT] = min; 
    
	 }
   }
 if(!early && z == boundaries[TOP] && z < b - 1 && min < domain[x][y][z+1].value)
   {
       whichNeighbors[TOP] = true;
       if(min < maxBorderGPs[TOP])
	 {
	   maxBorderGPs[TOP] = min;
  
	 }
   }
 if(!early && x == boundaries[LEFT] && x > 0 && min < domain[x-1][y][z].value)
   {
     whichNeighbors[LEFT] = true;
     if(min < maxBorderGPs[LEFT])
       {
	 maxBorderGPs[LEFT] = min;
  
       }
   }
 if(!early && y == boundaries[BACK] && y > 0 && min < domain[x][y-1][z].value)
   {
     whichNeighbors[BACK] = true;
     if(min < maxBorderGPs[BACK])
       {
	 maxBorderGPs[BACK] = min;
 
       }
   }
 if(!early && z == boundaries[BOTTOM] && z > 0 && min < domain[x][y][z-1].value)
   {
     whichNeighbors[BOTTOM] = true;
     if(min < maxBorderGPs[BOTTOM])
       {
	 maxBorderGPs[BOTTOM] = min;
       }
   }
#endif
 
}

template <class T>  //TODO: another template parameter for parallelHCM to use.
inline void printHeap(HeapGeneral<cell>* Considered, T*** celldomain)
{
    /* Used for debugging. */

    int cellx, celly,cellz,k,i;
    cell* temp;
    k = 1;

    cell* beginning = &celldomain[0][0][0];
    for(i = 0; i < Considered->currently_used; i++)
    {
        temp = Considered->L[i];
        cellx = temp->getx(beginning);
        celly = temp->gety(beginning);
        cellz = temp->getz(beginning);
        cout<<k<<". ("<< cellx<<","<<celly<<", "<<cellz<<")"<<"  value = "<<temp->value<<endl;
        k++;
    }
    cout<<endl;
}

template <class T>
inline void UpdateSweepDirections(T *c, LSMGridpoint ***finedomain, bool isFast,
                           loc_flag whichNeighbor, T*** celldomain)
{
    //finedomain is only needed if isFast == true;
    //This function is called for each neigboring cell of a newly "accepted" cell.
    //c is located relative to the newly accepted cell in the position whichneighbor
    //The function assumed, however, that the opposite is true: that the newly accepted neighbor is
    //located relative to c in the position whichneighbor

    whichNeighbor = ReverseLocFlag(whichNeighbor);

    if(isFast)
        MonotonicityCheck(finedomain,c,whichNeighbor, celldomain);
    else
    {
        switch(whichNeighbor)
        {
        case TOP:
            c->sweepDirections[RightFrontTop] = true;
            c->sweepDirections[RightBackTop] = true;
            c->sweepDirections[LeftFrontTop] = true;
            c->sweepDirections[LeftBackTop] = true;
            break;
        case BOTTOM:
            c->sweepDirections[RightFrontBottom] = true;
            c->sweepDirections[RightBackBottom] = true;
            c->sweepDirections[LeftFrontBottom] = true;
            c->sweepDirections[LeftBackBottom] = true;
            break;
        case LEFT:
            c->sweepDirections[LeftFrontTop] = true;
            c->sweepDirections[LeftBackTop] = true;
            c->sweepDirections[LeftFrontBottom] = true;
            c->sweepDirections[LeftBackBottom] = true;
            break;
        case RIGHT:
            c->sweepDirections[RightFrontTop] = true;
            c->sweepDirections[RightBackTop] = true;
            c->sweepDirections[RightFrontBottom] = true;
            c->sweepDirections[RightBackBottom] = true;
            break;
        case FRONT:
            c->sweepDirections[LeftFrontTop] = true;
            c->sweepDirections[LeftFrontBottom] = true;
            c->sweepDirections[RightFrontTop] = true;
            c->sweepDirections[RightFrontBottom] = true;
            break;
        case BACK:
            c->sweepDirections[LeftBackTop] = true;
            c->sweepDirections[LeftBackBottom] = true;
            c->sweepDirections[RightBackTop] = true;
            c->sweepDirections[RightBackBottom] = true;
            break;
        default:
            assert(false);
            break;

        }
    }
}



template <class T>
inline void MonotonicityCheck(LSMGridpoint ***finedomain, T* c, loc_flag whichborder, T*** celldomain)
{
  /*This function is used only in FastCellCompute(), which shouldn't be used. */ 

   /*This function is called within UpdateSweepDirections();
c is the pointer to the cell whose sweep directions this function updates.
whichborder is the location of the "accepted" neighbor.

TODO: The cell domain is passed only to get a pointer to the first element for using c->getx(first), etc.
*/
    int x, y, z, i, j, k, left, right, top, bottom, back, front;
    bool leftToRight = true;
    bool rightToLeft = true;
    bool bottomToTop = true;
    bool topToBottom = true;
    bool frontToBack = true;
    bool backToFront = true;

    monotonicityCount++;

    x = c->getx(&celldomain[0][0][0]);
    y = c->gety(&celldomain[0][0][0]);
    z = c->getz(&celldomain[0][0][0]);

    left = x*cellWidth;
    right = left + cellWidth - 1;
    back = y*cellDepth;
    front = back + cellDepth - 1;
    bottom = z*cellHeight;
    top = bottom + cellHeight - 1;

    switch(whichborder)
    {
    case LEFT:
        for(j = back; j < front ; j++)
        {
            if(finedomain[left - 1][j][bottom].value <= finedomain[left - 1][j + 1][bottom].value)
                frontToBack = false;
            else
                backToFront = false;
            if(finedomain[left - 1][j][top].value <= finedomain[left - 1][j + 1][top].value)
                frontToBack = false;
            else
                backToFront = false;
        }
        for(k = bottom; k < top; k++)
        {
            if(finedomain[left - 1][back][k].value <= finedomain[left -1][back][k+1].value)
                topToBottom = false;
            else
                bottomToTop = false;
            if(finedomain[left - 1][front][k].value <= finedomain[left - 1][front][k+1].value)
                topToBottom = false;
            else
                bottomToTop = false;
        }

        if(topToBottom || bottomToTop)
        {
            if(frontToBack || backToFront)
                DOUBLESuccess++;
            else
                singleSuccess++;
        }
        else
        {
            if(frontToBack || backToFront)
                singleSuccess++;
        }
        if(bottomToTop)
        {
            if(backToFront)
                c->sweepDirections[LeftBackBottom] = true;
            else
            {
                if(frontToBack)
                    c->sweepDirections[LeftFrontBottom] = true;
                else //only bottomToTop
                {
                    c->sweepDirections[LeftBackBottom] = true;
                    c->sweepDirections[LeftFrontBottom] = true;
                }
            }
        }
        else
        {
            if(topToBottom)
            {
                if(backToFront)
                    c->sweepDirections[LeftBackTop] = true;
                else
                {
                    if(frontToBack)
                        c->sweepDirections[LeftFrontTop] = true;
                    else //only topToBottom
                    {
                        c->sweepDirections[LeftFrontTop] = true;
                        c->sweepDirections[LeftBackTop] = true;
                    }
                }

            }
            else //neither up-down monotonicity
            {
                if(backToFront)
                {
                    c->sweepDirections[LeftBackTop] = true;
                    c->sweepDirections[LeftBackBottom] = true;
                }
                else
                {
                    if(frontToBack)
                    {
                        c->sweepDirections[LeftFrontTop] = true;
                        c->sweepDirections[LeftFrontBottom] = true;
                    }
                    else //no monotonicity
                    {
                        c->sweepDirections[LeftFrontTop] = true;
                        c->sweepDirections[LeftBackTop] = true;
                        c->sweepDirections[LeftFrontBottom] = true;
                        c->sweepDirections[LeftBackBottom] = true;
                    }
                }
            }
        }
        break;
    case RIGHT:
        for(j = back; j<= front - 1; j++)
        {
            if(finedomain[right + 1][j][bottom].value <= finedomain[right + 1][j + 1][bottom].value)
                frontToBack = false;
            else
                backToFront = false;
            if(finedomain[right + 1][j][top].value <= finedomain[right + 1][j + 1][top].value)
                frontToBack = false;
            else
                backToFront = false;
        }
        for(k = bottom; k <= top - 1; k++)
        {
            if(finedomain[right + 1][back][k].value <= finedomain[right + 1][back][k+1].value)
                topToBottom = false;
            else
                bottomToTop = false;
            if(finedomain[right + 1][front][k].value <= finedomain[right + 1][front][k+1].value)
                topToBottom = false;
            else
                bottomToTop = false;
        }

        if(topToBottom || bottomToTop)
        {
            if(frontToBack || backToFront)
                DOUBLESuccess++;
            else
                singleSuccess++;
        }
        else
        {
            if(frontToBack || backToFront)
                singleSuccess++;
        }

        if(bottomToTop)
        {
            if(backToFront)
                c->sweepDirections[RightBackBottom] = true;
            else
            {
                if(frontToBack)
                    c->sweepDirections[RightFrontBottom] = true;
                else //only bottomToTop
                {
                    c->sweepDirections[RightBackBottom] = true;
                    c->sweepDirections[RightFrontBottom] = true;
                }
            }
        }
        else
        {
            if(topToBottom)
            {
                if(backToFront)
                    c->sweepDirections[RightBackTop] = true;
                else
                {
                    if(frontToBack)
                        c->sweepDirections[RightFrontTop] = true;
                    else //only topToBottom
                    {
                        c->sweepDirections[RightFrontTop] = true;
                        c->sweepDirections[RightBackTop] = true;
                    }
                }

            }
            else //neither up-down monotonicity
            {
                if(backToFront)
                {
                    c->sweepDirections[RightBackTop] = true;
                    c->sweepDirections[RightBackBottom] = true;
                }
                else
                {
                    if(frontToBack)
                    {
                        c->sweepDirections[RightFrontTop] = true;
                        c->sweepDirections[RightFrontBottom] = true;
                    }
                    else //no monotonicity
                    {
                        c->sweepDirections[RightFrontTop] = true;
                        c->sweepDirections[RightBackTop] = true;
                        c->sweepDirections[RightFrontBottom] = true;
                        c->sweepDirections[RightBackBottom] = true;
                    }
                }
            }
        }
        break;


        case TOP:
        for(i = left; i <= right - 1; i++)
        {
            if(finedomain[i][back][top+1].value <= finedomain[i+1][back][top +1].value)
                rightToLeft = false;
            else
                leftToRight = false;
            if(finedomain[i][front][top+1].value <= finedomain[i+1][front][top +1].value)
                rightToLeft = false;
            else
                leftToRight = false;
        }
        for(j = back; j <= front - 1; j++)
        {
            if(finedomain[left][j][top + 1].value <= finedomain[left][j+1][top+1].value)
                frontToBack = false;
            else
                backToFront = false;
            if(finedomain[right][j][top + 1].value <= finedomain[right][j+1][top+1].value)
                frontToBack = false;
            else
                backToFront = false;
        }


        if(leftToRight || rightToLeft)
        {
            if(frontToBack || backToFront)
                DOUBLESuccess++;
            else
                singleSuccess++;
        }
        else
        {
            if(frontToBack || backToFront)
                singleSuccess++;
        }

        if(leftToRight)
        {
            if(frontToBack)
            {
                c->sweepDirections[LeftFrontTop] = true;
            }
            else
            {
                if(backToFront)
                {
                    c->sweepDirections[LeftBackTop] = true;
                }
                else //only left to right
                {
                    c->sweepDirections[LeftBackTop] = true;
                    c->sweepDirections[LeftFrontTop] = true;
                }
            }
        }
        else
        {
            if(rightToLeft)
            {
                if(backToFront)
                    c->sweepDirections[RightBackTop] = true;
                else
                {
                    if(frontToBack)
                        c->sweepDirections[RightFrontTop] = true;
                    else //no front-back monotonicity
                    {
                        c->sweepDirections[RightBackTop] = true;
                        c->sweepDirections[RightFrontTop] = true;
                    }
                }
            }
            else //no left-right monotonicity
            {
                if(backToFront)
                {
                    c->sweepDirections[LeftBackTop] = true;
                    c->sweepDirections[RightBackTop] = true;
                }
                else
                {
                    if(frontToBack)
                    {
                        c->sweepDirections[LeftFrontTop] = true;
                        c->sweepDirections[RightFrontTop] = true;
                    }
                    else //no monotonicity
                    {
                        c->sweepDirections[LeftBackTop] = true;
                        c->sweepDirections[LeftFrontTop] = true;
                        c->sweepDirections[RightBackTop] = true;
                        c->sweepDirections[RightFrontTop] = true;
                    }
                }
            }
        }


        break;

        case BOTTOM:
        for(i = left; i <= right - 1; i++)
        {
            if(finedomain[i][back][bottom - 1].value <= finedomain[i+1][back][bottom -1].value)
                rightToLeft = false;
            else
                leftToRight = false;
            if(finedomain[i][front][bottom -1].value <= finedomain[i+1][front][bottom - 1].value)
                rightToLeft = false;
            else
                leftToRight = false;
        }
        for(j = back; j <= front - 1; j++)
        {
            if(finedomain[left][j][bottom - 1].value <= finedomain[left][j+1][bottom - 1].value)
                frontToBack = false;
            else
                backToFront = false;
            if(finedomain[right][j][bottom - 1].value <= finedomain[right][j+1][bottom - 1].value)
                frontToBack = false;
            else
                backToFront = false;
        }

        if(leftToRight || rightToLeft)
        {
            if(frontToBack || backToFront)
                DOUBLESuccess++;
            else
                singleSuccess++;
        }
        else
        {
            if(frontToBack || backToFront)
                singleSuccess++;
        }

        if(leftToRight)
        {
            if(frontToBack)
            {
                c->sweepDirections[LeftFrontBottom] = true;
            }
            else
            {
                if(backToFront)
                {
                    c->sweepDirections[LeftBackBottom] = true;
                }
                else //only left to right
                {
                    c->sweepDirections[LeftBackBottom] = true;
                    c->sweepDirections[LeftFrontBottom] = true;
                }
            }
        }
        else
        {
            if(rightToLeft)
            {
                if(backToFront)
                    c->sweepDirections[RightBackBottom] = true;
                else
                {
                    if(frontToBack)
                        c->sweepDirections[RightFrontBottom] = true;
                    else //no front-back monotonicity
                    {
                        c->sweepDirections[RightBackBottom] = true;
                        c->sweepDirections[RightFrontBottom] = true;
                    }
                }
            }
            else //no left-right monotonicity
            {
                if(backToFront)
                {
                    c->sweepDirections[LeftBackBottom] = true;
                    c->sweepDirections[RightBackBottom] = true;
                }
                else
                {
                    if(frontToBack)
                    {
                        c->sweepDirections[LeftFrontBottom] = true;
                        c->sweepDirections[RightFrontBottom] = true;
                    }
                    else //no monotonicity
                    {
                        c->sweepDirections[LeftBackBottom] = true;
                        c->sweepDirections[LeftFrontBottom] = true;
                        c->sweepDirections[RightBackBottom] = true;
                        c->sweepDirections[RightFrontBottom] = true;
                    }
                }
            }
        }
        break;

        case FRONT:
        for(i = left; i <= right -1; i++)
        {
            if(finedomain[i][front + 1][top].value <= finedomain[i + 1][front + 1][top].value)
                rightToLeft = false;
            else
                leftToRight = false;
            if(finedomain[i][front + 1][bottom].value <= finedomain[i + 1][front + 1][bottom].value)
                rightToLeft = false;
            else
                leftToRight = false;
        }
        for(k = bottom; k <= top -1; k++)
        {
            if(finedomain[left][front +1][k].value <= finedomain[left][front +1][k + 1].value)
                topToBottom = false;
            else
                bottomToTop = false;
            if(finedomain[right][front + 1][k].value <= finedomain[right][front +1][k + 1].value)
                topToBottom = false;
            else
                bottomToTop = false;

        }

        if(leftToRight || rightToLeft)
        {
            if(bottomToTop || topToBottom)
                DOUBLESuccess++;
            else
                singleSuccess++;
        }
        else
        {
            if(bottomToTop || topToBottom)
                singleSuccess++;
        }


        if(leftToRight)
        {
            if(topToBottom)
            {
                c->sweepDirections[LeftFrontTop] = true;
            }
            else
            {
                if(bottomToTop)
                {
                    c->sweepDirections[LeftFrontBottom] = true;
                }
                else //leftToRight only
                {
                    c->sweepDirections[LeftFrontBottom] = true;
                    c->sweepDirections[LeftFrontTop] = true;
                }
            }
        }
        else
        {
            if(rightToLeft)
            {
                if(topToBottom)
                {
                    c->sweepDirections[RightFrontTop] = true;
                }
                else
                {
                    if(bottomToTop)
                    {
                        c->sweepDirections[RightFrontBottom] = true;
                    }
                    else //rightToLeft only
                    {
                        c->sweepDirections[RightFrontBottom] = true;
                        c->sweepDirections[RightFrontTop] = true;
                    }
                }
            }
            else //no left-right monotonicity
            {
                if(bottomToTop)
                {
                    c->sweepDirections[LeftFrontBottom] = true;
                    c->sweepDirections[RightFrontBottom] = true;
                }
                else
                {
                    if(topToBottom)
                    {
                        c->sweepDirections[LeftFrontTop] = true;
                        c->sweepDirections[RightFrontTop] = true;
                    }
                    else //no monotonicity
                    {
                        c->sweepDirections[LeftFrontBottom] = true;
                        c->sweepDirections[LeftFrontTop] = true;
                        c->sweepDirections[RightFrontBottom] = true;
                        c->sweepDirections[RightFrontTop] = true;
                    }
                }
            }
        }

        break;

        case BACK:
        for(i = left; i <= right -1; i++)
        {
            if(finedomain[i][back - 1][top].value <= finedomain[i + 1][back - 1][top].value)
                rightToLeft = false;
            else
                leftToRight = false;
            if(finedomain[i][back - 1][bottom].value <= finedomain[i + 1][back - 1][bottom].value)
                rightToLeft = false;
            else
                leftToRight = false;
        }
        for(k = bottom; k <= top -1; k++)
        {
            if(finedomain[left][back +1][k].value <= finedomain[left][back +1][k + 1].value)
                topToBottom = false;
            else
                bottomToTop = false;
            if(finedomain[right][back - 1][k].value <= finedomain[right][back - 1][k + 1].value)
                topToBottom = false;
            else
                bottomToTop = false;
        }

        if(leftToRight || rightToLeft)
        {
            if(bottomToTop || topToBottom)
                DOUBLESuccess++;
            else
                singleSuccess++;
        }
        else
        {
            if(bottomToTop || topToBottom)
                singleSuccess++;
        }

        if(leftToRight)
        {
            if(topToBottom)
            {
                c->sweepDirections[LeftBackTop] = true;
            }
            else
            {
                if(bottomToTop)
                {
                    c->sweepDirections[LeftBackBottom] = true;
                }
                else //leftToRight only
                {
                    c->sweepDirections[LeftBackBottom] = true;
                    c->sweepDirections[LeftBackTop] = true;
                }
            }
        }
        else
        {
            if(rightToLeft)
            {
                if(topToBottom)
                {
                    c->sweepDirections[RightBackTop] = true;
                }
                else
                {
                    if(bottomToTop)
                    {
                        c->sweepDirections[RightBackBottom] = true;
                    }
                    else //rightToLeft only
                    {
                        c->sweepDirections[RightBackBottom] = true;
                        c->sweepDirections[RightBackTop] = true;
                    }
                }
            }
            else //no left-right monotonicity
            {
                if(bottomToTop)
                {
                    c->sweepDirections[LeftBackBottom] = true;
                    c->sweepDirections[RightBackBottom] = true;
                }
                else
                {
                    if(topToBottom)
                    {
                        c->sweepDirections[LeftBackTop] = true;
                        c->sweepDirections[RightBackTop] = true;
                    }
                    else //no monotonicity
                    {
                        c->sweepDirections[LeftBackBottom] = true;
                        c->sweepDirections[LeftBackTop] = true;
                        c->sweepDirections[RightBackBottom] = true;
                        c->sweepDirections[RightBackTop] = true;
                    }
                }
            }
        }
        break;

        default:
        assert(false);
        break;
    }

}


#endif // HEAPCELLMETHOD_H
