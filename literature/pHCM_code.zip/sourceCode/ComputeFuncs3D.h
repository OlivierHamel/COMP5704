  /*
  * =====================================================================================
  *
  *  This program is free software: you can redistribute it and/or modify
  *  it under the terms of the GNU General Public License as published by
  *  the Free Software Foundation, either version 3 of the License, or
  *  (at your option) any later version.
  *
  *  This program is distributed in the hope that it will be useful,
  *  but WITHOUT ANY WARRANTY; without even the implied warranty of
  *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  *  GNU General Public License for more details.
  *
  *  You should have received a copy of the GNU General Public License
  *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
  *
  * -------------------------------------------------------------------------------------
  *
  *       Filename:  ComputeFuncs3D.h
  *
  *        Version:   1.0
  *        Created:   6/18/13
  *        Revision:  none
  *        Compiler:  gcc/intel compiler
  *        Author:    Adam Chacon, adamdante@gmail.com
  *                   Cornell University
  *
  *        This file is a part of the numerical methods implementation/
  *        benchmarking described in the following article:
  *
  *	   http://www.math.cornell.edu/~vlad/papers/pHCM/
  *
  *	   The HCM and pHCM algorithms were developed by A. Chacon and 
  *	   A. Vladimirsky.
  *
  * =====================================================================================
  */


#ifndef COMPUTEFUNCS3D_H
#define COMPUTEFUNCS3D_H



#include "params3D.h"
#include "OtherCommon.h"
#include "ExternVars.h"
#include "GlobalVars3D.h"
#include <math.h>
#include <stdio.h>
#include "GlobalConfiguration.h"
#include "Gridpoint.h"
#include <assert.h>
#include "HeapGeneral.h"

extern int CompUCounter;

using namespace std;
inline void FindMinTwo(DOUBLE output[2], DOUBLE wx, DOUBLE wy, DOUBLE wz, DOUBLE other[1])
{
    //Called only by Compute_from_Three_Neighbors()
    if(wx > wy)
    {
        if(wx > wz)
        {
            output[0] = wy;
            output[1] = wz;
            other[0] = wx;
        }
        else //wz >= wx
        {
            output[0] = wx;
            output[1] = wy;
            other[0] = wz;
        }
    }
    else //wy >= wx
    {
        if(wy > wz)
        {
            output[0] = wx;
            output[1] = wz;
            other[0] = wy;
        }
        else //wz >= wy
        {
            output[0] = wx;
            output[1] = wy;
            other[0] = wz;
        }

    }
}


inline DOUBLE Compute_from_One_Neighbor(DOUBLE f,   DOUBLE w)
{
    /*This function uses 1 neighbor to estimate the gradient at a point q.
  w is the value at the neighbor and f is the speed at q.
  */
  //  CompUCounter1++;
    if(f == 0)
        return inf;
    return (w + hy/f);

}

inline DOUBLE Compute_from_Two_Neighbors(DOUBLE f,   DOUBLE w1,   DOUBLE w2)
{
    /*
    w1 is the value of an east-west neighor, and w2 is the value of an north-south neighbor.
    f is the speed at the gridpoint being updated.
Note: a nonzero "thresh" may be needed when compiler optimizations are used.  */
    if(f == 0)
        return inf;
    //CompUCounter2++;
    DOUBLE h = hx;
    DOUBLE thresh, rat1, root1, diff, rat, discriminant;

    diff = w1 - w2;
    rat1 = h/f;
    if(sizeof(DOUBLE) == 4) //DOUBLE == float
      thresh = 1e-7;
    else
      thresh = 1e-14;//threshConst*h*h;//1e-5;

    if(fabs(diff) + thresh >= rat1) //upwinding condition won't be satisfied.
    {
        if(w1 < w2)
            root1 = w1 + rat1;
        else
            root1 = w2 + rat1;
    }
    else
    {
        rat = SQRT2*rat1;
        discriminant = (rat - diff)*(rat + diff);
        if(discriminant >= 0)
        {
            root1 = .5*((w1 + w2) + sqrt(discriminant));

#ifdef NUMERICAL_TINKER_COMP2NEIGHB
            assert(sqrt(discriminant) > fabs(diff));
#else
#endif
            if(root1 < w1 || root1 < w2)
            {
                cout<<"w1: "<<w1<<"    w2: "<<w2<<"     root: ";
                cout<<root1<<"    h/f: "<<rat1;
                cout<<"     diff: "<<diff<<"          thresh: "<<thresh;
		cout<<"          diff + thresh: "<<diff + thresh<<endl;
                assert(false);
            }
        }
        else
        {
            assert(false);
        }
    }
    return root1;
}

#ifdef UNSAFE_COMP_THREE
inline DOUBLE Compute_from_Three_Neighbors(DOUBLE f, DOUBLE wx, DOUBLE wy, DOUBLE wz)
{
    //This function should only be called if all w values are less than the current value of the gridpoint.
  //CompUCounter3++;
    if(f == 0)
        return inf;
    DOUBLE root, sqDiscriminant,twoSided;
    DOUBLE thresh; //this is used to prevent a 3-sided update if kappa is near -sqDiscriminant
    //thresh only depends on the w variables- should it depend on h or something else?
    DOUBLE h = hx;
    DOUBLE output[2];
    DOUBLE other;
    
    DOUBLE discriminant = 3*h*h/(f*f) - 2*(wx*wx - wx*wy + wy*wy - wx*wz + wz*wz - wy*wz);
    if(discriminant >= 0)
      {
	sqDiscriminant = sqrt(discriminant);
	root = (wx + wy + wz + sqDiscriminant)/3;
      }
    else
      {
	FindMinTwo(output, wx, wy, wz, &other);
	root = Compute_from_Two_Neighbors(f,output[0],output[1]);
	
      }
    return root;
}

#else
inline DOUBLE Compute_from_Three_Neighbors(DOUBLE f, DOUBLE wx, DOUBLE wy, DOUBLE wz)
{
    //This function should only be called if all w values are less than the current value of the gridpoint.
  //CompUCounter3++;
    if(f == 0)
        return inf;
    DOUBLE root, sqDiscriminant,twoSided;
    DOUBLE thresh; //this is used to prevent a 3-sided update if kappa is near -sqDiscriminant
    DOUBLE h = hx;
    DOUBLE output[2];
    DOUBLE other;
    DOUBLE discriminant;

    FindMinTwo(output, wx, wy, wz, &other);
#ifdef _DEBUGMODE
    DOUBLE kappa = output[0] + output[1] - 2*other;
#else
#endif

    if(sizeof(DOUBLE) == 4) //DOUBLE == float
      thresh = 1e-7;
    else
      thresh = 1e-14;//threshConst*h*h;//1e-5;

    twoSided = Compute_from_Two_Neighbors(f,output[0],output[1]);
    //    DOUBLE phi = h*h/(f*f) -output[0]*output[0] - output[1]*output[1] + 2*other*(output[0] + output[1] - other);
    
    if((twoSided - other) <= thresh)
      {
	//TwoSidedCounter++;
        return twoSided;
      }
    else
    {
        discriminant = 3*h*h/(f*f) - 2*(wx*wx - wx*wy + wy*wy - wx*wz + wz*wz - wy*wz);
        if(discriminant >= 0)
        {
            sqDiscriminant = sqrt(discriminant);
            root = (wx + wy + wz + sqDiscriminant)/3;
#ifdef _DEBUGMODE
            ASSERT(sqDiscriminant > fabs(kappa));
            ASSERT(root >= wx && root >= wy && root >= wz);
#else
#endif
        }
        else
        {
            assert(false);
        }
        return root;
    }
}
#endif

template <class GPs>
        inline DOUBLE SmallerXNeighbor(GPs ***domain, int x, int y, int z)
{
    DOUBLE value;

    if (x == 0)
        value = domain[x+1][y][z].value;
    else if (x == (m-1))
        value = domain[x-1][y][z].value;
    else
        value = min(domain[x+1][y][z].value, domain[x-1][y][z].value);
    return value;
}

template <class GPs>
        inline DOUBLE SmallerYNeighbor(GPs ***domain, int x, int y, int z)
{
    DOUBLE value;

    if (y == 0)
        value = domain[x][y+1][z].value;
    else if (y == (n-1))
        value = domain[x][y-1][z].value;
    else
        value = min(domain[x][y+1][z].value, domain[x][y-1][z].value);

    return value;
}

template <class GPs>
        inline DOUBLE SmallerZNeighbor(GPs ***domain, int x, int y, int z)
{
    DOUBLE value;

    if (z == 0)
        value = domain[x][y][z+1].value;
    else if (z == (b-1))
        value = domain[x][y][z-1].value;
    else
        value = min(domain[x][y][z+1].value, domain[x][y][z-1].value);

    return value;
}


template <class GPs>
        inline DOUBLE UpdateNode(GPs*** domain, int x, int y, int z)
{

#ifdef HARDCODED_UNIT_SPEED
    DOUBLE speed = 1;
#else
    DOUBLE speed = getspeed(hx*x + minx,hy*y + miny, z*hz + minz);
#endif


    DOUBLE smallest = domain[x][y][z].value;
    DOUBLE temp, neighb1, neighb2, neighb3;
    neighb1 = SmallerXNeighbor(domain,x,y,z);
    neighb2 = SmallerYNeighbor(domain,x,y,z);
    neighb3 = SmallerZNeighbor(domain,x,y,z);

    if(neighb1 < smallest)
    {
        if(neighb2 < smallest)
        {
            if(neighb3 <  smallest)
                temp = Compute_from_Three_Neighbors(speed, neighb1, neighb2, neighb3);
            else
                temp = Compute_from_Two_Neighbors(speed,neighb1,neighb2);
        }
        else
        {
            if(neighb3 <  smallest)
                temp = Compute_from_Two_Neighbors(speed,neighb1,neighb3);
            else
                temp = Compute_from_One_Neighbor(speed,neighb1);
        }
    }
    else
    {
        if(neighb2 < smallest)
        {
            if(neighb3 < smallest)
                temp = Compute_from_Two_Neighbors(speed,neighb2,neighb3);
            else
                temp = Compute_from_One_Neighbor(speed,neighb2);
        }
        else
            temp = Compute_from_One_Neighbor(speed,neighb3);
    }

    return min(temp,smallest);
}

inline DOUBLE updateNodeFMM(int x, int y, int z, DOUBLE rootVal, DOUBLE neighb2Val, DOUBLE neighb3Val, DOUBLE zBarVal)
{
  //Assumes rootVal < zBarVal
  //assert(rootVal <= zBarVal);
  DOUBLE speed = getspeed(hx*x + minx, hy*y + miny, hz*z + minz);
  if(neighb2Val < zBarVal)
    {
      if(neighb3Val < zBarVal)
	{
	  return Compute_from_Three_Neighbors(speed, rootVal,neighb2Val, neighb3Val);
	}
      else
	return Compute_from_Two_Neighbors(speed,rootVal,neighb2Val);
    }
  else
    {
      if(neighb3Val < zBarVal)
	return Compute_from_Two_Neighbors(speed,rootVal,neighb3Val);
      else
	return Compute_from_One_Neighbor(speed,rootVal);
    }
  
  assert(false);
}


#ifdef OLD_INC_L
inline void Incorporate_Into_L(FMMGridpoint ***domain,HeapGeneral<FMMGridpoint> *Considered,int x,
                               int y, int z, DOUBLE rootVal)
{
    /*temp is the accepted fmmNode.  x and y are the coordinates of a neighbor of temp.
  "vertical" describes if that fmmNode is horizontally adjacent to temp (vertical == 0) or verticall adjacent
(vertical == 1).
  This function is called by InitializeFMM() and FastMarchingMethod().
  */

    FMMGridpoint* zBar = &domain[x][y][z];
#ifdef HARDCODED_UNIT_SPEED
    DOUBLE speed =1;
#else
    DOUBLE speed = getspeed(hx*x + minx,hy*y + miny, z*hz + minz);
#endif
    zBar->value = Compute_from_One_Neighbor(speed,rootVal);
    zBar->status = CONSIDERED;
    int k = Considered->currently_used;
    zBar->offset = k;
    Considered->L[k] = zBar;
    Considered->upheap(k);
    Considered->currently_used++;
}
#else  //OLD_INC_L

inline void Incorporate_Into_L(FMMGridpoint *zBar,HeapGeneral<FMMGridpoint> *Considered,int x,
                               int y, int z, DOUBLE rootVal)
{
    /*temp is the accepted fmmNode.  x and y are the coordinates of a neighbor of temp.
  "vertical" describes if that fmmNode is horizontally adjacent to temp (vertical == 0) or verticall adjacent
(vertical == 1).
  This function is called by InitializeFMM() and FastMarchingMethod().
  */

    //FMMGridpoint* zBar = &domain[x][y][z];
#ifdef HARDCODED_UNIT_SPEED
    DOUBLE speed =1;
#else
    DOUBLE speed = getspeed(hx*x + minx,hy*y + miny, z*hz + minz);
#endif
    zBar->value = Compute_from_One_Neighbor(speed,rootVal);
    zBar->status = CONSIDERED;
    int k = Considered->currently_used;
    zBar->offset = k;
    Considered->L[k] = zBar;
    Considered->upheap(k);
    Considered->currently_used++;
}

#endif //OLD_INC_L

#endif //COMPUTEFUNCS3D_H
