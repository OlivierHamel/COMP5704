  /*
  * =====================================================================================
  *
  *  This program is free software: you can redistribute it and/or modify
  *  it under the terms of the GNU General Public License as published by
  *  the Free Software Foundation, either version 3 of the License, or
  *  (at your option) any later version.
  *
  *  This program is distributed in the hope that it will be useful,
  *  but WITHOUT ANY WARRANTY; without even the implied warranty of
  *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  *  GNU General Public License for more details.
  *
  *  You should have received a copy of the GNU General Public License
  *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
  *
  * -------------------------------------------------------------------------------------
  *
  *       Filename:  parallelHCM.cpp
  *
  *        Version:   1.0
  *        Created:   6/18/13
  *        Revision:  none
  *        Compiler:  gcc/intel compiler
  *        Author:    Adam Chacon, adamdante@gmail.com
  *                   Cornell University
  *
  *        This file is a part of the numerical methods implementation/
  *        benchmarking described in the following article:
  *
  *	   http://www.math.cornell.edu/~vlad/papers/pHCM/
  *
  *	   The HCM and pHCM algorithms were developed by A. Chacon and 
  *	   A. Vladimirsky.
  *
  * =====================================================================================
  */


#include "parallelHCM.h"


void setCurrentTid(parallelHeap* Considered, int tid, int currentlyIn)
{

  int i;
  for(i = 0; i < currentlyIn; i++)
    Considered->L[i]->currentTid = tid;

}


double ParallelHCM(parallelCell*** celldomain, LSMGridpoint*** finedomain, bool isFast,double* cellCompTime)
{
  //1. returns the time spent in cells only. 4/11/12
  //2.  returns AvHR 4/12/12
  //3.  Cell comp time is now an argument to the function 4/12/12

  double  dummy_debugTime = 0;
  double  debugTime = 0;

  //DOUBLE startTime = omp_get_wtime();

  int tid,j;
  int totalHRs = 0;
  omp_set_num_threads(numthreads);
  parallelHeap* Heaps = new parallelHeap[numthreads];
  // bool anywork = true; //is any processor busy?
  //    bool recently_added = false;
  // bool* procIdle = new bool[numthreads]; //does the local processor have work?
  int totalSweeps = 0;
  //int nonemptyHeaps = 1;
  int numCellsTotal = 1; //TODO: not very clean.
  for(j = 0; j < numthreads; j++)
    {
        Heaps[j].Initialize(cm*cn*cb);
    }
  
  int neighborVec[6][3];
  SetNeighborVec(neighborVec);
  

#pragma omp parallel private(tid) shared(neighborVec, Heaps, finedomain, celldomain,numCellsTotal)
  {
    
    double dT,dummy_dT;
    
      tid = omp_get_thread_num();
      int mySweeps = 0;
      parallelCell* cell_q;
      parallelCell* c;
      parallelCell* beginning = &celldomain[0][0][0];
      if(tid == 0) //TODO: change when Q^c is large
        {
          //cout<<"Num threads: "<<numthreads<<endl;
	  InitializeCells(celldomain,&Heaps[0]);
	  numCellsTotal = Heaps[0].GetCurrentlyIn();
	  setCurrentTid(&Heaps[0],0, numCellsTotal);
        }

      DOUBLE temp_cell_label;
      int cellx, celly, cellz, x, y, z, i,min_heap, min_elements, test_count, k, temp_heap, notworking;
      //int local_recently_added;
      int chosenHeap;
      bool IsEmpty;
      bool whichNeighbors[6];
      DOUBLE maxBorderGPs[6];
      parallelHeap* localHeap = &Heaps[tid];
      bool tryAgain;

      
      k = 0;

      while(numCellsTotal > 0)//nonemptyHeaps > 0)//anywork)
        {

          omp_set_lock(&localHeap->lock);
          IsEmpty = localHeap->IsEmpty();
          omp_unset_lock(&localHeap->lock);

          while(!IsEmpty)
            {

              omp_set_lock(&localHeap->lock);
              cell_q = localHeap->L[0];
              omp_set_lock(&cell_q->posLock); 

              ASSERT(cell_q == localHeap->L[0]);/*this should always be true because no one else can add
to this heap; the lock is already obtained by the time L[0] is grabbed.*/
              localHeap->downheap();
              cell_q->currentTid = -1;
	      //cell_q->prevTid = tid;
	      cell_q->status = OUT;
	      /*6/7/13 TEST */
#ifdef NEW_CELL_VAL
	      cell_q->SetVal(inf);
#endif

              omp_unset_lock(&cell_q->posLock);
              omp_unset_lock(&localHeap->lock);

	      /*4/30/12: These were in the locked section above, but I don't think this 
		read-access needs to be locked, since it never changes.  */
	      cellx = cell_q->getx(beginning); //race
              celly = cell_q->gety(beginning); //race
              cellz = cell_q->getz(beginning); //race

	      for(i = 0; i < 6; i++)
		{
		  whichNeighbors[i] = false;
#ifdef NEW_CELL_VAL
		  maxBorderGPs[i] = inf;
#else
		  maxBorderGPs[i] = -1;
#endif
		}
              omp_set_lock(&cell_q->compLock);
	      //note that pos_lock is not set here, so cell_q can now have its value changed and can be placed on another list.
              if(isFast)
                  mySweeps = FastCellCompute(celldomain,finedomain,cellx,celly,cellz,whichNeighbors,maxBorderGPs);
              else
		{
		  mySweeps = SlowCellCompute(celldomain,finedomain,cellx,celly,cellz, whichNeighbors,&dT,&dummy_dT,maxBorderGPs);
#pragma omp atomic
		  debugTime += dT;
		  //#pragma omp atomic
		  //dummy_debugTime += dummy_dT;
		}
              //When using FHCM it might be a good idea to use a lock when updating sweep directions.

              omp_unset_lock(&cell_q->compLock);
#pragma omp atomic
	      totalSweeps += mySweeps;
              

              for(i = 0; i < 6; i++)//neighbor loop.
		{
                  if(whichNeighbors[i])
                    {
                      x = cellx + neighborVec[i][0];
                      y = celly + neighborVec[i][1];
                      z = cellz + neighborVec[i][2];
		      
                      ASSERT(x >= 0 && x < cm && y >= 0 && y < cn && z >= 0 && z < cb);
		      c = &celldomain[x][y][z];

		      // temp_cell_label = ComputeCellVal(finedomain,cellx,celly,cellz,(loc_flag)i);
		      //5/29/31:
		      ASSERT(maxBorderGPs[i] != -1 && maxBorderGPs[i] != inf);

#ifdef NEW_CELL_VAL
		      temp_cell_label = maxBorderGPs[i];
#else
		      temp_cell_label = ComputeCellVal(finedomain,cellx,celly,cellz,(loc_flag)i, maxBorderGPs[i]);
#endif
		      if(temp_cell_label < c->GetVal())
                        {
                          tryAgain = true;
                          while(tryAgain)
                            {
                              if(c->status == IN)
                                {
#pragma omp flush
                                  temp_heap = c->currentTid;
				  if(temp_heap == -1)
				    continue;
				  omp_set_lock(&Heaps[temp_heap].lock);
				  if(c->currentTid != temp_heap)
				    {
				      omp_unset_lock(&Heaps[temp_heap].lock);
				      continue;
				    }
				  else  
				    {      
				      /*1/18/12: Once we are in this section, we know for sure that c is on a heap, and that heap is locked. 
				       Thus, c need not be posLocked: it is guaranteed to be on the heap identified with the lock already obtained,
				       so c can't be removed, or added to another heap.
				      */
				      tryAgain = false;

				      omp_set_lock(&c->posLock); //Does this need to be set?
				      if(temp_cell_label < c->GetVal()) //need to check again now that cell is locked.
					{
					  c->SetVal(temp_cell_label);
					  if(c->currentTid == temp_heap) //check again now that lock is obtained.  See the comment above.
					    {
					      Heaps[temp_heap].upheap(c->offset);
                                            }
					  else
					    {
					      assert(false);
					    }
					}

				      omp_unset_lock(&c->posLock);
				      omp_unset_lock(&Heaps[temp_heap].lock);
				    }
				}
			      
                              else //c->status == OUT
                                {

                                  omp_set_lock(&c->posLock);
                                  if(c->status == IN)
                                    omp_unset_lock(&c->posLock);
                                  else
                                    {
                                      tryAgain = false;
                                      if(temp_cell_label < c->GetVal()) //check again now that lock is obtained.
                                        c->SetVal(temp_cell_label);
                                      omp_unset_lock(&c->posLock);
                                    }
                                }
                            }//while (tryAgain)
                        }//if(temp_cell_label < ...)

		      
                      //Add cell:
                      if(c->status == OUT)
                        {			  
			  //min_heap = FindMinHeap(&Heaps); //5_6_12
			  min_heap = 0;
			  min_elements = Heaps[0].GetCurrentlyIn(); //race
			  for(j = 1; j < numthreads; j++)
			    {
			      if(Heaps[j].GetCurrentlyIn() < min_elements)
				{
				  min_heap = j;
				  min_elements = Heaps[j].GetCurrentlyIn();  //race
				}
			    }

                          test_count = 0;

                          while(!omp_test_lock(&Heaps[(min_heap + test_count) % numthreads].lock))
			    test_count++; 
			  chosenHeap = (min_heap + test_count) % numthreads;
			  omp_set_lock(&c->posLock);
                          if(c->status == OUT) //check again now that cell lock is obtained.
                            {
#pragma omp atomic
			      numCellsTotal++;
                              c->currentTid = chosenHeap;
                              Heaps[chosenHeap].add(c);
			    }
        
			  omp_unset_lock(&(c->posLock));
                          omp_unset_lock(&Heaps[chosenHeap].lock);

                        }
		      UpdateSweepDirections(c, finedomain, isFast,(loc_flag)i,celldomain); //race
                    }
                }
              omp_set_lock(&localHeap->lock);
              IsEmpty = localHeap->IsEmpty();
              omp_unset_lock(&localHeap->lock);
              k++;
	      
#pragma omp atomic
	      numCellsTotal--; //Now count the cell removed at the beginning of the loop.
		
            }//while(!IsEmpty)
	  

	}//while (anywork)
      
      ASSERT(localHeap->IsEmpty());
      ASSERT(numCellsTotal == 0);


#pragma omp atomic
      totalHRs += k;
      
      
#pragma omp barrier
      {
        omp_destroy_lock(&localHeap->lock);
      }
      
    }
    
    //cout<<"Parallel HeapCell algorithm time: "<<total_time<<endl;
    //cout<<"Ratio test_count increments to total adds:"<<(float)test_total/total_adds<<endl<<endl;
    //cout<<"Avg dummy computation time per thread: "<<dummy_debugTime/numthreads<<endl;
    //cout<<"Avg other time spent in SlowCompte(): "<<debugTime/numthreads<<endl;
    //cout<<"Avg number of sweeps  per cell: "<<(DOUBLE)totalSweeps/(cm*cn*cb)<<endl;
    //cout<<"Total Avg HRs: "<<(DOUBLE)totalHRs/(cm*cn*cb)<<endl;
    delete [] Heaps;
    //delete [] mywork;
    //return debugTime/numthreads;
    *cellCompTime = debugTime/numthreads;
    //return (DOUBLE)totalHRs/(cm*cn*cb);
    return (DOUBLE)totalSweeps/(cm*cn*cb);
}

