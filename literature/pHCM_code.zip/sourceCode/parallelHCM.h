  /*
  * =====================================================================================
  *
  *  This program is free software: you can redistribute it and/or modify
  *  it under the terms of the GNU General Public License as published by
  *  the Free Software Foundation, either version 3 of the License, or
  *  (at your option) any later version.
  *
  *  This program is distributed in the hope that it will be useful,
  *  but WITHOUT ANY WARRANTY; without even the implied warranty of
  *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  *  GNU General Public License for more details.
  *
  *  You should have received a copy of the GNU General Public License
  *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
  *
  * -------------------------------------------------------------------------------------
  *
  *       Filename:  parallelHCM.h
  *
  *        Version:   1.0
  *        Created:   6/18/13
  *        Revision:  none
  *        Compiler:  gcc/intel compiler
  *        Author:    Adam Chacon, adamdante@gmail.com
  *                   Cornell University
  *
  *        This file is a part of the numerical methods implementation/
  *        benchmarking described in the following article:
  *
  *	   http://www.math.cornell.edu/~vlad/papers/pHCM/
  *
  *	   The HCM and pHCM algorithms were developed by A. Chacon and 
  *	   A. Vladimirsky.
  *
  * =====================================================================================
  */


#ifndef PARALLELHCM_H
#define PARALLELHCM_H

/* 

This is an openmp implementation of HCM.  There is one heap for each processor.  Cells are removed only from
a processor's own heap, but they are added based on the cell with the smallest load (estimated). */

#include "Gridpoint.h"
#include "GlobalVars3D.h"
#include "ExternVars.h"
#include "params3D.h"
#include "OtherCommon.h"
#include "HeapGeneral.h"
#include "ComputeFuncs3D.h"
#include "HeapCellMethod.h"
#include <math.h>
#include <iostream>
#include "omp.h"
#include <stdlib.h>

double ParallelHCM(parallelCell*** celldomain, LSMGridpoint*** finedomain, bool isFast,double* cellCompTime);
int parallelDetrixhe(FSMGridpoint*** domain);
int parallelDetrixheLSM(LSMGridpoint*** domain);
void setCurrentTid(parallelHeap* Considered, int tid, int currentlyIn);

inline void printParallelHeap(parallelHeap* Considered, parallelCell*** celldomain, int tid)
{
    /* Used for debugging. */

    int cellx, celly,cellz,k,i;
    parallelCell* temp;
    k = 1;

    parallelCell* beginning = &celldomain[0][0][0];
    cout<<"Heap: "<<tid<<".  Currently in: "<<Considered->currently_used<<endl;
    for(i = 0; i < Considered->currently_used; i++)
    {
        temp = Considered->L[i];
        cellx = temp->getx(beginning);
        celly = temp->gety(beginning);
        cellz = temp->getz(beginning);
        cout<<k<<". ("<< cellx<<","<<celly<<", "<<cellz<<")"<<"  value = "<<temp->value<<endl;
        k++;
    }
    cout<<endl;
}


inline int FindMinHeap(parallelHeap** Heaps)
{
    /*Note: this function is called within a parallel region, so the values heap_count  might not be up-to-date.  */
    int min_heap = 0;
    int min_heap_count = Heaps[0]->GetCurrentlyIn();
    for(int j = 1; j < numthreads; j++)
      {
        if(Heaps[j]->GetCurrentlyIn() < min_heap_count)
          {
            min_heap = j;
            min_heap_count = Heaps[j]->GetCurrentlyIn();
          }
      }
    return min_heap;
}

inline DOUBLE pHCM_UpdateNode(DOUBLE currentVal, DOUBLE xMinNeighb, DOUBLE yMinNeighb, DOUBLE zMinNeighb, DOUBLE speed)
{
  DOUBLE temp;
  
  if(xMinNeighb < currentVal)
    {
      if(yMinNeighb < currentVal)
        {
	  if(zMinNeighb < currentVal)
	    temp = Compute_from_Three_Neighbors(speed, xMinNeighb, yMinNeighb, zMinNeighb);
	  else
	    temp = Compute_from_Two_Neighbors(speed,xMinNeighb,yMinNeighb);
        }
      else
        {
	  if(xMinNeighb < currentVal)
	    temp = Compute_from_Two_Neighbors(speed,xMinNeighb,xMinNeighb);
	  else
	    temp = Compute_from_One_Neighbor(speed,xMinNeighb);
        }
    }
  else
    {
      if(yMinNeighb < currentVal)
        {
	  if(zMinNeighb < currentVal)
	    temp = Compute_from_Two_Neighbors(speed,yMinNeighb,zMinNeighb);
	  else
	    temp = Compute_from_One_Neighbor(speed,yMinNeighb);
        }
      else
	temp = Compute_from_One_Neighbor(speed,zMinNeighb);
    }
  
  return Min(temp,currentVal);
}


#endif // PARALLELHCM_H
