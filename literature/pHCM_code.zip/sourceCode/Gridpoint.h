#ifndef GRIDPOINT_H
#define GRIDPOINT_H

  /*
  * =====================================================================================
  *
  *  This program is free software: you can redistribute it and/or modify
  *  it under the terms of the GNU General Public License as published by
  *  the Free Software Foundation, either version 3 of the License, or
  *  (at your option) any later version.
  *
  *  This program is distributed in the hope that it will be useful,
  *  but WITHOUT ANY WARRANTY; without even the implied warranty of
  *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  *  GNU General Public License for more details.
  *
  *  You should have received a copy of the GNU General Public License
  *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
  *
  * -------------------------------------------------------------------------------------
  *
  *       Filename:  Gridpoint.h
  *
  *        Version:   1.0
  *        Created:   6/18/13
  *        Revision:  none
  *        Compiler:  gcc/intel compiler
  *        Author:    Adam Chacon, adamdante@gmail.com
  *                   Cornell University
  *
  *        This file is a part of the numerical methods implementation/
  *        benchmarking described in the following article:
  *
  *	   http://www.math.cornell.edu/~vlad/papers/pHCM/
  *
  *	   The HCM and pHCM algorithms were developed by A. Chacon and 
  *	   A. Vladimirsky.
  *
  * =====================================================================================
  */


#include "GlobalConfiguration.h"
#include "params3D.h"
#include "ExternVars.h"
#include "GlobalVars3D.h"
#include "omp.h"
#include <assert.h>

class GridPoint
{
public:
    GridPoint();
    DOUBLE value;
    void initialize(DOUBLE v);
    DOUBLE GetVal(){return value;}
    void SetVal(DOUBLE t){value = t;}
};

inline GridPoint::GridPoint(){value = inf;}

inline void GridPoint::initialize(DOUBLE v)
{
    value = v;
}

/////////////////////////////////////////////////////////
class HeapStorable
{
public:
    HeapStorable();
    int offset;
    flags status;
};


inline HeapStorable::HeapStorable()
{
    offset = -1;
    status = FAR;
}

/////////////////////////////////////////////////////////
class FSMGridpoint: public GridPoint
{

};

/////////////////////////////////////////////////////////////////////

class FMMGridpoint:public GridPoint, public HeapStorable
{
public:
    //FMMGridpoint();
    void initialize(DOUBLE v);
    int getx(FMMGridpoint*);
    int gety(FMMGridpoint*);
    int getz(FMMGridpoint*);
};



inline void FMMGridpoint::initialize(DOUBLE v)
{
    /*Sometimes the same grid is recomputed several times,
so it is necessary to reset all data.  Additionally, the intialization is timed for performace comparison
across the different methods whereas the allocation of memory (call to the constructor) is NOT timed.*/
  GridPoint::initialize(v);
  offset = -1;
  status = FAR;
}


inline int FMMGridpoint::getx(FMMGridpoint* first)
{
  int numBetween = (this - first);
 return (int)(numBetween/(b*n));
}

inline int FMMGridpoint::gety(FMMGridpoint* first)
{
  int numBetween = (this - first);
  return (numBetween / b) % n;
}

inline int FMMGridpoint::getz(FMMGridpoint* first)
{
  int num_between = (this - first);
    return num_between % b;
}


//////////////////////////////////////////////////////////////////////////////
/*
Even though this class inherits from fmmgridpoint, "offset" is used differently in FMSM than in FMM.
In FMM the offset gives the position of a gridpoint on the heap.  Here it does that, but also records the
order of coarse gridpoint acceptance, which is used at a later point in the algorithm.

The "next" data member is set in part I of the algorithm.  The coarse gridpoints form a linked list
in the order of acceptance.

Part II of the algorithm walks along the linked list and performs fast sweeping.  The rule for
deciding the sweeping directions uses the "offset" of neighboring gridpoints.

*/


class CoarseGridpoint:public GridPoint, public HeapStorable
{
public:
    CoarseGridpoint();
    int getx(CoarseGridpoint* first);
    int gety(CoarseGridpoint* first);
    int getz(CoarseGridpoint* first);
    void Initialize(DOUBLE val);
    CoarseGridpoint* next;
};

inline CoarseGridpoint::CoarseGridpoint()
{
    next = 0;
}

inline void CoarseGridpoint::Initialize(DOUBLE val)
{
    GridPoint::initialize(val);
    offset = -1;
    status = FAR;
    next = 0;
}

inline int CoarseGridpoint::getx(CoarseGridpoint* first)
{
    //int num_between = (this-first);
    //return (int)(num_between/cm);
    int numBetween = (this-first);
    return (int)(numBetween/(cb*cn));
}

inline int CoarseGridpoint::gety(CoarseGridpoint* first)
{
    //int num_between = (this-first);
    //return num_between % cm;
    int numBetween = (this-first);
    return (numBetween / cb) % cn;
}

inline int CoarseGridpoint::getz(CoarseGridpoint *first)
{
    int num_between = (this-first);
    return num_between % cb;
}

//////////////////////////////////////////////////////
class LSMGridpoint:public GridPoint
{
public:
    LSMGridpoint();
    void initialize(DOUBLE);
    bool isLocked;
};


inline LSMGridpoint::LSMGridpoint()
    :isLocked(true){}

inline void LSMGridpoint::initialize(DOUBLE v)
{
    /*Sometimes the same grid is recomputed several times,
so it is necessary to reset all data.  Additionally, the intialization is timed for performace comparison
across the different methods whereas the allocation of memory (call to the constructor) is NOT timed.*/
    GridPoint::initialize(v);
  isLocked = true;
}
///////////////////////////////////////////////////////////////////
class cell:public GridPoint, public HeapStorable
{
public:
  cell();
  int getx(cell*);
  int gety(cell*);
  int getz(cell*);
  //bool northwest,southwest,southeast,northeast;
  bool sweepDirections[8];
};

inline  cell::cell()
{
    /*northeast = false;
    northwest = false;
    southeast = false;
    southwest = false;
    */
    for(int i = 0; i < 8; i++)
        sweepDirections[i] = false;
}

inline int cell::getx(cell* first)
{
  int numBetween = (this-first);
  ASSERT((int)(numBetween/(cb*cn)) < cm);
  ASSERT((int)(numBetween/(cb*cn)) >= 0);
    return (int)(numBetween/(cb*cn));
}

inline int cell::gety(cell* first)
{
    int numBetween = (this-first);
    ASSERT((numBetween / cb) % cn >= 0);
    return (numBetween / cb) % cn;
}

inline int cell::getz(cell* first)
{
    int num_between = (this-first);
    return num_between % cb;
}

///////////////////////////////////////////////////////////
class parallelCell : public cell
{
 public:
  parallelCell();
  omp_lock_t compLock;
  omp_lock_t posLock;
  
  //  bool beingSwept;
  int prevTid;
  int currentTid;
  int getx(parallelCell*);
  int gety(parallelCell*);
  int getz(parallelCell*);
};


inline parallelCell::parallelCell()
{
  omp_init_lock(&compLock);
  omp_init_lock(&posLock);
  currentTid = -1;
  //beingSwept = false;
  //prevTid = -1;
}


inline int parallelCell::getx(parallelCell* first)
{
  int numBetween = (this-first);
    return (int)(numBetween/(cb*cn));
}

inline int parallelCell::gety(parallelCell* first)
{
    int numBetween = (this-first);
    return (numBetween / cb) % cn;
}

inline int parallelCell::getz(parallelCell* first)
{
    int num_between = (this-first);
    return num_between % cb;
}



#endif // GRIDPOINT_H
