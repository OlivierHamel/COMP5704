  /*
  * =====================================================================================
  *
  *  This program is free software: you can redistribute it and/or modify
  *  it under the terms of the GNU General Public License as published by
  *  the Free Software Foundation, either version 3 of the License, or
  *  (at your option) any later version.
  *
  *  This program is distributed in the hope that it will be useful,
  *  but WITHOUT ANY WARRANTY; without even the implied warranty of
  *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  *  GNU General Public License for more details.
  *
  *  You should have received a copy of the GNU General Public License
  *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
  *
  * -------------------------------------------------------------------------------------
  *
  *       Filename:  HeapGeneral.h
  *
  *        Version:   1.0
  *        Created:   6/18/13
  *        Revision:  none
  *        Compiler:  gcc/intel compiler
  *        Author:    Adam Chacon, adamdante@gmail.com
  *                   Cornell University
  *
  *        This file is a part of the numerical methods implementation/
  *        benchmarking described in the following article:
  *
  *	   http://www.math.cornell.edu/~vlad/papers/pHCM/
  *
  *	   The HCM and pHCM algorithms were developed by A. Chacon and 
  *	   A. Vladimirsky.
  *
  * =====================================================================================
  */


#ifndef HEAPGENERAL_H
#define HEAPGENERAL_H

/*
This heap can be used with any objects that have an "offset" and a "value".
   */

#include "GlobalConfiguration.h"
#include "Gridpoint.h"
#include "omp.h"

template <class T>
        class  HeapGeneral
{
public:
    HeapGeneral();
    ~HeapGeneral();
    void Initialize(int k);
    int currently_used;
    T** L;
    inline bool upheap(int);
    inline bool downheap();
    bool verify();
    bool add(T*w);
    int verifycounter;

};

template <class T>
        void HeapGeneral<T>::Initialize(int k)
{
    L = new T*[k];
    currently_used = 0;
    verifycounter = 0;
}

template <class  T>
        bool HeapGeneral<T>::add(T* w)
{
    /*FMM uses statuses {ACCEPTED, CONSIDERED, FAR}.
    HCM uses statuses on cells {IN, OUT}. See params3D.h.  */

    L[currently_used] = w;
    w->status = IN;
    w->offset = currently_used;
    currently_used++;
    return upheap(currently_used - 1);
}



template <class  T>
        HeapGeneral<T>::HeapGeneral()
{

}


template <class T>
        HeapGeneral<T>::~HeapGeneral()
{
    delete [] L;
}

template <class T>
        bool HeapGeneral<T>::verify()
{//checks that the heap is balanced
    bool flag = true;
    int parent;
    verifycounter = 0;

    for(int i = 1; i < currently_used; i++) //loops on all children
    {
        assert(L[i]->status == CONSIDERED || L[i]->status == IN);
        parent = (int)((DOUBLE)(i-1)/2);
        if(L[i]->value < L[parent]->value)
        {
            verifycounter++;
            flag = false;
        }
    }

    ASSERT(flag);
    return flag;
}


template <class T>
        inline bool HeapGeneral<T>::upheap(int end)
{
    //Beginning with "end" this function continues to swap elements
    //in the heap with its parent until the heap is balanced.
    int parentIndex, childIndex;
    bool switchedOnce = false;
    DOUBLE gpVal;
    T *gpAddress, *parentAddress;
    //ASSERT(end >= 0);
    ASSERT(end <= currently_used);

    childIndex = end;
    gpAddress = L[childIndex];
    gpVal = gpAddress->value;
    //Note: gpAddress is the address of the gridpoint being moved.
    //Note: the location of the gridpoint being pushed up is not up-to-date until after the while loop.
    while(childIndex > 0)
    {
        parentIndex = (int)((childIndex-1)/2);
        parentAddress = L[parentIndex];
        if(gpVal < parentAddress->value)
        {
            switchedOnce = true;
            L[childIndex] = parentAddress;
            parentAddress->offset = childIndex;
            childIndex = parentIndex;
        }
        else
            break;
    }
    //Finally, update the location of the gridpoint that was being pushed up.
    if(switchedOnce)
    {
        L[childIndex] = gpAddress;
        gpAddress->offset = childIndex;
    }
#ifdef SERIOUS_DEBUG
    return verify();
#else
    return true;
#endif
}



template <class T>
        bool HeapGeneral<T>::downheap()
{
  //Last modified 6/5/11.
  //downheapCounter++;
  //The status of the cell or gridpoint should be changed right before calling this function.

    int		currentIndex, smallerIndex, child1Index, child2Index, currentIndexTimes2;
    DOUBLE	smallerValue, child1Val, child2Val, currentVal;
    bool balancedHeap = false;
    ASSERT(currently_used > 0);
    L[0]->offset = -1; // indicate that the old root is no longer on the heap
    currently_used--;

    // Note: this is an optimized version of "downheap"
    // -- the heap is inconsistent while we are in the process of pushing down.

    if(currently_used > 0)
    {

        currentIndex = 0;
        currentVal = L[currently_used]->value; //value at last element of L, "placing" it at beginning.  Updating the actual gridpoint is delayed for now.

        do
        {
            currentIndexTimes2 = currentIndex*2;
            //1.  Get indices of children
            if(currentIndexTimes2 + 2 < currently_used) //if currentIndex has two children
            {
                child1Index = currentIndexTimes2 + 1;
                child2Index = currentIndexTimes2 + 2;
                child1Val = L[child1Index]->value;
                child2Val = L[child2Index]->value;
                if(child1Val < child2Val)
                {
                    smallerValue = child1Val;
                    smallerIndex = child1Index;
                }
                else
                {
                    smallerValue = child2Val;
                    smallerIndex = child2Index;
                }
            }
            else //current has 1 or 0 children.
            {
                if(currentIndexTimes2 + 1 < currently_used) //if currentIndex has exactly one child
                {
                    smallerIndex = currentIndexTimes2 + 1;
                    smallerValue = L[smallerIndex]->value;
                }
                else //currentIndex has no children
                    balancedHeap = true;
            }

            //2.  Swap with smaller child if necessary.
            if(!balancedHeap)//if currentIndex has 1 or 2 children
            {
                if(smallerValue < currentVal)
                {
                    //Note: we simply push up the smaller child;
                    //its old entry in the heap is still pointing to it as well.
                    //The entry of the pushed-down node is still located at L[currently_used]
                    //(strictly speaking, after the end of the heap); its offset is not updated
                    //untill we are done pushing-down & exit the loop.
                    L[currentIndex] = L[smallerIndex];
                    L[currentIndex]->offset = currentIndex;

                    currentIndex = smallerIndex;
                }
                else
                    balancedHeap = true;
            }
        }while(!balancedHeap);

        //ok, now we finally update the pushed-down node to its rightful location
        L[currentIndex] = L[currently_used];
        L[currentIndex]->offset = currentIndex;

    }

#ifdef SERIOUS_DEBUG
    return verify();
#else
    return true;
#endif

}

///////////////////////////////////////////////////////
class parallelHeap : public HeapGeneral<parallelCell>
{
public:
    omp_lock_t lock;
    parallelHeap(){omp_init_lock(&lock);}//
    bool IsEmpty() {return (currently_used == 0);}
    int GetCurrentlyIn(){return currently_used;}
};


#endif // HEAPGENERAL_H
