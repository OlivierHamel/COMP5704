  /*
  * =====================================================================================
  *
  *  This program is free software: you can redistribute it and/or modify
  *  it under the terms of the GNU General Public License as published by
  *  the Free Software Foundation, either version 3 of the License, or
  *  (at your option) any later version.
  *
  *  This program is distributed in the hope that it will be useful,
  *  but WITHOUT ANY WARRANTY; without even the implied warranty of
  *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  *  GNU General Public License for more details.
  *
  *  You should have received a copy of the GNU General Public License
  *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
  *
  * -------------------------------------------------------------------------------------
  *
  *       Filename:  timingInfo.h
  *
  *        Version:   1.0
  *        Created:   6/18/13
  *        Revision:  none
  *        Compiler:  gcc/intel compiler
  *        Author:    Adam Chacon, adamdante@gmail.com
  *                   Cornell University
  *
  *        This file is a part of the numerical methods implementation/
  *        benchmarking described in the following article:
  *
  *	   http://www.math.cornell.edu/~vlad/papers/pHCM/
  *
  *	   The HCM and pHCM algorithms were developed by A. Chacon and 
  *	   A. Vladimirsky.
  *
  * =====================================================================================
  */


#include "GlobalConfiguration.h"
#include "GlobalVars3D.h"
#include "ExternVars.h"
#include "params3D.h"
#include <math.h>
#include <fstream>
#include <iostream>
#include <iomanip>


//The J or P or M or MJ or PJ that follows the variable names give the scaling.
class Performance
{

 private:
  DOUBLE** fmmSpeedUp_MJ;
  DOUBLE** hcmSpeedUp_MJ;

  DOUBLE** fmmSpeedUp_PJ;
  DOUBLE** hcmSpeedUp_PJ;
  DOUBLE** hcmTimes_MJ;
  DOUBLE** phcmTimes_MJ;
  DOUBLE** phcmTimes_PJ;
  DOUBLE** phcmOverheadPercDiff_PJ;
  DOUBLE** AvS_ratio_PJ; //ratio of pHCM total AvS to HCM AvS
  
  DOUBLE* hcmTimes_J;
  DOUBLE* hcmAvS_J;
  DOUBLE* hcmOverheadPerc_J;
  DOUBLE* lsmTimes;
  DOUBLE* fmmTimes;
  DOUBLE* detrixheFSMTimes_P;
  DOUBLE* detrixheLSMTimes_P;
  DOUBLE* fsmTimes;

  DOUBLE* detrixheFSMSpeedUp_P;
  DOUBLE* detrixheLSMSpeedUp_P;

 public:
  Performance(int m1, int numMsteps, int stepSize);
  ~Performance();

  DOUBLE fmmTime;
  DOUBLE pHCMTime;
  DOUBLE hcmTime;
  DOUBLE lsmTime;
  DOUBLE fsmTime;
  DOUBLE hcmCellCompTime;
  DOUBLE pHCMCellCompTime;
  DOUBLE detrixheFSMTime;
  DOUBLE detrixheLSMTime;
  int* numSweeps;

  int mMin, mMax, numMStep, mStepSize;
  //int gpPerCell;
  int jMin, jMax;

  void setSpeedUps_MJ(int mIndex, int jIndex);
  void setSpeedUps_PJ(int pIndex, int jIndex);
  void writeMatlabFile(bool MJ);
  void writeLatexFile();
  void writeLatexFile2();
  void writeLatexFile3();
  void setRawTimes_MJ(int mIndex,int jIndex);
  void setRawTimes_PJ(int pIndex, int jIndex);
  void setAvSData(DOUBLE HCM_AvS, DOUBLE pHCM_AvS, int pIndex, int jIndex);

};

Performance::Performance(int m1, int numMsteps, int stepSize)
{

  int i;
  /*The cells are assumed to be subdivided into 2 each time, i.e., see jMax */
  mMin = m1;
  numMStep = numMsteps;
  mStepSize = stepSize;
  mMax = m1 + (numMsteps - 1)*stepSize;
  jMin = numCellsStart; //global
  //numCellDivs = numDivs; numCellDivs is already a global variable.
  jMax = (int) jMin* (int)pow(2,numCellDivs - 1); 
  //Note: numCellDivs == 1 mean ONE cell trial with 0 subdivisions.

  fmmTimes = new DOUBLE[numMStep];
  lsmTimes = new DOUBLE[numMStep];
  fsmTimes = new DOUBLE[numMStep];
  numSweeps = new int[numMStep];

  hcmTimes_J = new DOUBLE[numCellDivs];
  hcmOverheadPerc_J = new DOUBLE[numCellDivs];
  hcmAvS_J = new DOUBLE[numCellDivs];

  hcmTimes_MJ = new DOUBLE*[numMStep];
  hcmTimes_MJ[0] = new DOUBLE[numMStep*numCellDivs];

  phcmTimes_MJ = new DOUBLE*[numMStep];
  phcmTimes_MJ[0] = new DOUBLE[numMStep*numCellDivs];

  detrixheFSMSpeedUp_P = new DOUBLE[numPTrials];
  detrixheLSMSpeedUp_P = new DOUBLE[numPTrials];
  detrixheFSMTimes_P = new DOUBLE[numPTrials];
  detrixheLSMTimes_P = new DOUBLE[numPTrials];


  phcmTimes_PJ = new DOUBLE*[numPTrials];
  phcmTimes_PJ[0] = new DOUBLE[numPTrials*numCellDivs];
  phcmOverheadPercDiff_PJ = new DOUBLE*[numPTrials];
  phcmOverheadPercDiff_PJ[0] = new DOUBLE[numPTrials*numCellDivs];
  AvS_ratio_PJ = new DOUBLE*[numPTrials];
  AvS_ratio_PJ[0] = new DOUBLE[numPTrials*numCellDivs];

  
  fmmSpeedUp_PJ = new DOUBLE*[numPTrials];
  fmmSpeedUp_PJ[0] = new DOUBLE[numPTrials*numCellDivs];
  hcmSpeedUp_PJ = new DOUBLE*[numPTrials];
  hcmSpeedUp_PJ[0] = new DOUBLE[numPTrials*numCellDivs];

  fmmSpeedUp_MJ = new DOUBLE*[numMStep];
  fmmSpeedUp_MJ[0] = new DOUBLE[numMStep*numCellDivs];
  hcmSpeedUp_MJ = new DOUBLE*[numMStep];
  hcmSpeedUp_MJ[0] = new DOUBLE[numMStep*numCellDivs];

  for(i = 1; i < numPTrials; i++)
    {
      phcmTimes_PJ[i] = phcmTimes_PJ[0] + i*numCellDivs;
      phcmOverheadPercDiff_PJ[i] = phcmOverheadPercDiff_PJ[0] + i*numCellDivs;
      AvS_ratio_PJ[i] = AvS_ratio_PJ[0] + i*numCellDivs;
      fmmSpeedUp_PJ[i] = fmmSpeedUp_PJ[0] + i*numCellDivs;
      hcmSpeedUp_PJ[i] = hcmSpeedUp_PJ[0] + i*numCellDivs;
    }

  for(i = 1; i < numMStep; i++)
    {
      phcmTimes_MJ[i] = phcmTimes_MJ[0] + i*numCellDivs;
      hcmTimes_MJ[i] = hcmTimes_MJ[0] + i*numCellDivs;
      fmmSpeedUp_MJ[i] = fmmSpeedUp_MJ[0] + i*numCellDivs;
      hcmSpeedUp_MJ[i] = hcmSpeedUp_MJ[0] + i*numCellDivs;
    }
}

Performance::~Performance()
{
  delete [] fmmTimes;
  delete [] lsmTimes;
  delete [] fsmTimes;
  delete [] hcmTimes_J;
  delete [] hcmOverheadPerc_J;
  delete [] hcmAvS_J;
  delete [] numSweeps;

  delete [] detrixheFSMSpeedUp_P;
  delete [] detrixheLSMSpeedUp_P;
  delete [] detrixheFSMTimes_P;
  delete [] detrixheLSMTimes_P;

  delete [] fmmSpeedUp_PJ[0];
  delete [] fmmSpeedUp_PJ;
  delete [] hcmSpeedUp_PJ[0];
  delete [] hcmSpeedUp_PJ;

  delete [] phcmTimes_PJ[0];
  delete [] phcmTimes_PJ;

  delete [] phcmOverheadPercDiff_PJ[0];
  delete [] phcmOverheadPercDiff_PJ;

  delete [] AvS_ratio_PJ[0];
  delete [] AvS_ratio_PJ;

  delete [] phcmTimes_MJ[0];
  delete [] phcmTimes_MJ;
  delete [] hcmTimes_MJ[0];
  delete [] hcmTimes_MJ;
  delete [] fmmSpeedUp_MJ[0];
  delete [] fmmSpeedUp_MJ;
  delete [] hcmSpeedUp_MJ[0];
  delete [] hcmSpeedUp_MJ;
}

void Performance::setSpeedUps_MJ(int mIndex, int jIndex)
{
  //int mIndex;
  //mIndex = (m - mMin)/mStepSize;  //"m" is global to entire program. 

  fmmSpeedUp_MJ[mIndex][jIndex] = fmmTime/pHCMTime;
  hcmSpeedUp_MJ[mIndex][jIndex] = hcmTime/pHCMTime;

}

void Performance::setRawTimes_MJ(int mIndex, int jIndex)
{
  fmmTimes[mIndex] = fmmTime;
  fsmTimes[mIndex] = fsmTime;
  lsmTimes[mIndex] = lsmTime;
  hcmTimes_MJ[mIndex][jIndex] = hcmTime;
  phcmTimes_MJ[mIndex][jIndex] = pHCMTime;
}

void Performance::setSpeedUps_PJ(int pIndex, int jIndex)
{
  fmmSpeedUp_PJ[pIndex][jIndex] = fmmTime/pHCMTime;
  hcmSpeedUp_PJ[pIndex][jIndex] = hcmTime/pHCMTime;
  
  detrixheFSMSpeedUp_P[pIndex] = fsmTime/detrixheFSMTime;
  detrixheLSMSpeedUp_P[pIndex] = lsmTime/detrixheLSMTime;
  
}

void Performance::setRawTimes_PJ(int pIndex, int jIndex)
{
  DOUBLE pHCM_OvhdPerc, HCM_OvhdPerc;
  fmmTimes[0] = fmmTime;
  lsmTimes[0] = lsmTime;
  fsmTimes[0] = fsmTime;
  hcmTimes_J[jIndex] = hcmTime;

  HCM_OvhdPerc = 1 - (hcmCellCompTime/hcmTime);
  hcmOverheadPerc_J[jIndex] = HCM_OvhdPerc;

  phcmTimes_PJ[pIndex][jIndex] = pHCMTime;
  detrixheFSMTimes_P[pIndex] = detrixheFSMTime;
  detrixheLSMTimes_P[pIndex] = detrixheLSMTime;
  
  pHCM_OvhdPerc = 1 -(pHCMCellCompTime/pHCMTime);
  phcmOverheadPercDiff_PJ[pIndex][jIndex] = 100*(pHCM_OvhdPerc - HCM_OvhdPerc);
  //assert(HCM_OvhdPerc < 1.1*pHCM_OvhdPerc);
  
}

void Performance::setAvSData(DOUBLE HCM_AvS, DOUBLE pHCM_AvS, int pIndex, int jIndex)
{
  hcmAvS_J[jIndex] = HCM_AvS;
  AvS_ratio_PJ[pIndex][jIndex] = pHCM_AvS/HCM_AvS;
}

void Performance::writeMatlabFile(bool MJ)
{
  ofstream matlabFile;
  int i,j;
  matlabFile.open("EikonalTimingData_MJ_early.m");
  matlabFile<<"%The speedups are structured as row = numGridpoints, column = numGPs per cell side,"<<endl;
  matlabFile<<"%or row = numthreads, column = numGPs per cell side."<<endl;
  matlabFile<<"%The bottom row of each speedup array corresponds to the LARGEST m. "<<endl;
  matlabFile<<"%J now gives the number of GPs per cell. "<<endl;

  matlabFile<<"cellDivs = 1:"<<numCellDivs<<";"<<endl;
  matlabFile<<"numCellDivs = cellDivs(end);"<<endl;

  if(numPTrials == 1)
    matlabFile<<"M = "<<m<<";"<<endl;
  else
    matlabFile<<"M = "<<mMin<<":"<<mStepSize<<":"<<mMax<<";"<<endl;

  if(numPTrials == 1)
    matlabFile<<"numProcs = "<<numthreads<<";"<<endl;
  else
    matlabFile<<"numProcs = 1:"<<numPTrials<<";"<<endl;

  matlabFile<<"J = 2.^cellDivs"<<";"<<endl;


  matlabFile<<"rawFMMtimes = ["<<endl;
  for(i = 0; i < numMStep; i++)
    {
      matlabFile<<fmmTimes[i]<<" ";
    }
  matlabFile<<" ];"<<endl;

  matlabFile<<"rawLSMtimes = ["<<endl;
  for(i = 0; i < numMStep; i++)
    {
      matlabFile<<lsmTimes[i]<<" ";
    }
  matlabFile<<" ];"<<endl;


  matlabFile<<"rawFSMtimes = ["<<endl;
  for(i = 0; i < numMStep; i++)
    {
      matlabFile<<fsmTimes[i]<<" ";
    }
  matlabFile<<" ];"<<endl;


  matlabFile<<"rawHCMtimes_J = ["<<endl;
  for(i = 0; i < numCellDivs; i++)
    {
      matlabFile<<hcmTimes_J[i]<<" ";
    }
  matlabFile<<" ];"<<endl;

  matlabFile<<"HCM_OverheadPerc_J = ["<<endl;
  for(i = 0; i < numCellDivs; i++)
    {
      matlabFile<<100*hcmOverheadPerc_J[i]<<" ";
    }
  matlabFile<<" ];"<<endl;


  /////////////////////////////////////////////
  matlabFile<<"HCM_AvS = ["<<endl;
  for(i = 0; i < numCellDivs; i++)
    {
      matlabFile<<hcmAvS_J[i]<<" ";
    }
  matlabFile<<" ];"<<endl;


  /////////////////////////////////////////////


  matlabFile<<"rawDetrixheFSMTimes_P = ["<<endl;
  for(i = 0; i < numPTrials; i++)
    {
      matlabFile<<detrixheFSMTimes_P[i]<<" ";
    }
  matlabFile<<" ];"<<endl;

  matlabFile<<"rawDetrixheLSMTimes_P = ["<<endl;
  for(i = 0; i < numPTrials; i++)
    {
      matlabFile<<detrixheLSMTimes_P[i]<<" ";
    }
  matlabFile<<" ];"<<endl;


  matlabFile<<"DetrixheLSMSpeedup_P = ["<<endl;
  for(i = 0; i < numPTrials; i++)
    {
      matlabFile<<detrixheLSMSpeedUp_P[i]<<" ";
    }
  matlabFile<<" ];"<<endl;

  matlabFile<<"DetrixheFSMSpeedup_P = ["<<endl;
  for(i = 0; i < numPTrials; i++)
    {
      matlabFile<<detrixheFSMSpeedUp_P[i]<<" ";
    }
  matlabFile<<" ];"<<endl;

  

  if(MJ)
    {
    
      matlabFile<<"rawHCMtimes_MJ = ["<<endl;
      for(i = 0; i < numMStep; i++)
	{
	  for(j = 0; j < numCellDivs; j++)
	    matlabFile<<hcmTimes_MJ[i][j]<<" ";
	  matlabFile<<endl;
	}
      matlabFile<<" ];"<<endl;
      
      matlabFile<<"rawPHCMtimes_MJ = ["<<endl;
      for(i = 0; i < numMStep; i++)
	{
	  for(j = 0; j < numCellDivs; j++)
	    matlabFile<<phcmTimes_MJ[i][j]<<" ";
	  matlabFile<<endl;
	}
      matlabFile<<" ];"<<endl;
      
      
      matlabFile<<"hcmSpeedUp_MJ = ["<<endl;
      for(i = 0; i < numMStep; i++)
	{
	  for(j = 0; j < numCellDivs; j++)
	    matlabFile<<hcmSpeedUp_MJ[i][j]<<" ";
	  matlabFile<<endl;
	}
      matlabFile<<" ];"<<endl;
      
      matlabFile<<"fmmSpeedUp_MJ = ["<<endl;
      for(i = 0; i < numMStep; i++)
	{
	  for(j = 0; j < numCellDivs; j++)
	    matlabFile<<fmmSpeedUp_MJ[i][j]<<" ";
	  matlabFile<<endl;
	}
      matlabFile<<" ];"<<endl;
    }  
 


  else
    {


      matlabFile<<"hcmSpeedUp_PJ = ["<<endl;
      for(i = 0; i < numPTrials; i++)
	{
	  for(j = 0; j < numCellDivs; j++)
	    matlabFile<<hcmSpeedUp_PJ[i][j]<<" ";
	  matlabFile<<endl;
	}
      matlabFile<<" ];"<<endl;
      
      matlabFile<<"fmmSpeedUp_PJ = ["<<endl;
      for(i = 0; i < numPTrials; i++)
	{
	  for(j = 0; j < numCellDivs; j++)
	    matlabFile<<fmmSpeedUp_PJ[i][j]<<" ";
	  matlabFile<<endl;
	}
      matlabFile<<" ];"<<endl<<endl;
      
      matlabFile<<"%ADDITIONAL OVERHEAD: "<<endl;
      matlabFile<<"pHCM_OverheadPerc_PJ = ["<<endl;
      for(i = 0; i < numPTrials; i++)
	{
	  for(j = 0; j < numCellDivs; j++)
	    matlabFile<<phcmOverheadPercDiff_PJ[i][j]<<" ";
	  matlabFile<<endl;
	}
      matlabFile<<" ];"<<endl;
      
      
      //////////////////////////////////////////////////////////////////////
      matlabFile<<"%WORK RATIO (SWEEPS): "<<endl;
      matlabFile<<"pHCM_Work_PJ = ["<<endl;
      for(i = 0; i < numPTrials; i++)
	{
	  for(j = 0; j < numCellDivs; j++)
	    matlabFile<<AvS_ratio_PJ[i][j]<<" ";
	  matlabFile<<endl;
	}
      matlabFile<<" ];"<<endl;
      
      
      /////////////////////////////////////////////////////////////////////
      
      
      
      matlabFile<<"pHCM_RawTimes = zeros(numProcs(end),numCellDivs);"<<endl;
      matlabFile<<"lsmSpeedUp_PJ = zeros(numProcs(end),numCellDivs);"<<endl;
      matlabFile<<"for i = 1:numCellDivs"<<endl;
      matlabFile<<"   pHCM_RawTimes(:,i) = rawHCMtimes_J(i)./hcmSpeedUp_PJ(:,i);"<<endl;
      matlabFile<<"   lsmSpeedUp_PJ(:,i) = rawLSMtimes(1)./pHCM_RawTimes(:,i);"<<endl;
      matlabFile<<"end"<<endl;
      
    }
 

 matlabFile.close();
}



void Performance::writeLatexFile()
{
  /*This function creates tables comparing total amount of work increase and cell comp percent measurements in 
tex readable format.  Gives Cell Comp time RATIOS (phcm to hcm) and AvS ratios. */
  float AvS_thresh = 1.5;
  float addOverheadThresh = 15;


  ofstream texFile;
  texFile.open("pHCM_Analysis.txt");
  texFile<<setprecision(3);
  texFile<<"%These are the tables for the pHCM paper."<<endl;
  texFile<<endl<<"%m = "<<m<<endl<<endl;


  //Table 1: HCM data only:
  texFile<<"\\begin{table}[h] \\footnotesize"<<endl;
  texFile<<"\\begin{center}"<<endl;
  texFile<<"\\caption{Performance analysis of HCM and pHCM for $F ";
  switch(speed_fun)
    {
    case constantf:
      texFile<<"\\equiv 1$.}"<<endl;
      break;

    case sinusoid1:
      texFile<<"= 1 + .5\\sin(20\\pi x)\\sin(20\\pi y)\\sin(20\\pi z)$.}"<<endl;
      break;

    case sinusoid2:
      texFile<<"= 1 + .99\\sin(2\\pi x)\\sin(2\\pi y)\\sin(2\\pi z)$.}"<<endl;
      break;
    }
  texFile<<"\\vspace*{2mm}"<<endl;
  texFile<<"\\begin{tabular}{|c|c|c|c|c|}"<<endl;
  texFile<<"\\hline"<<endl;
  texFile<<" & \\textbf{HCM16} & \\textbf{HCM8} & \\textbf{HCM4} & ";
  texFile<<"\\textbf{HCM2}\\\\"<<endl;
  texFile<<"\\hline"<<endl;
  texFile<<"\\textbf{AvS}  &"<<hcmAvS_J[3]<<" & "<<hcmAvS_J[2]<<" & ";
  texFile<<hcmAvS_J[1]<<" & "<<hcmAvS_J[0]<<"\\\\"<<endl;
  texFile<<"\\hline"<<endl;
  texFile<<"\\textbf{Overhead \\%}  & "<<100*hcmOverheadPerc_J[3]<<" & ";
  texFile<<100*hcmOverheadPerc_J[2]<<" & "<<100*hcmOverheadPerc_J[1]<<" & ";
  texFile<<100*hcmOverheadPerc_J[0]<<"\\\\"<<endl;
  texFile<<"\\hline"<<endl;
  texFile<<"\\end{tabular}"<<endl;

  texFile<<"\\vspace*{.5cm}"<<endl;
  //texFile<<setprecision(2);

  //table 2
  texFile<<"\\begin{tabular}{|c||c|c|c|c|}"<<endl;
  texFile<<"\\hline"<<endl;
  texFile<<"\\textbf{p} & \\textbf{pHCM16} & \\textbf{pHCM8} & \\textbf{pHCM4}";
  texFile<<" & \\textbf{pHCM2} \\\\ "<<endl;
  texFile<<"\\hline"<<endl;
  texFile<<"\\vspace*{-.4cm}"<<endl;
  texFile<<"&&&&\\\\"<<endl;
  for(int p = 0; p < numPTrials; p++)
    {
      texFile<<"\\hline"<<endl;
      texFile<<p+1<<" & \\backslashbox{";
      
      if(AvS_ratio_PJ[p][3] > AvS_thresh)
	 texFile<<"\\color{red}"<<AvS_ratio_PJ[p][3]<<"}{";
      else
	texFile<<AvS_ratio_PJ[p][3]<<"}{";
      
      if(phcmOverheadPercDiff_PJ[p][3] > addOverheadThresh)
	texFile<<"\\color{purple}"<<phcmOverheadPercDiff_PJ[p][3];
      else
	texFile<<phcmOverheadPercDiff_PJ[p][3];
      texFile<<"} & \\backslashbox{";

      if(AvS_ratio_PJ[p][2] > AvS_thresh)
	texFile<<"\\color{red}"<<AvS_ratio_PJ[p][2];
      else
	  texFile<<AvS_ratio_PJ[p][2];
      texFile<<"}{";
      
      if(phcmOverheadPercDiff_PJ[p][2] > addOverheadThresh)
	texFile<<"\\color{purple}"<<phcmOverheadPercDiff_PJ[p][2];
      else
	texFile<<phcmOverheadPercDiff_PJ[p][2];
     
      texFile<<"} &  \\backslashbox{";

      if(AvS_ratio_PJ[p][1] > AvS_thresh)
	texFile<<"\\color{red}"<<AvS_ratio_PJ[p][1]<<"}{";
      else
	texFile<<AvS_ratio_PJ[p][1]<<"}{";

      if(phcmOverheadPercDiff_PJ[p][1] > addOverheadThresh)
	texFile<<"\\color{purple}"<<phcmOverheadPercDiff_PJ[p][1];
      else
	texFile<<phcmOverheadPercDiff_PJ[p][1];
      texFile<<"} & \\backslashbox{";

      if(AvS_ratio_PJ[p][0] > AvS_thresh)
	texFile<<"\\color{red}"<<AvS_ratio_PJ[p][0];
      else
	texFile<<AvS_ratio_PJ[p][0];

      if(phcmOverheadPercDiff_PJ[p][0] > addOverheadThresh)
	texFile<<"}{"<<"\\color{purple}"<<phcmOverheadPercDiff_PJ[p][0];
      else
	texFile<<"}{"<<phcmOverheadPercDiff_PJ[p][0];
      texFile<<"} \\\\"<<endl;
    }
  texFile<<"\\hline"<<endl;
  texFile<<"\\end{tabular}"<<endl<<endl;
  texFile<<"\\end{center}"<<endl<<endl;
  texFile<<"\\end{table}"<<endl;


  texFile.close();
}

void Performance::writeLatexFile2()
{
  //Same as the above function but with different formatting. 4/17/12.
  float AvS_thresh = 1.2;
  float addOverheadThresh = 15;


  ofstream texFile;
  texFile.open("pHCM_Analysis.txt");
  texFile<<setprecision(3);
  

  //Table 1: HCM data only:

  assert(numCellDivs == 5);
  texFile<<"\\begin{table}[h] \\footnotesize"<<endl;
  texFile<<"\\begin{center}"<<endl;
  texFile<<"\\caption{Performance analysis of HCM on Ex. ";
  switch(speed_fun)
    {
    case constantf:
      texFile<<"1, ";
      break;

    case sinusoid1:
      texFile<<"2, ";
      break;

    case sinusoid2:
      texFile<<"3, ";
      break;
    }
  texFile<<", $M ="<<m<<"^3$.}";
  texFile<<"\\vspace*{2mm}"<<endl;
  texFile<<"\\begin{tabular}{|c|c|c|c|c|c|}"<<endl;
  texFile<<"\\hline"<<endl;
  texFile<<"& \\textbf{HCM32} & \\textbf{HCM16} & \\textbf{HCM8} & \\textbf{HCM4} & ";
  texFile<<"\\textbf{HCM2}\\\\"<<endl;
  texFile<<"\\hline"<<endl;
  texFile<<"\\textbf{Avg. Sweeps per Cell}  &"<<hcmAvS_J[4]<<" & "<<hcmAvS_J[3]<<" & ";
  texFile<<hcmAvS_J[2]<<" & "<<hcmAvS_J[1]<<" & "<<hcmAvS_J[0]<<"\\\\"<<endl;
  texFile<<"\\hline"<<endl;
  texFile<<"\\textbf{Heap Maintenance \\%}  & "<<100*hcmOverheadPerc_J[4]<<" & ";
  texFile<<100*hcmOverheadPerc_J[3]<<" & "<<100*hcmOverheadPerc_J[2]<<" & ";
  texFile<<100*hcmOverheadPerc_J[1]<<" & "<<100*hcmOverheadPerc_J[0]<<"\\\\"<<endl;
  texFile<<"\\hline"<<endl;
  texFile<<"\\end{tabular}"<<endl;

  texFile<<"\\vspace*{.5cm}"<<endl;



  //table 2 (in the current version this information is presented in chart form; data available in
  // writeMatlabFile();
  //texFile<<setprecision(2);
  /*
  texFile<<"\\begin{tabular}{|c||c|c|c|c|}"<<endl;
  texFile<<"\\hline"<<endl;
  texFile<<"\\textbf{p} & \\textbf{pHCM16} & \\textbf{pHCM8} & \\textbf{pHCM4}";
  texFile<<" & \\textbf{pHCM2} \\\\ "<<endl;
  texFile<<"\\hline"<<endl;
  texFile<<"\\vspace*{-.3cm}"<<endl;
  texFile<<"&&&&\\\\"<<endl;
  for(int p = 0; p < numPTrials; p++)
    {
      texFile<<"\\hline"<<endl;
      texFile<<p+1<<" & {";
      
      if(AvS_ratio_PJ[p][3] > AvS_thresh)
	 texFile<<"\\color{red}"<<AvS_ratio_PJ[p][3]<<"} / {";
      else
	texFile<<AvS_ratio_PJ[p][3]<<"} / {";
      
      if(phcmOverheadPercDiff_PJ[p][3] > addOverheadThresh)
	texFile<<"\\color{purple}"<<phcmOverheadPercDiff_PJ[p][3];
      else
	texFile<<phcmOverheadPercDiff_PJ[p][3];
      texFile<<"} & {";

      if(AvS_ratio_PJ[p][2] > AvS_thresh)
	texFile<<"\\color{red}"<<AvS_ratio_PJ[p][2];
      else
	  texFile<<AvS_ratio_PJ[p][2];
      texFile<<"} / {";
      
      if(phcmOverheadPercDiff_PJ[p][2] > addOverheadThresh)
	texFile<<"\\color{purple}"<<phcmOverheadPercDiff_PJ[p][2];
      else
	texFile<<phcmOverheadPercDiff_PJ[p][2];
     
      texFile<<"} &  {";

      if(AvS_ratio_PJ[p][1] > AvS_thresh)
	texFile<<"\\color{red}"<<AvS_ratio_PJ[p][1]<<"} / {";
      else
	texFile<<AvS_ratio_PJ[p][1]<<"} / {";

      if(phcmOverheadPercDiff_PJ[p][1] > addOverheadThresh)
	texFile<<"\\color{purple}"<<phcmOverheadPercDiff_PJ[p][1];
      else
	texFile<<phcmOverheadPercDiff_PJ[p][1];
      texFile<<"} & {";

      if(AvS_ratio_PJ[p][0] > AvS_thresh)
	texFile<<"\\color{red}"<<AvS_ratio_PJ[p][0];
      else
	texFile<<AvS_ratio_PJ[p][0];

      if(phcmOverheadPercDiff_PJ[p][0] > addOverheadThresh)
	texFile<<"} / {"<<"\\color{purple}"<<phcmOverheadPercDiff_PJ[p][0];
      else
	texFile<<"} / {"<<phcmOverheadPercDiff_PJ[p][0];
      texFile<<"} \\\\"<<endl;
    }
  texFile<<"\\hline"<<endl;
  texFile<<"\\end{tabular}"<<endl<<endl;
  texFile<<"\\end{center}"<<endl<<endl;
  texFile<<"\\end{table}"<<endl;

  */

  texFile.close();


}




void Performance::writeLatexFile3()
{
  //Prints a single line in the table of the number of sweeps LSM does for different M.

  int i;
  ofstream texFile;
  texFile.open("numSweeps_M.txt");
  texFile<<setprecision(3);
  


  //assert(numMTrials == 5);
  texFile<<"\\hline"<<endl;
  if(sizeof(DOUBLE) == 8)
    texFile<<"\\textbf{double} ";
  if(sizeof(DOUBLE) == 4)
    texFile<<"\\textbf{single} ";

  for(i = 0; i < numMTrials; i++)
    {
      texFile<<" & "<<numSweeps[i];
    }
  texFile<<"\\\\"<<endl;


  texFile.close();
}
