  /*
  * =====================================================================================
  *
  *  This program is free software: you can redistribute it and/or modify
  *  it under the terms of the GNU General Public License as published by
  *  the Free Software Foundation, either version 3 of the License, or
  *  (at your option) any later version.
  *
  *  This program is distributed in the hope that it will be useful,
  *  but WITHOUT ANY WARRANTY; without even the implied warranty of
  *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  *  GNU General Public License for more details.
  *
  *  You should have received a copy of the GNU General Public License
  *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
  *
  * -------------------------------------------------------------------------------------
  *
  *       Filename:  params3D.h
  *
  *        Version:   1.0
  *        Created:   6/18/13
  *        Revision:  none
  *        Compiler:  gcc/intel compiler
  *        Author:    Adam Chacon, adamdante@gmail.com
  *                   Cornell University
  *
  *        This file is a part of the numerical methods implementation/
  *        benchmarking described in the following article:
  *
  *	   http://www.math.cornell.edu/~vlad/papers/pHCM/
  *
  *	   The HCM and pHCM algorithms were developed by A. Chacon and 
  *	   A. Vladimirsky.
  *
  * =====================================================================================
  */

#ifndef PARAMS_H
#define PARAMS_H


enum flags {ACCEPTED, CONSIDERED, FAR, IN=1, OUT=2};
enum sweepDirection{LeftBackBottom, RightBackBottom, RightFrontBottom, LeftFrontBottom, LeftBackTop,
                RightBackTop, RightFrontTop, LeftFrontTop};
/*8/25/11: The order of the enum listing sweepDirection is written to match
the order in OtherCommon.h: SetSweepDirs()  */

enum loc_flag{LEFT, RIGHT, BACK, FRONT, BOTTOM, TOP};//,INTERIOR, OTHER};
enum speeds{checkerboard,combmaze2, combmaze4, combmaze6, sinusoid1, constantf, sinusoid2,generalf,blob,shellMaze};
enum exits{lowerleftcorner, center,domainedge, zaxis};
//enum methodSet{FMM,LSM,HCM,SLFLLL, CELL};

//command line parameters held in here:
struct param_struct
{
  int m;
  int nc; //numcheckers;
  speeds sp; //built-in speed function
  exits ex; //built-in exit set.
  int ge; //bool: get error?
  //int n; //will set n = m;
  double threshConst;
  int numTrials; //the number of times each method runs
};

void get_params(int argc, char** argv, param_struct* params);
#endif
