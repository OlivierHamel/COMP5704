  /*
  * =====================================================================================
  *
  *  This program is free software: you can redistribute it and/or modify
  *  it under the terms of the GNU General Public License as published by
  *  the Free Software Foundation, either version 3 of the License, or
  *  (at your option) any later version.
  *
  *  This program is distributed in the hope that it will be useful,
  *  but WITHOUT ANY WARRANTY; without even the implied warranty of
  *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  *  GNU General Public License for more details.
  *
  *  You should have received a copy of the GNU General Public License
  *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
  *
  * -------------------------------------------------------------------------------------
  *
  *       Filename:  params.cpp
  *
  *        Version:   1.0
  *        Created:   6/18/13
  *        Revision:  none
  *        Compiler:  gcc/intel compiler
  *        Author:    Adam Chacon, adamdante@gmail.com
  *                   Cornell University
  *
  *        This file is a part of the numerical methods implementation/
  *        benchmarking described in the following article:
  *
  *	   http://www.math.cornell.edu/~vlad/papers/pHCM/
  *
  *	   The HCM and pHCM algorithms were developed by A. Chacon and 
  *	   A. Vladimirsky.
  *
  * =====================================================================================
  */


#include <iostream>
#include "assert.h"
#include "params3D.h"
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>


static void default_params(param_struct* params)
{
       params->m = 96;
       params->ex = center;
       params->sp = constantf;
       params->nc = 11;
       params->ge = 0;
       params->threshConst = .0001;
       params->numTrials = 1;
}


void get_params(int argc, char** argv, param_struct* params)
{

    default_params(params);
    for(int i = 1; i < argc; i = i+2) //assumes there is a string following each option
        //eg, -e lowerleftcorner
    {
        if(i + 1 != argc)
        {
            if(strcmp(argv[i],"-e") == 0)
            {
                if(strcmp(argv[i+1],"lowerleftcorner") == 0)
                    params->ex = lowerleftcorner;
                else if(strcmp(argv[i+1],"center") == 0)
                    params->ex = center;
                else if(strcmp(argv[i+1],"domainedge") == 0)
                    params->ex = domainedge;
                else if(strcmp(argv[i+1],"zaxis") == 0)
                    params->ex = zaxis;
            }
            if(strcmp(argv[i],"-m") == 0)
	      params->m = atoi(argv[i+1]);
	    if(strcmp(argv[i],"-n") == 0)
	      params->numTrials = atoi(argv[i+1]);
	    if(strcmp(argv[i],"-c") == 0)
	      params->nc = atoi(argv[i+1]);
	    if(strcmp(argv[i],"-w") == 0)
	      params->threshConst = atof(argv[i+1]);
	    if(strcmp(argv[i],"-t") == 0)
	      params->ge = atoi(argv[i+1]);
	    if(strcmp(argv[i],"-s") == 0)
	      {
	       if(strcmp(argv[i+1],"constantf") == 0)
                    params->sp = constantf;
                else if(strcmp(argv[i+1],"combmaze4") == 0)
                    params->sp = combmaze4;
                else if(strcmp(argv[i+1],"combmaze2") == 0)
                    params->sp = combmaze2;
                else if(strcmp(argv[i+1],"combmaze6") == 0)
                    params->sp = combmaze6;
                else if(strcmp(argv[i+1],"checkerboard") == 0)
                    params->sp = checkerboard;
                else if(strcmp(argv[i+1],"sinusoid1") == 0)
                    params->sp = sinusoid1;
                else if(strcmp(argv[i+1],"sinusoid2") == 0)
                    params->sp = sinusoid2;
                else if (strcmp(argv[i+1],"blob") == 0)
                    params->sp = blob;
                else if (strcmp(argv[i+1],"shellMaze") == 0)
		  params->sp = shellMaze;
            }
        }

    }

}


/*
void get_params(int argc, char** argv, param_struct* params)
{
 extern char* optarg;
 const char* optstring = "m:e:s:c:t:w:";
 int b;
 #define get_int_arg(b,field) \
         case b: params->field = atoi(optarg); break                                 
#define get_flt_arg(b, field) \
    case b: params->field = (float) atof(optarg); break

         
 default_params(params);          
 while ((b = getopt(argc,argv, optstring)) != -1){
       switch(b) {
                 get_int_arg('m',m);
                 get_int_arg('c',nc);
                 get_int_arg('t',ge);
                 get_flt_arg('w',threshConst);
               case 'e':
                    if(strcmp(optarg, "lowerleftcorner") == 0)
                      params->ex = lowerleftcorner;
                    if(strcmp(optarg, "center") == 0)
                      params->ex = center;
                    if(strcmp(optarg, "domainedge") == 0)
                      params->ex = domainedge;
                    if(strcmp(optarg, "zaxis") == 0)
                      params->ex = zaxis;
                    break;  
               case 's':
                    if(strcmp(optarg,"sinusoid1") == 0)
                      params->sp = sinusoid1;
                    if(strcmp(optarg,"sinusoid2") == 0)
                      params->sp = sinusoid2;
                    if(strcmp(optarg,"combmaze2") == 0)
                      params->sp = combmaze2;
                    if(strcmp(optarg,"combmaze4") == 0)
                      params->sp = combmaze4;
                    if(strcmp(optarg,"combmaze6") == 0)
                      params->sp = combmaze6;
                    if(strcmp(optarg,"constantf") == 0)
                      params->sp = constantf;
                    if(strcmp(optarg,"checkerboard") == 0)
                      params->sp = checkerboard;
                    if(strcmp(optarg,"generalf") == 0)
                      params->sp = generalf;   
                    if(strcmp(optarg,"blob") == 0)
                      params->sp = blob;
                    break;
                 //default:
                         //fprintf(stderr, "Unknown option \n");
                 }
 }  
}
*/
