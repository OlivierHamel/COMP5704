  /*
  * =====================================================================================
  *
  *  This program is free software: you can redistribute it and/or modify
  *  it under the terms of the GNU General Public License as published by
  *  the Free Software Foundation, either version 3 of the License, or
  *  (at your option) any later version.
  *
  *  This program is distributed in the hope that it will be useful,
  *  but WITHOUT ANY WARRANTY; without even the implied warranty of
  *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  *  GNU General Public License for more details.
  *
  *  You should have received a copy of the GNU General Public License
  *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
  *
  * -------------------------------------------------------------------------------------
  *
  *       Filename:  Detrixhe.cpp
  *
  *        Version:   1.0
  *        Created:   6/18/13
  *        Revision:  none
  *        Compiler:  gcc/intel compiler
  *        Author:    Adam Chacon, adamdante@gmail.com
  *                   Cornell University
  *
  *        This file is a part of the numerical methods implementation/
  *        benchmarking described in the following article:
  *
  *	   http://www.math.cornell.edu/~vlad/papers/pHCM/
  *
  *	   The HCM and pHCM algorithms were developed by A. Chacon and 
  *	   A. Vladimirsky.  The "parallelDetrixhe()" and "parallelDetrixheLSM()" subroutine
  *    of this file are based on the method in the following paper:
  *
  *    M. Detrixhe, F. Gibou, C. Min, "A parallel fast sweeping method for the Eikonal
  *    equation, Journal of Computational Physics, v.237, pp.46-55, 2013.
  * =====================================================================================
  */

#include "parallelHCM.h"


void divideWork(int planarSlice, int* iDivs, int* d_iDivs, int* divArray, int I1, int I2, int* iStart)
{

  /* iDivs and d_iDivs are input arrays of length m. 
     Given a planar slice (indexed p) of the domain cube:
     d_iDivs[i] = number of nodes along an i curve of the planar slice p.
     iDivs[i] = cumulative total of nodes until and including the i-curve.
     Both iDivs and d_iDivs are length m, but depending on p, only a contiguous portion of the elements is nonzero.

     I1 and I2 are from the main loop, already computed by the time divideWork() is called.

     iStart and iEnd are the output arrays of length "numthreads".  The pth element of these arrays gives I1 and I2, respectively, for
     the pth processor.

     INCOMPLETE- DO NOT USE THIS FUNCTION
*/
  int i,p,j, k, numDivsToMake, numIlevels, numDivsMade;
  int minDist, tempDist, minIndex, peak, tempDiv, iEnd, numNodes, peakDist;
  int L,R;
  bool block1 = false;
  bool block2 = false;
  bool block3 = false;

  p = 1; //remove this line when complete (compiler warning)

  if(planarSlice < m)
    block1 = true;
  else if (planarSlice < 2*m - 2)
    block2 = true;
  else
    block3 = true;

  /*1.  Set iDivs and d_iDivs, and initialize the divArray. */
  for(i = 0; i < m; i++)
    {
      iDivs[i] = 0;
      d_iDivs[i] = 0;
      divArray[i] = -1;
    }

  
  for(i = I1; i <= I2; i++)
    {
      peak = planarSlice + 1 - m;
      peakDist = abs(i - peak);
      d_iDivs[i] = max(0, m - peakDist);
    }


  iDivs[I1] = d_iDivs[I1];
  for(i = I1 + 1; i <= m - 1; i++)
    iDivs[i] = d_iDivs[i] + iDivs[i - 1];

  /*Note that the above loop goes until m - 1, not I2, so in block1 iDivs will look like
    4|7|9|10|10|10|10
    
    In block3 it will still be
    0|0|0|1|3|6|10

*/

  numNodes = iDivs[I2];

#ifdef _DEBUGMODE
  if(block2)
    {
      
      for(i = 0; i < m; i++)
	assert(d_iDivs[i] > 1);
    }
  if(p < m - 1)
    {
      for(i = 0; i < m; i++)
	assert(d_iDivs[i] < m);
    }
#endif

  /*2.  Make divisions and store them as they are created in the divArray  */
  numDivsMade = 0;
  while(numDivsMade + 1 < numthreads) //numGroups = numDivs + 1
    {
      numDivsToMake = (int)pow(2,numDivsMade);
      
      for(k = 0; k < numDivsToMake; k++)
	{
	  if(k == 0)
	    L = 0; //right of left (-.5) //index of the first bin
	  else
	    L = divArray[numDivsMade];

	  if(k == numDivsToMake - 1)
	    R = m - 1;//index of the final bin
	  else
	    R = divArray[numDivsMade];

	  numNodes = iDivs[R] - iDivs[L];//number of nodes between leftDiv and rightDiv;

	  if(numNodes % 2 == 0)
	    tempDiv = numNodes/2;
	  else
	    tempDiv = (numNodes - 1)/2;
	  
	  //Find closest iDiv:
	  //TODO: improve

	  minDist = (int) pow(m,3);
	  minIndex = 0;
	  for(p = 0; p < numIlevels; p++)
	    {
	      tempDist = max(iDivs[p] - tempDiv, tempDiv - iDivs[p]);
	      if(minDist > tempDist)
		{
		  minDist = tempDist;
		  minIndex = p;
		}
	    }
	  divArray[numDivsMade] = minIndex;
	  numDivsMade++;

	}

    }
  
  /* 3.  Sort the divArray */

  /*4.  Collapse. */
  while(numDivsMade + 1 > numthreads) //numDivsMade = numSubgroups - 1
    {

    }





#ifdef _DEBUGMODE
  /*Make sure the ranges don't overlap  
  for(p = 0; p < numthreads - 1; p++)
    {
      if(iEnd[p] >= iStart[p + 1])
	{
	  cout<<"Ranges overlap."<<endl;
	  assert(false);
	}
    }
  */
#endif

}




int parallelDetrixhe(FSMGridpoint*** domain)
{
  int planarSlice, planarStart, planarEnd, I1, I2, J1, J2;
  int level, levStart, levEnd, levInc, level2;
  int levelCoeff, jCoeff;
  int i,j, k, numSweeps, numChanging;
  bool changing = true;
  DOUBLE temp;
  DOUBLE maxChange, percentChanging;
  DOUBLE zbarOld;
numSweeps = 0;
  int maxSweep = (int)inf;
 
  FSMGridpoint* zbar;
  SweepData possibleSweeps[8];
  
  SetSweepDirs(0,m-1,0,b-1,0,n-1,possibleSweeps);
  SweepData* currentSweep;
  int incrementI, incrementJ, incrementK;
  maxChange = 0;
  cout<<"NumThreads: "<<numthreads<<endl;
  omp_set_num_threads(numthreads);
  
  while(changing && (numSweeps < maxSweep))
    {
      changing = false;
      currentSweep = &possibleSweeps[numSweeps%8];
      
      incrementI = currentSweep->iInc;
      incrementJ = currentSweep->jInc;
      incrementK = currentSweep->kInc;
      

      //There are 3*m - 2 planar slices through the cube.
        if(incrementI > 0)
	  {
            planarStart = 0;
            planarEnd = 3*m - 3;
	  }
        else
	  {
            planarStart = 3*m - 3;
            planarEnd = 0;
	  }
	
        for(planarSlice = planarStart; planarSlice != planarEnd + incrementI; planarSlice += incrementI)
	  {
           
	    if(incrementI*incrementK > 0)
	      {
		I1 = max(0,planarSlice - 2*m +2);
		I2 = min(planarSlice, m-1);
	      }
	    else
	      {
		I1 = max(0, m - 1 - planarSlice);
		I2 = min(m - 1, 3*m - 3 - planarSlice);
	      }
	    ASSERT(I1 >= 0 && I1 <= I2 && I2 <= m - 1);

	    //DivideWork()
    

#pragma omp parallel private(i,j,k,level, level2, J1, J2, jCoeff, levelCoeff, zbar, temp,zbarOld)
	    {
#pragma omp for schedule(static) reduction(+:changing)
	      for(i = I1; i <= I2; i++)  
		{
		  level = planarSlice - i;
		  level2 = planarSlice + i;
#ifdef _DEBUGMODE
		  if(incrementI*incrementK > 0)
		    ASSERT(level >= 0 && level <= 2*m - 2);
		  else
		    ASSERT(level2 >= m - 1 && level2 <= 3*m - 3);
#endif		  
		
		  if((incrementI > 0 && incrementJ > 0 && incrementK > 0) || (incrementI < 0 && incrementJ < 0 && incrementK < 0))
		    {
		      //i + j + k = C
		      //(level += 0)
		      J1 = max(0,level - m + 1);
		      J2 = min(level, m - 1);
		      levelCoeff = 1;
		      jCoeff = -1;
		    }
		  else if((incrementI > 0 && incrementJ < 0 && incrementK > 0) || (incrementI < 0 && incrementJ > 0 && incrementK < 0))
		    {
		      //i - j + k = C
		      
		      level -= m - 1;
		      J1 = max(0, -level);
		      J2 = min(m - 1, m - 1 - level);
		      levelCoeff = 1;
		      jCoeff = 1;
		    }
		  else if((incrementI > 0 && incrementJ < 0 && incrementK < 0) || (incrementI < 0 && incrementJ > 0 && incrementK > 0))
		    {
		      //i - j - k = C
		      level2 -= m - 1;
		      J1 = max(0,level2 - m + 1);
		      J2 = min(level2, m - 1);
		      level = level2;
		      levelCoeff = 1;
		      jCoeff = -1;
		    }
		  else if((incrementI > 0 && incrementJ > 0 && incrementK < 0) || (incrementI < 0 && incrementJ < 0 && incrementK > 0))
		    {
		      //i + j - k = C
		      level2 -= 2*m - 2;
		      J1 = max(0, -level2);
		      J2 = min(m - 1, m - 1 - level2);
		      level = level2;
		      levelCoeff = 1;
		      jCoeff = 1;
		    }
		  
		  ASSERT(J1 >= 0 && J2 <= m - 1);
		  ASSERT(J1 <= J2);
		  
		  for(j = J1; j <= J2; j++)
		    {
		      k = levelCoeff*level + jCoeff*j;
		      ASSERT(k >= 0 && k <= m - 1);
		       
		      zbar = &domain[i][j][k];
		      zbarOld = zbar->value;
		      temp = UpdateNode(domain,i,j,k);
		      if(temp < zbarOld)
			{  
			  zbar->value = temp;
			  if(temp + sweepTerminationThresh < zbarOld)
			    {
			      changing = true;
			    }
			  
			}
		        
		    }  //for j
		} //for i
	    }//parallel region
	    if(changing > 0)
	      changing = true;
	  }  //for planarSlice
	numSweeps++;
    }  //while changing
  return numSweeps;
}


int parallelDetrixheLSM(LSMGridpoint*** domain)
{
  int planarSlice, planarStart, planarEnd, I1, I2, J1, J2;
  int level, levStart, levEnd, levInc, level2;
  int levelCoeff, jCoeff;
  int i,j, k, numSweeps, numChanging;
  bool changing = true;
  DOUBLE temp;
  DOUBLE maxChange, percentChanging;
  numSweeps = 0;
  int maxSweep = (int)inf;
  DOUBLE zbarOld;
  LSMGridpoint* zbar;
  SweepData possibleSweeps[8];
  


  SetSweepDirs(0,m-1,0,b-1,0,n-1,possibleSweeps);
  SweepData* currentSweep;
  int incrementI, incrementJ, incrementK;
  maxChange = 0;
  cout<<"NumThreads: "<<numthreads<<endl;
  omp_set_num_threads(numthreads);
  
  while(changing && (numSweeps < maxSweep))
      {
        changing = false;
        currentSweep = &possibleSweeps[numSweeps%8];

        incrementI = currentSweep->iInc;
        incrementJ = currentSweep->jInc;
        incrementK = currentSweep->kInc;


	//There are 3*m - 2 planar slices through the cube.
        if(incrementI > 0)
	  {
            planarStart = 0;
            planarEnd = 3*m - 3;
	  }
        else
	  {
            planarStart = 3*m - 3;
            planarEnd = 0;
	  }
	
        for(planarSlice = planarStart; planarSlice != planarEnd + incrementI; planarSlice += incrementI)
	  {

	    if(incrementI*incrementK > 0)
	      {
		I1 = max(0,planarSlice - 2*m +2);
		I2 = min(planarSlice, m-1);
	      }
	    else
	      {
		I1 = max(0, m - 1 - planarSlice);
		I2 = min(m - 1, 3*m - 3 - planarSlice);
	      }
	    ASSERT(I1 >= 0 && I1 <= I2 && I2 <= m - 1);

	    //DivideWork()
    

#pragma omp parallel private(i,j,k,level, level2, J1, J2, jCoeff, levelCoeff, zbar, temp, zbarOld)
	    {
#pragma omp for schedule(static) reduction(+:changing)
	      for(i = I1; i <= I2; i++)  
		{
		  level = planarSlice - i;
		  level2 = planarSlice + i;
#ifdef _DEBUGMODE
		  if(incrementI*incrementK > 0)
		    ASSERT(level >= 0 && level <= 2*m - 2);
		  else
		    ASSERT(level2 >= m - 1 && level2 <= 3*m - 3);
#endif		  
		 
		  if((incrementI > 0 && incrementJ > 0 && incrementK > 0) || (incrementI < 0 && incrementJ < 0 && incrementK < 0))
		    {
		      //i + j + k = C
		      //(level += 0)
		      J1 = max(0,level - m + 1);
		      J2 = min(level, m - 1);
		      levelCoeff = 1;
		      jCoeff = -1;
		    }
		  else if((incrementI > 0 && incrementJ < 0 && incrementK > 0) || (incrementI < 0 && incrementJ > 0 && incrementK < 0))
		    {
		      //i - j + k = C
		      
		      level -= m - 1;
		      J1 = max(0, -level);
		      J2 = min(m - 1, m - 1 - level);
		      levelCoeff = 1;
		      jCoeff = 1;
		    }
		  else if((incrementI > 0 && incrementJ < 0 && incrementK < 0) || (incrementI < 0 && incrementJ > 0 && incrementK > 0))
		    {
		      //i - j - k = C
		      level2 -= m - 1;
		      J1 = max(0,level2 - m + 1);
		      J2 = min(level2, m - 1);
		      level = level2;
		      levelCoeff = 1;
		      jCoeff = -1;
		    }
		  else if((incrementI > 0 && incrementJ > 0 && incrementK < 0) || (incrementI < 0 && incrementJ < 0 && incrementK > 0))
		    {
		      //i + j - k = C
		      level2 -= 2*m - 2;
		      J1 = max(0, -level2);
		      J2 = min(m - 1, m - 1 - level2);
		      level = level2;
		      levelCoeff = 1;
		      jCoeff = 1;
		    }
		  
		  ASSERT(J1 >= 0 && J2 <= m - 1);
		  ASSERT(J1 <= J2);
		  
		  for(j = J1; j <= J2; j++)
		    {
		      k = levelCoeff*level + jCoeff*j;
		      ASSERT(k >= 0 && k <= m - 1);
		       
		      zbar = &domain[i][j][k];
		      if(!zbar->isLocked)
			{
			  zbar->isLocked = true;
			  zbarOld = zbar->value;
			  temp = UpdateNode(domain,i,j,k);
			  if(temp < zbarOld)
			    {  
			      zbar->value = temp;
			      UnlockNeighbors(domain,i,j,k);
			      if(temp + sweepTerminationThresh < zbarOld)
				{
				  changing = true;
				}
			    }    
			}
		    }  //for j
		} //for i
	    }//parallel region
	    if(changing > 0)
	      changing = true;
	  }  //for planarSlice
        numSweeps++;
      }  //while changing
    return numSweeps;
}


