#!/bin/bash

#g++ main.cpp HeapCellMethod.cpp parallelHCM.cpp params.cpp OtherCommon.cpp Detrixhe.cpp -O2 -g -fopenmp -Dnumthreads=1 -o parallelEik_O2_Detrixhe.exe

icpc main.cpp HeapCellMethod.cpp parallelHCM.cpp params.cpp OtherCommon.cpp Detrixhe.cpp -O2 -openmp -parallel -o parallelEik.exe

