  /*
  * =====================================================================================
  *
  *  This program is free software: you can redistribute it and/or modify
  *  it under the terms of the GNU General Public License as published by
  *  the Free Software Foundation, either version 3 of the License, or
  *  (at your option) any later version.
  *
  *  This program is distributed in the hope that it will be useful,
  *  but WITHOUT ANY WARRANTY; without even the implied warranty of
  *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  *  GNU General Public License for more details.
  *
  *  You should have received a copy of the GNU General Public License
  *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
  *
  * -------------------------------------------------------------------------------------
  *
  *       Filename:  OtherCommon.h
  *
  *        Version:   1.0
  *        Created:   6/18/13
  *        Revision:  none
  *        Compiler:  gcc/intel compiler
  *        Author:    Adam Chacon, adamdante@gmail.com
  *                   Cornell University
  *
  *        This file is a part of the numerical methods implementation/
  *        benchmarking described in the following article:
  *
  *	   http://www.math.cornell.edu/~vlad/papers/pHCM/
  *
  *	   The HCM and pHCM algorithms were developed by A. Chacon and 
  *	   A. Vladimirsky.
  *
  * =====================================================================================
  */


#ifndef OTHERCOMMON_H
#define OTHERCOMMON_H


#include "params3D.h"
#include <iostream>
#include <fstream>
#include "GlobalVars3D.h"
#include "ExternVars.h"
#include "GlobalConfiguration.h"
#include <math.h>
#include <assert.h>
#include "Gridpoint.h"

void print_params(param_struct params);
//void print(node*** domain,int rowlength, int collength);  //TODO


DOUBLE getspeed(DOUBLE x, DOUBLE y,   DOUBLE z);
DOUBLE twonorm(  DOUBLE x,   DOUBLE y,   DOUBLE z);
DOUBLE ComputeBorder(int i, int j, int k);
void SetNeighborVec(int neighborVec[6][3]);
void UnlockNeighbors(LSMGridpoint*** domain, int x, int y, int z);

void printLevelSet(LSMGridpoint*** domain, DOUBLE level);

inline DOUBLE Min(DOUBLE a, DOUBLE b)
{
    return ((a < b) ? a : b);
}

inline DOUBLE Max(DOUBLE a, DOUBLE b)
{
    return ((a > b) ? a : b);
}


inline DOUBLE getspeed(DOUBLE x,   DOUBLE y,   DOUBLE z)
{

    ASSERT(x >= minx - eps && x <= maxx + eps);
    ASSERT(y >= miny - eps && y <= maxy + eps);
    ASSERT(z >= minz - eps && z <= maxz + eps);

    DOUBLE slowSpeed = 1;
    DOUBLE fastSpeed = 2;
    DOUBLE t,txy,w, opening;




    switch(speed_fun)
      {
      case constantf:
        return 1.0;
        break;
	
      case sinusoid1:
	//return (1 + .5*sin(20*pi*x)*sin(20*pi*y));
        return (1 + .5*sin(20*pi*x)*sin(20*pi*y)*sin(20*pi*z));
	
        break;
      case sinusoid2:
	
        //return (1 + .99*sin(2*pi*x)*sin(2*pi*y));
        return (1 + .99*sin(2*pi*x)*sin(2*pi*y)*sin(2*pi*z));
	
        break;
	
      case blob:
        if(twonorm(x - .5,y - .5,z - .5) < .3)
	  return .01;
        else
	  return 1;
        break;
	
	
      case combmaze2:
        if(y <  1 - (1.0/11))
	  {
            if(x > 1.0/15 && x < 2.0/15)
	      return .01;
	  }
        if(y > 1.0/11)
	  {
            if(x > 3.0/15 && x < 4.0/15)
	      return .01;
	  }
        return 1;
	
        break;
	
      case combmaze4:
        if(y <  1 - (1.0/11))
	  {
            if((x > 10.0/110 && x < 20.0/110) || (x > 50.0/110 && x < 60.0/110))
	      return .01;
	  }
        if( y > 1.0/11)
	  {
            if((x > 30.0/110 && x < 40.0/110) || (x > 70.0/110 && x < 80.0/110))
	      return .01;
	  }
        return 1;
	
        break;
	
	
      case combmaze6:
        if(y <  1 - (1.0/11))
	  {
            if((x > 1.0/15 && x < 2.0/15) || (x > 5.0/15 && x < 6.0/15) || (x > 9.0/15 && x < 10.0/15))
	      return .01;
	  }
        if( y > 1.0/11)
	  {
	    if((x > 3.0/15 && x < 4.0/15) || (x > 7.0/15 && x < 8.0/15) || (x > 11.0/15 && x < 12.0/15))
	      return .01;
	  }
        return 1;
	
        break;
	
      case checkerboard:
        int i,j,k;
        	
        for(k = 0; k <= (numcheckers - numcheckers%2)/2; k++)
        {
	  if(z > (2*k +1)*checkerdimz && z < (2*k + 2)*checkerdimz) //"regular checkerboard"
	    {
	      for(i = 0; i <= (numcheckers - numcheckers%2)/2; i++)
		{
		  if(x > (2*i+1)*checkerdimx && x < (2*i+2)*checkerdimx)
		    {
		      for(j = 0; j <= (numcheckers - numcheckers%2)/2; j++)
			{
			  if(y > (2*j + 1)*checkerdimy && y < (2*j + 2)*checkerdimy)
			    return slowSpeed;
			  if(y >= (2*j)*checkerdimy && y <= (2*j + 1)*checkerdimy)
			    return fastSpeed;
			}
		    }
		  if(x >= (2*i)*checkerdimx && x <= (2*i +1)*checkerdimx)
		    {
		      for(j = 0; j <= (numcheckers - numcheckers%2)/2; j++)
			{
			  if(y > (2*j + 1)*checkerdimy && y < (2*j + 2)*checkerdimy )
			    return fastSpeed;
			  if(y >= (2*j)*checkerdimy && y <= (2*j +1)*checkerdimy)
			    return slowSpeed;
			}
		    }
		}
	    }
	  if(z >= (2*k)*checkerdimz && z <= (2*k + 1)*checkerdimz) //"reverse checkerboard"
	    {
	      for(i = 0; i <= (numcheckers - numcheckers%2)/2; i++)
		{
		  if(x > (2*i+1)*checkerdimx && x < (2*i+2)*checkerdimx)
		    {
		      for(j = 0; j <= (numcheckers - numcheckers%2)/2; j++)
			{
			  if(y > (2*j + 1)*checkerdimy && y < (2*j + 2)*checkerdimy)
			    return fastSpeed;
			  if(y >= (2*j)*checkerdimy && y <= (2*j + 1)*checkerdimy)
			    return slowSpeed;
		      }
		    }
		  if(x >= (2*i)*checkerdimx && x <= (2*i +1)*checkerdimx)
		    {
		      for(j = 0; j <= (numcheckers - numcheckers%2)/2; j++)
			{
			  if(y > (2*j + 1)*checkerdimy && y < (2*j + 2)*checkerdimy )
			    return slowSpeed;
			  if(y >= (2*j)*checkerdimy && y <= (2*j +1)*checkerdimy)
			    return fastSpeed;
			}
		    }
		}
	    }
	}
	//cout<<"Function not defined for (x,y) = ("<<x<<","<<y<<")"<<endl;
        assert(false);
        break;

      case shellMaze:
	//barrierSpeed is set in GlobalVars3D.h;
	w = 1.0/12.0;
	t = twonorm(x,y,z);
	opening = .2;
	txy = sqrt(x*x + y*y); //Detrixhe does not take the sqrt of x*x + y*y
	if(t > .3 && t < (.3 + w) && !(txy < opening && z < 0))
	  return barrierSpeed;
	if(t > .5 && t < (.5 + w) && !(txy < opening && z > 0))
	  return barrierSpeed;
	if(t > .7 && t < (.7 + w) && !(txy < opening && z < 0))
	  return barrierSpeed;
	if(t > .9 && t < (.9 + w) && !(txy < opening && z > 0))
	  return barrierSpeed;
	return 1;
	break;

	
      case generalf:
        return 1/sqrt((x+1)*(x+1) + (y+1)*(y+1));
	
        break;
      default:
        assert(false);
	
      }
    assert(false);
}


inline void SetSweepDirs(int left, int right, int bottom, int top, int back, int front, SweepData* possibleSweeps)
{

    //left-bottom-back
    possibleSweeps[0].iStart = left;
    possibleSweeps[0].iEnd = right;
    possibleSweeps[0].jStart = back;
    possibleSweeps[0].jEnd = front;
    possibleSweeps[0].kStart = bottom;
    possibleSweeps[0].kEnd = top;
    possibleSweeps[0].iInc = 1;
    possibleSweeps[0].jInc = 1;
    possibleSweeps[0].kInc = 1;

    //right-bottom-back
    possibleSweeps[1].iStart = right;
    possibleSweeps[1].iEnd = left;
    possibleSweeps[1].jStart = back;
    possibleSweeps[1].jEnd = front;
    possibleSweeps[1].kStart = bottom;
    possibleSweeps[1].kEnd = top;
    possibleSweeps[1].iInc = -1;
    possibleSweeps[1].jInc = 1;
    possibleSweeps[1].kInc = 1;

    //right-bottom-front
    possibleSweeps[2].iStart = right;
    possibleSweeps[2].iEnd = left;
    possibleSweeps[2].jStart = front;
    possibleSweeps[2].jEnd = back;
    possibleSweeps[2].kStart = bottom;
    possibleSweeps[2].kEnd = top;
    possibleSweeps[2].iInc = -1;
    possibleSweeps[2].jInc = -1;
    possibleSweeps[2].kInc = 1;

    //left-bottom-front
    possibleSweeps[3].iStart = left;
    possibleSweeps[3].iEnd = right;
    possibleSweeps[3].jStart = front;
    possibleSweeps[3].jEnd = back;
    possibleSweeps[3].kStart = bottom;
    possibleSweeps[3].kEnd = top;
    possibleSweeps[3].iInc = 1;
    possibleSweeps[3].jInc = -1;
    possibleSweeps[3].kInc = 1;

    //left-top-back
    possibleSweeps[4].iStart = left;
    possibleSweeps[4].iEnd = right;
    possibleSweeps[4].jStart = back;
    possibleSweeps[4].jEnd = front;
    possibleSweeps[4].kStart = top;
    possibleSweeps[4].kEnd = bottom;
    possibleSweeps[4].iInc = 1;
    possibleSweeps[4].jInc = 1;
    possibleSweeps[4].kInc = -1;

    //right-top-back
    possibleSweeps[5].iStart = right;
    possibleSweeps[5].iEnd = left;
    possibleSweeps[5].jStart = back;
    possibleSweeps[5].jEnd = front;
    possibleSweeps[5].kStart = top;
    possibleSweeps[5].kEnd = bottom;
    possibleSweeps[5].iInc = -1;
    possibleSweeps[5].jInc = 1;
    possibleSweeps[5].kInc = -1;

    //right-top-front
    possibleSweeps[6].iStart = right;
    possibleSweeps[6].iEnd = left;
    possibleSweeps[6].jStart = front;
    possibleSweeps[6].jEnd = back;
    possibleSweeps[6].kStart = top;
    possibleSweeps[6].kEnd = bottom;
    possibleSweeps[6].iInc = -1;
    possibleSweeps[6].jInc = -1;
    possibleSweeps[6].kInc = -1;

    //left-top-front
    possibleSweeps[7].iStart = left;
    possibleSweeps[7].iEnd = right;
    possibleSweeps[7].jStart = front;
    possibleSweeps[7].jEnd = back;
    possibleSweeps[7].kStart = top;
    possibleSweeps[7].kEnd = bottom;
    possibleSweeps[7].iInc = 1;
    possibleSweeps[7].jInc = -1;
    possibleSweeps[7].kInc = -1;
}

/*
template <class GPs>
void printZSlice(GPs*** domain, int zSlice)
{
  assert(zSlice < m);

  ofstream arrayfile;
  arrayfile.open("Test3.m");
  arrayfile<<"m = [   "<<endl;
  for(int i = 0; i < m; i++)
    {
      for(int j = 0; j < n; j++)
	arrayfile<<setprecision(18)<<domain[i][j][zSlice].value<<"  ";
      arrayfile<<endl;
    }
  arrayfile<<" ];"<<endl;
  arrayfile<<"m = m';";
  arrayfile<<"n = "<<n<<";"<<endl;
  arrayfile.close();
  
}
*/

#endif // OTHERCOMMON_H
