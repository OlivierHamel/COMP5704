  /*
  * =====================================================================================
  *
  *  This program is free software: you can redistribute it and/or modify
  *  it under the terms of the GNU General Public License as published by
  *  the Free Software Foundation, either version 3 of the License, or
  *  (at your option) any later version.
  *
  *  This program is distributed in the hope that it will be useful,
  *  but WITHOUT ANY WARRANTY; without even the implied warranty of
  *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  *  GNU General Public License for more details.
  *
  *  You should have received a copy of the GNU General Public License
  *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
  *
  * -------------------------------------------------------------------------------------
  *
  *       Filename:  GlobalVars3D.h
  *
  *        Version:   1.0
  *        Created:   6/18/13
  *        Revision:  none
  *        Compiler:  gcc/intel compiler
  *        Author:    Adam Chacon, adamdante@gmail.com
  *                   Cornell University
  *
  *        This file is a part of the numerical methods implementation/
  *        benchmarking described in the following article:
  *
  *	   http://www.math.cornell.edu/~vlad/papers/pHCM/
  *
  *	   The HCM and pHCM algorithms were developed by A. Chacon and 
  *	   A. Vladimirsky.
  *
  * =====================================================================================
  */


#ifndef GLOBALVARS3D_H
#define GLOBALVARS3D_H


#include "GlobalConfiguration.h"
#include <math.h>

const   DOUBLE maxx = 1;
const   DOUBLE maxy = 1;
const   DOUBLE maxz = 1;
const   DOUBLE minx = 0;
const   DOUBLE miny = 0;
const   DOUBLE minz = 0;
const   DOUBLE inf = 999999999;
const   DOUBLE eps = 1e-9;

const DOUBLE SQRT2 = sqrt(2);

const DOUBLE pi = 3.141592653589793238462643383;

//#define EARLY_SWEEP 1 //6/12/13: this should be set when using nonzero sweepTerminationThresh.
//It's used for early sweep term in HCM only.

#ifdef EARLY_SWEEP
const DOUBLE sweepTerminationThresh = .00000001;
#else
const DOUBLE sweepTerminationThresh = 0;
#endif

const int numCellsStart = 1;

const int mStart = 128;

const int numMTrials = 1;

const int numPTrials = 32;

const int mStep = 64; //each test runs with current_m = mStart + i*mStep

const int numCellDivs = 1;

const DOUBLE barrierSpeed = 0;//.001; //used for shellMaze speed function

#ifdef CONST_THREADS
//const int numthreads = 4;
#else
#endif

typedef struct {
       int iStart;
       int jStart;
       int kStart;
       int iEnd;
       int jEnd;
       int kEnd;
       int iInc;
       int jInc;
       int kInc;
} SweepData;


#endif // GLOBALVARS3D_H
